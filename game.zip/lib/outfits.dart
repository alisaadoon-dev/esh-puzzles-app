// lib/outfits.dart
// الملابس: قبعات ونظارات وأوشحة وعباءات للبومة والثعلب والحيوان الأليف.
// تُشترى مرة واحدة بالعملات، ثم يلبسها أي بطل. تظهر في المغامرة والعش وشاشة الحيوان.

import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'audio.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'pet.dart' show PetStore, PetForm;
import 'sprites.dart';
import 'widgets.dart';

// ───────────── النصوص ─────────────

const _os = {
  'ar': {
    'title': 'خزانة الملابس',
    'back': 'رجوع',
    'head': 'الرأس', 'face': 'الوجه', 'neck': 'الرقبة', 'back_slot': 'الظهر',
    'owl': 'البومة', 'fox': 'الثعلب', 'pet': 'صديقي',
    'no_coins': 'ما عندك عملات كافية! العب المغامرة وافتح الصناديق',
    'wearing': 'يلبسها الآن',
    'tap_off': 'اضغط مرة ثانية لتخلعها',
  },
  'en': {
    'title': 'Wardrobe',
    'back': 'Back',
    'head': 'Head', 'face': 'Face', 'neck': 'Neck', 'back_slot': 'Back',
    'owl': 'Owl', 'fox': 'Fox', 'pet': 'My pet',
    'no_coins': 'Not enough coins! Play the adventure and open chests',
    'wearing': 'Wearing',
    'tap_off': 'Tap again to take it off',
  },
  'fr': {
    'title': 'Garde-robe',
    'back': 'Retour',
    'head': 'Tête', 'face': 'Visage', 'neck': 'Cou', 'back_slot': 'Dos',
    'owl': 'Hibou', 'fox': 'Renard', 'pet': 'Mon ami',
    'no_coins': 'Pas assez de pièces ! Joue l\'aventure et ouvre des coffres',
    'wearing': 'Porté',
    'tap_off': 'Touche encore pour l\'enlever',
  },
};

String oT(String k) => (_os[L.lang] ?? _os['ar']!)[k] ?? k;

// ───────────── القطع ─────────────

enum Slot { head, face, neck, back }

class Outfit {
  final String id;
  final Slot slot;
  final String emoji; // للعباءة والأجنحة: رمز العرض في المتجر فقط
  final int price;
  final Color? cape; // لون العباءة المرسومة
  final bool wings;
  const Outfit(this.id, this.slot, this.emoji, this.price, {this.cape, this.wings = false});
}

const kOutfits = [
  // الرأس
  Outfit('flower', Slot.head, '🌺', 15),
  Outfit('bow', Slot.head, '🎀', 20),
  Outfit('cap', Slot.head, '🧢', 25),
  Outfit('sunhat', Slot.head, '👒', 30),
  Outfit('tophat', Slot.head, '🎩', 40),
  Outfit('gradcap', Slot.head, '🎓', 50),
  Outfit('crown', Slot.head, '👑', 150),
  // الوجه
  Outfit('glasses', Slot.face, '👓', 25),
  Outfit('sunglasses', Slot.face, '🕶️', 35),
  Outfit('goggles', Slot.face, '🥽', 40),
  // الرقبة
  Outfit('ribbon', Slot.neck, '🎗️', 20),
  Outfit('scarf', Slot.neck, '🧣', 30),
  Outfit('medal', Slot.neck, '🏅', 60),
  // الظهر
  Outfit('cape_red', Slot.back, '🟥', 50, cape: Color(0xFFE53935)),
  Outfit('cape_blue', Slot.back, '🟦', 50, cape: Color(0xFF1E88E5)),
  Outfit('cape_gold', Slot.back, '🟨', 120, cape: Color(0xFFFFC107)),
  Outfit('wings', Slot.back, '🪽', 100, wings: true),
];

Outfit? outfitById(String? id) {
  if (id == null) return null;
  for (final o in kOutfits) {
    if (o.id == id) return o;
  }
  return null;
}

/// من يلبس: 'owl' أو 'fox' أو 'pet'
const kWearers = ['owl', 'fox', 'pet'];

// ───────────── الحفظ (مع نسخة في الذاكرة للرسم السريع) ─────────────

class Outfits {
  static final Set<String> owned = {};
  static final Map<String, Map<Slot, String>> worn = {for (final w in kWearers) w: {}};

  static Future<void> load() async {
    try {
      final sp = await SharedPreferences.getInstance();
      owned
        ..clear()
        ..addAll(sp.getStringList('outfit_owned') ?? const []);
      for (final w in kWearers) {
        worn[w]!.clear();
        for (final s in Slot.values) {
          final id = sp.getString('wear_${w}_${s.name}');
          if (id != null && owned.contains(id)) worn[w]![s] = id;
        }
      }
    } catch (_) {}
  }

  static Future<void> _save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList('outfit_owned', owned.toList());
    for (final w in kWearers) {
      for (final s in Slot.values) {
        final id = worn[w]![s];
        if (id == null) {
          await sp.remove('wear_${w}_${s.name}');
        } else {
          await sp.setString('wear_${w}_${s.name}', id);
        }
      }
    }
  }

  /// يشتري القطعة (إن لم تكن مملوكة). يرجع false إذا العملات لا تكفي.
  static Future<bool> buy(Outfit o) async {
    if (owned.contains(o.id)) return true;
    final sp = await SharedPreferences.getInstance();
    final wallet = sp.getInt('coins') ?? 30;
    if (wallet < o.price) return false;
    await sp.setInt('coins', wallet - o.price);
    owned.add(o.id);
    await _save();
    return true;
  }

  /// يلبس القطعة أو يخلعها إذا كانت ملبوسة. يرجع true إذا صارت ملبوسة.
  static Future<bool> toggle(String wearer, Outfit o) async {
    final m = worn[wearer]!;
    final on = m[o.slot] != o.id;
    if (on) {
      m[o.slot] = o.id;
    } else {
      m.remove(o.slot);
    }
    await _save();
    return on;
  }

  static String? wearing(String wearer, Slot s) => worn[wearer]?[s];
}

// ───────────── الرسم ─────────────

final Map<String, TextPainter> _tp = {};

void _emoji(Canvas c, String e, Offset center, double size) {
  final key = '$e|${size.round()}';
  final tp = _tp.putIfAbsent(key, () {
    if (_tp.length > 120) _tp.clear();
    return TextPainter(
      text: TextSpan(text: e, style: TextStyle(fontSize: size.roundToDouble())),
      textDirection: TextDirection.ltr,
    )..layout();
  });
  tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
}

/// يرسم ملابس [wearer] داخل مربع الشخصية [box].
/// [behind]=true للعباءة والأجنحة (قبل رسم الشخصية)، و false للباقي (بعدها).
void drawOutfit(Canvas c, String wearer, Rect box, double t, {required bool behind}) {
  final m = Outfits.worn[wearer];
  if (m == null || m.isEmpty) return;
  final w = box.width, h = box.height;
  final cx = box.center.dx;
  // مواضع تقريبية كنسبة من ارتفاع الشخصية
  final isPet = wearer == 'pet';
  final headY = box.top + h * (isPet ? .12 : .06);
  final eyeY = box.top + h * (isPet ? .38 : .34);
  final neckY = box.top + h * (isPet ? .62 : .62);
  final shoulderY = box.top + h * .45;

  if (behind) {
    final o = outfitById(m[Slot.back]);
    if (o == null) return;
    if (o.wings) {
      final flap = sin(t * 6) * .25;
      final paint = Paint()..color = Colors.white;
      final edge = Paint()
        ..color = const Color(0xFF90CAF9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;
      for (final side in [-1.0, 1.0]) {
        c.save();
        c.translate(cx + side * w * .18, shoulderY);
        c.rotate(side * (-.5 - flap));
        for (var i = 0; i < 3; i++) {
          final r = Rect.fromLTWH(side > 0 ? 0 : -w * (.42 - i * .08), -h * .12 + i * h * .07,
              w * (.42 - i * .08), h * .12);
          c.drawOval(r, paint);
          c.drawOval(r, edge);
        }
        c.restore();
      }
    } else if (o.cape != null) {
      final wave = sin(t * 5);
      final top = shoulderY - h * .05;
      final bottom = box.bottom - h * .02;
      final half = w * .3;
      final path = Path()
        ..moveTo(cx - half * .6, top)
        ..lineTo(cx + half * .6, top)
        ..quadraticBezierTo(cx + half * 1.1, (top + bottom) / 2, cx + half + wave * 6, bottom)
        ..quadraticBezierTo(cx, bottom + 8 + wave * 4, cx - half - wave * 6, bottom)
        ..quadraticBezierTo(cx - half * 1.1, (top + bottom) / 2, cx - half * .6, top)
        ..close();
      final hsl = HSLColor.fromColor(o.cape!);
      c.drawPath(path, Paint()
        ..shader = ui.Gradient.linear(Offset(cx, top), Offset(cx, bottom),
            [hsl.withLightness((hsl.lightness * 1.2).clamp(0, 1).toDouble()).toColor(),
             hsl.withLightness(hsl.lightness * .6).toColor()]));
      c.drawPath(path, Paint()
        ..color = Colors.white.withValues(alpha: .8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2);
    }
    return;
  }

  final neck = outfitById(m[Slot.neck]);
  if (neck != null) _emoji(c, neck.emoji, Offset(cx, neckY), w * .34);
  final face = outfitById(m[Slot.face]);
  if (face != null) _emoji(c, face.emoji, Offset(cx, eyeY), w * .42);
  final head = outfitById(m[Slot.head]);
  if (head != null) {
    final bob = sin(t * 3) * 1.5;
    _emoji(c, head.emoji, Offset(cx, headY + bob), w * .44);
  }
}

/// طبقة ملابس فوق/تحت ويدجت شخصية بحجم [size].
class OutfitLayer extends StatefulWidget {
  final String wearer;
  final double size;
  final bool behind;
  const OutfitLayer({super.key, required this.wearer, required this.size, required this.behind});
  @override
  State<OutfitLayer> createState() => _OutfitLayerState();
}

class _OutfitLayerState extends State<OutfitLayer> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 20))..repeat();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = Outfits.worn[widget.wearer];
    if (m == null || m.isEmpty) return SizedBox(width: widget.size, height: widget.size);
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _OutfitPainter(widget.wearer, _c.value * 20, widget.behind),
        ),
      ),
    );
  }
}

class _OutfitPainter extends CustomPainter {
  final String wearer;
  final double t;
  final bool behind;
  _OutfitPainter(this.wearer, this.t, this.behind);
  @override
  void paint(Canvas c, Size s) => drawOutfit(c, wearer, Offset.zero & s, t, behind: behind);
  @override
  bool shouldRepaint(covariant _OutfitPainter o) => true;
}

/// يلف صورة شخصية بطبقتي الملابس (خلف وأمام).
Widget dressed(String wearer, double size, Widget character) => SizedBox(
      width: size,
      height: size,
      child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
        OutfitLayer(wearer: wearer, size: size, behind: true),
        character,
        OutfitLayer(wearer: wearer, size: size, behind: false),
      ]),
    );

// ───────────── شاشة خزانة الملابس ─────────────

class WardrobeScreen extends StatefulWidget {
  final String initialWearer;
  const WardrobeScreen({super.key, this.initialWearer = 'owl'});
  @override
  State<WardrobeScreen> createState() => _WardrobeScreenState();
}

class _WardrobeScreenState extends State<WardrobeScreen> with SingleTickerProviderStateMixin {
  late String wearer = widget.initialWearer;
  Slot slot = Slot.head;
  int wallet = 0;
  PetStore? pet;
  String toast = '';
  int toastId = 0, popN = 0;
  late final AnimationController _clock = AnimationController(vsync: this, duration: const Duration(seconds: 30))..repeat();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _clock.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    final sp = await SharedPreferences.getInstance();
    final p = await PetStore.load();
    if (!mounted) return;
    setState(() {
      wallet = sp.getInt('coins') ?? 30;
      pet = p;
    });
  }

  void _say(String k) {
    setState(() {
      toast = oT(k);
      toastId++;
    });
    final id = toastId;
    Future.delayed(const Duration(milliseconds: 2400), () {
      if (mounted && toastId == id) setState(() => toast = '');
    });
  }

  Future<void> _tapItem(Outfit o) async {
    if (!Outfits.owned.contains(o.id)) {
      final ok = await Outfits.buy(o);
      if (!ok) {
        Sfx.play('wrong');
        Buzz.wrong();
        _say('no_coins');
        return;
      }
      Sfx.play('coin');
      await _reload();
    }
    final on = await Outfits.toggle(wearer, o);
    if (!mounted) return;
    if (on) {
      Sfx.play('magic');
      Buzz.magic();
      Future.delayed(const Duration(milliseconds: 250), () => Sfx.play('correct', volume: .6));
      _say('tap_off');
    } else {
      Sfx.play('whoosh');
      Buzz.tick();
    }
    setState(() => popN++);
  }

  Widget _character(double size) {
    ui.Image? img;
    String emoji;
    if (wearer == 'pet') {
      final p = pet;
      if (p == null || p.stage == 0) {
        img = Sprites.get('egg');
        emoji = '🥚';
      } else if (Sprites.get('petb_normal') != null) {
        img = Sprites.get('petb_normal');
        emoji = '🐣';
      } else if (p.stage == 1 || p.form == PetForm.none) {
        img = Sprites.get('pet_baby');
        emoji = '🐣';
      } else {
        img = Sprites.get('pet_${p.form.name}_${p.stage}');
        emoji = '🐣';
      }
    } else {
      img = Sprites.get('${wearer}_happy') ?? Sprites.get(wearer);
      emoji = wearer == 'owl' ? '🦉' : '🦊';
    }
    final pic = img != null
        ? RawImage(image: img, width: size, height: size, fit: BoxFit.contain)
        : SizedBox(width: size, height: size, child: FittedBox(child: Text(emoji)));
    return dressed(wearer, size, pic);
  }

  Widget _wearerTab(String w) {
    final sel = wearer == w;
    final e = w == 'owl' ? '🦉' : (w == 'fox' ? '🦊' : '🐣');
    return GestureDetector(
      onTap: () {
        Sfx.play('click');
        Buzz.tick();
        setState(() {
          wearer = w;
          popN++;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: sel ? const Color(0xFFFF6F00) : const Color(0xCCFFFFFF),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white, width: 2),
        ),
        child: Text('$e ${oT(w)}',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: sel ? Colors.white : const Color(0xFF4E342E))),
      ),
    );
  }

  Widget _slotTab(Slot s) {
    final sel = slot == s;
    final label = oT(s == Slot.back ? 'back_slot' : s.name);
    return Expanded(
      child: GestureDetector(
        onTap: () {
          Sfx.play('click');
          setState(() => slot = s);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          padding: const EdgeInsets.symmetric(vertical: 6),
          decoration: BoxDecoration(
            color: sel ? const Color(0xFF7E57C2) : const Color(0x55FFFFFF),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(label, textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Colors.white)),
        ),
      ),
    );
  }

  Widget _item(Outfit o) {
    final own = Outfits.owned.contains(o.id);
    final on = Outfits.wearing(wearer, o.slot) == o.id;
    Widget icon;
    if (o.cape != null) {
      icon = Container(
        width: 30, height: 34,
        decoration: BoxDecoration(
          color: o.cape,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(6), bottom: Radius.circular(14)),
          border: Border.all(color: Colors.white, width: 2),
        ),
      );
    } else {
      icon = Text(o.emoji, style: const TextStyle(fontSize: 32));
    }
    return GestureDetector(
      onTap: () => _tapItem(o),
      child: AnimatedScale(
        scale: on ? 1.06 : 1,
        duration: const Duration(milliseconds: 200),
        child: Container(
          width: 76, height: 80,
          decoration: BoxDecoration(
            color: on ? const Color(0xFFFFF59D) : (own ? const Color(0xFFE8F5E9) : Colors.white),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: on ? const Color(0xFFFF6F00) : (own ? const Color(0xFF43A047) : const Color(0xFFBDBDBD)),
                width: on ? 4 : 2.5),
            boxShadow: const [BoxShadow(color: Color(0x55000000), offset: Offset(0, 3), blurRadius: 3)],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            icon,
            const SizedBox(height: 2),
            Text(on ? '✅' : (own ? '👕' : '🪙 ${L.num(o.price)}'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Color(0xFFE65100))),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final charSize = min(size.height * .55, 220.0);
    return Directionality(
      textDirection: L.dir,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                colors: [Color(0xFFF48FB1), Color(0xFFCE93D8), Color(0xFF9575CD)]),
          ),
          child: SafeArea(
            child: Stack(children: [
              Row(children: [
                // المعاينة
                Expanded(
                  flex: 5,
                  child: Column(children: [
                    const SizedBox(height: 50),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final w in kWearers) _wearerTab(w)]),
                    Expanded(
                      child: Center(
                        child: AnimatedBuilder(
                          animation: _clock,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(0, sin(_clock.value * 2 * pi * 15) * 4),
                            child: child,
                          ),
                          child: Stack(alignment: Alignment.bottomCenter, children: [
                            // منصة
                            Container(
                              width: charSize * .9, height: 26,
                              decoration: BoxDecoration(
                                gradient: const RadialGradient(colors: [Color(0xFFFFF59D), Color(0x00FFF59D)]),
                                borderRadius: BorderRadius.circular(100),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: TweenAnimationBuilder<double>(
                                key: ValueKey('$wearer$popN'),
                                tween: Tween(begin: 1.15, end: 1),
                                duration: const Duration(milliseconds: 500),
                                curve: Curves.elasticOut,
                                builder: (_, v, ch) => Transform.scale(scale: v, child: ch),
                                child: _character(charSize),
                              ),
                            ),
                          ]),
                        ),
                      ),
                    ),
                  ]),
                ),
                // المتجر
                Expanded(
                  flex: 6,
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(4, 50, 8, 8),
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: const Color(0x55000000),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: Colors.white70, width: 2),
                    ),
                    child: Column(children: [
                      Row(children: [for (final s in Slot.values) _slotTab(s)]),
                      const SizedBox(height: 8),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Wrap(
                            alignment: WrapAlignment.center,
                            spacing: 8,
                            runSpacing: 8,
                            children: [for (final o in kOutfits) if (o.slot == slot) _item(o)],
                          ),
                        ),
                      ),
                    ]),
                  ),
                ),
              ]),
              // الشريط العلوي
              Positioned(
                top: 6, left: 8, right: 8,
                child: Row(children: [
                  Btn3D(
                    color: const Color(0xFF78909C), depth: 4, radius: 14,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    onTap: () => Navigator.of(context).pop(),
                    child: Text(oT('back'), style: const TextStyle(fontSize: 18)),
                  ),
                  const SizedBox(width: 12),
                  OutlinedText('👒 ${oT('title')}', size: 24, color: const Color(0xFFFFEB3B)),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(color: const Color(0xAA000000), borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Colors.white70, width: 2)),
                    child: PopIn(
                      key: ValueKey(wallet),
                      child: Text('🪙 ${L.num(wallet)}',
                          style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                    ),
                  ),
                ]),
              ),
              if (toast.isNotEmpty)
                Positioned(
                  left: 0, right: 0, bottom: 14,
                  child: IgnorePointer(child: Center(child: PopIn(
                    key: ValueKey(toastId),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(color: const Color(0xDD1A237E), borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white, width: 2)),
                      child: Text(toast, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                    ),
                  ))),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
