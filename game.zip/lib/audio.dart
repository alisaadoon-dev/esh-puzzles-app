import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'l10n.dart';

/// Sound effects, music and voice lines. Every call is safe: a missing file
/// or an audio error never crashes the game.
class Sfx {
  static bool enabled = true;
  static final Map<String, List<AudioPlayer>> _pools = {};
  static final Map<String, int> _next = {};
  static final Map<String, DateTime> _last = {};
  static AudioPlayer? _music;
  static String? _musicName;
  static AudioPlayer? _voice;
  static final Set<String> _assets = {};
  static bool _ready = false;

  static Future<void> init() async {
    if (_ready) return;
    _ready = true;
    try {
      // Let sound effects, music and voice play together.
      await AudioPlayer.global.setAudioContext(AudioContext(
        android: AudioContextAndroid(audioFocus: AndroidAudioFocus.none),
      ));
    } catch (_) {}
    try {
      final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
      _assets.addAll(manifest.listAssets());
    } catch (_) {
      try {
        final raw = await rootBundle.loadString('AssetManifest.json');
        _assets.addAll((jsonDecode(raw) as Map<String, dynamic>).keys);
      } catch (_) {}
    }
  }

  static Set<String> get assets => _assets;

  static bool has(String assetPath) => _assets.isEmpty || _assets.contains(assetPath);

  /// Plays assets/sfx/<name>.wav. [minGapMs] stops spammy repeats.
  static void play(String name, {double volume = 1.0, int minGapMs = 40}) {
    if (!enabled) return;
    final now = DateTime.now();
    final last = _last[name];
    if (last != null && now.difference(last).inMilliseconds < minGapMs) return;
    _last[name] = now;
    final path = 'sfx/$name.wav';
    if (!has('assets/$path')) return;
    try {
      final pool = _pools.putIfAbsent(name, () => List.generate(3, (_) => AudioPlayer()));
      final i = (_next[name] ?? 0) % pool.length;
      _next[name] = i + 1;
      final p = pool[i];
      p.stop().catchError((_) {});
      p.play(AssetSource(path), volume: volume).catchError((_) {});
    } catch (_) {}
  }

  static Future<void> music(String? name, {double volume = 0.45}) async {
    if (_musicName == name) return;
    _musicName = name;
    try {
      _music ??= AudioPlayer();
      await _music!.stop();
      if (name == null || !enabled) return;
      if (!has('assets/music/$name.wav')) return;
      await _music!.setReleaseMode(ReleaseMode.loop);
      await _music!.play(AssetSource('music/$name.wav'), volume: volume);
    } catch (_) {}
  }

  static Future<void> setMusicVolume(double v) async {
    try {
      await _music?.setVolume(v);
    } catch (_) {}
  }

  /// Speaks assets/voice/<lang>/<key>.wav if it was generated.
  /// Returns true when a voice file exists.
  static bool say(String key) {
    if (!enabled) return false;
    final path = 'voice/${L.lang}/$key.wav';
    if (_assets.isEmpty || !_assets.contains('assets/$path')) return false;
    try {
      _voice ??= AudioPlayer();
      _voice!.stop().catchError((_) {});
      _voice!.play(AssetSource(path), volume: 1.0).catchError((_) {});
      return true;
    } catch (_) {
      return false;
    }
  }

  static void stopAll() {
    try {
      _music?.stop();
      _voice?.stop();
    } catch (_) {}
    _musicName = null;
  }
}
