import 'package:flutter/material.dart';
import 'audio.dart';
import 'haptics.dart';

/// Chunky "3D" button with a press-down animation, strong contrast.
class Btn3D extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color color;
  final double depth;
  final EdgeInsets padding;
  final double radius;
  const Btn3D({super.key, required this.child, this.onTap, this.color = const Color(0xFFFFC107),
      this.depth = 7, this.padding = const EdgeInsets.symmetric(horizontal: 22, vertical: 12), this.radius = 20});

  @override
  State<Btn3D> createState() => _Btn3DState();
}

class _Btn3DState extends State<Btn3D> {
  bool _down = false;

  Color _shade(Color c, double k) {
    final h = HSLColor.fromColor(c);
    return h.withLightness((h.lightness * k).clamp(0.0, 1.0).toDouble()).toColor();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.color;
    final d = _down ? 2.0 : widget.depth;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) {
        setState(() => _down = false);
        Sfx.play('click');
        Buzz.tick();
        widget.onTap?.call();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 70),
        margin: EdgeInsets.only(top: widget.depth - d),
        padding: widget.padding,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(widget.radius),
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [_shade(c, 1.25), c]),
          border: Border.all(color: Colors.white.withValues(alpha: .85), width: 3),
          boxShadow: [
            BoxShadow(color: _shade(c, .55), offset: Offset(0, d), blurRadius: 0),
            BoxShadow(color: Colors.black.withValues(alpha: .35), offset: Offset(0, d + 4), blurRadius: 8),
          ],
        ),
        child: DefaultTextStyle.merge(
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22,
              shadows: [Shadow(color: Color(0x99000000), offset: Offset(0, 2), blurRadius: 2)]),
          child: Center(widthFactor: 1, heightFactor: 1, child: widget.child),
        ),
      ),
    );
  }
}

/// Text with a thick dark outline — readable on any background.
class OutlinedText extends StatelessWidget {
  final String text;
  final double size;
  final Color color;
  final Color outline;
  const OutlinedText(this.text, {super.key, this.size = 28, this.color = Colors.white, this.outline = const Color(0xFF3E2723)});

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900,
          foreground: Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = size / 5
            ..strokeJoin = StrokeJoin.round
            ..color = outline)),
      Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: color)),
    ]);
  }
}

/// Gentle looping pulse for hints.
class Pulse extends StatefulWidget {
  final Widget child;
  final double amount;
  const Pulse({super.key, required this.child, this.amount = .12});
  @override
  State<Pulse> createState() => _PulseState();
}

class _PulseState extends State<Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, child) => Transform.scale(scale: 1 + widget.amount * Curves.easeInOut.transform(_c.value), child: child),
        child: widget.child,
      );
}

/// Pops in with an overshoot.
class PopIn extends StatelessWidget {
  final Widget child;
  final int delayMs;
  const PopIn({super.key, required this.child, this.delayMs = 0});
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 520 + delayMs),
      curve: Interval(delayMs / (520 + delayMs), 1, curve: Curves.elasticOut),
      builder: (_, v, child) => Transform.scale(scale: v, child: child),
      child: child,
    );
  }
}

/// Shakes horizontally when [shakeKey] changes.
class ShakeOnChange extends StatelessWidget {
  final Object? shakeKey;
  final Widget child;
  const ShakeOnChange({super.key, required this.shakeKey, required this.child});
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      key: ValueKey(shakeKey),
      tween: Tween(begin: 1, end: 0),
      duration: const Duration(milliseconds: 420),
      builder: (_, v, child) {
        final dx = shakeKey == null ? 0.0 : 14 * v * (((v * 20).floor().isEven) ? 1 : -1);
        return Transform.translate(offset: Offset(dx, 0), child: child);
      },
      child: child,
    );
  }
}
