// lib/pet.dart
// الحيوان الأليف: بيضة تفقس بالفوز بالمغامرة، ثم يكبر بالأكل الذي يُشترى بالعملات.
// نوع الأكل يحدد شكله النهائي (غابة / بحر / سحر)، وهو تفاعلي باللمس.

import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'audio.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'sprites.dart';
import 'outfits.dart' show dressed, Outfits, Slot;

// ───────────── الإعدادات ─────────────

/// نقاط الخبرة لكل مرحلة: بيضة، صغير، يافع، كبير، أسطوري
const kStageXp = [0, 30, 100, 220, 400];

/// أقصى عدد وجبات في اليوم
const kDailyFeedLimit = 10;

/// أسماء صور الحيوان (اختيارية) في assets/images على خلفية خضراء
const kPetSpriteNames = [
  'pet_baby',
  'pet_forest_2', 'pet_forest_3', 'pet_forest_4',
  'pet_sea_2', 'pet_sea_3', 'pet_sea_4',
  'pet_magic_2', 'pet_magic_3', 'pet_magic_4',
];

enum PetForm { none, forest, sea, magic }

enum FoodType { fruit, fish, sweet, golden }

enum Mood {
  idle, happy, giggle, purr, hug, dizzy, hungry, eating, yuck,
  sleeping, playing, held, flying, evolving,
}

class Food {
  final FoodType type;
  final String emoji;
  final int price;
  final int xp;
  const Food(this.type, this.emoji, this.price, this.xp);
}

const kFoods = [
  Food(FoodType.fruit, '🍎', 5, 10),
  Food(FoodType.fish, '🐟', 5, 10),
  Food(FoodType.sweet, '🍭', 5, 10),
  Food(FoodType.golden, '🌟', 0, 50), // تُكسب فقط بجمع البيضات الثلاث
];

const kFavorite = {
  PetForm.forest: FoodType.fruit,
  PetForm.sea: FoodType.fish,
  PetForm.magic: FoodType.sweet,
};

const kDislike = {
  PetForm.forest: FoodType.fish,
  PetForm.sea: FoodType.sweet,
  PetForm.magic: FoodType.fruit,
};

const _strings = {
  'ar': {
    's0': 'بيضة', 's1': 'صغير', 's2': 'يافع', 's3': 'كبير', 's4': 'أسطوري',
    'feeds': 'وجبات اليوم',
    'noCoins': 'ما عندك عملات كافية! العب المغامرة واجمع العملات',
    'full': 'شبعَ اليوم! عُد غداً 😴',
    'egg': 'البيضة لا تأكل… انتصر في المغامرة لتفقس!',
    'yuck': 'لا يحب هذا الأكل!',
    'noGolden': 'اجمع البيضات الثلاث في المغامرة لتربح الثمرة الذهبية',
    'evolved': 'تطوّر!',
    'nameTitle': 'سمِّ صديقك الجديد',
    'ok': 'تم',
    'defaultName': 'بندق',
    'pet': 'صديقي',
  },
  'en': {
    's0': 'Egg', 's1': 'Baby', 's2': 'Young', 's3': 'Grown', 's4': 'Legendary',
    'feeds': 'Meals today',
    'noCoins': 'Not enough coins! Play the adventure to collect more',
    'full': 'Full for today! Come back tomorrow 😴',
    'egg': 'Eggs don\'t eat… win the adventure to hatch it!',
    'yuck': 'It doesn\'t like that!',
    'noGolden': 'Find all 3 eggs in the adventure to win a golden treat',
    'evolved': 'Evolved!',
    'nameTitle': 'Name your new friend',
    'ok': 'OK',
    'defaultName': 'Peanut',
    'pet': 'My pet',
  },
  'fr': {
    's0': 'Œuf', 's1': 'Bébé', 's2': 'Jeune', 's3': 'Grand', 's4': 'Légendaire',
    'feeds': 'Repas du jour',
    'noCoins': 'Pas assez de pièces ! Joue l\'aventure pour en gagner',
    'full': 'Rassasié ! Reviens demain 😴',
    'egg': 'Un œuf ne mange pas… gagne l\'aventure pour l\'éclore !',
    'yuck': 'Il n\'aime pas ça !',
    'noGolden': 'Trouve les 3 œufs dans l\'aventure pour un trésor doré',
    'evolved': 'Évolution !',
    'nameTitle': 'Nomme ton nouvel ami',
    'ok': 'OK',
    'defaultName': 'Noisette',
    'pet': 'Mon ami',
  },
};

String petT(String k) => (_strings[L.lang] ?? _strings['ar']!)[k] ?? k;

// ───────────── حفظ البيانات ─────────────

class PetStore {
  int xp = 0, fruit = 0, fish = 0, sweet = 0, golden = 0, feedsToday = 0, wallet = 0;
  String name = '', feedDay = '';
  PetForm form = PetForm.none;

  int get stage {
    var s = 0;
    for (var i = 0; i < kStageXp.length; i++) {
      if (xp >= kStageXp[i]) s = i;
    }
    return s;
  }

  double get progress {
    final s = stage;
    if (s >= kStageXp.length - 1) return 1;
    return (xp - kStageXp[s]) / (kStageXp[s + 1] - kStageXp[s]);
  }

  static String _today() => DateTime.now().toIso8601String().substring(0, 10);

  void resetDayIfNeeded() {
    if (feedDay != _today()) {
      feedDay = _today();
      feedsToday = 0;
    }
  }

  void decideForm() {
    if (form != PetForm.none || stage < 2) return;
    if (fish > fruit && fish >= sweet) {
      form = PetForm.sea;
    } else if (sweet > fruit && sweet > fish) {
      form = PetForm.magic;
    } else {
      form = PetForm.forest;
    }
  }

  static Future<PetStore> load() async {
    final sp = await SharedPreferences.getInstance();
    return PetStore()
      ..xp = sp.getInt('pet_xp') ?? 0
      ..fruit = sp.getInt('pet_fruit') ?? 0
      ..fish = sp.getInt('pet_fish') ?? 0
      ..sweet = sp.getInt('pet_sweet') ?? 0
      ..golden = sp.getInt('pet_golden') ?? 0
      ..feedsToday = sp.getInt('pet_feeds') ?? 0
      ..wallet = sp.getInt('pet_wallet') ?? 20
      ..feedDay = sp.getString('pet_day') ?? ''
      ..name = sp.getString('pet_name') ?? ''
      ..form = PetForm.values[sp.getInt('pet_form') ?? 0];
  }

  Future<void> save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('pet_xp', xp);
    await sp.setInt('pet_fruit', fruit);
    await sp.setInt('pet_fish', fish);
    await sp.setInt('pet_sweet', sweet);
    await sp.setInt('pet_golden', golden);
    await sp.setInt('pet_feeds', feedsToday);
    await sp.setInt('pet_wallet', wallet);
    await sp.setString('pet_day', feedDay);
    await sp.setString('pet_name', name);
    await sp.setInt('pet_form', form.index);
  }

  /// تُستدعى عند الانتصار في المغامرة: تحفظ العملات، وتدفّئ البيضة،
  /// وتعطي ثمرة ذهبية إذا جمع الطفل البيضات الثلاث.
  static Future<void> onAdventureWon({required int coins, required bool allEggs}) async {
    try {
      final p = await load();
      p.wallet += coins;
      p.xp += p.stage == 0 ? 10 : 2;
      if (allEggs) p.golden++;
      p.decideForm();
      await p.save();
    } catch (_) {}
  }
}

// ───────────── زر الحيوان في القائمة ─────────────

class PetButton extends StatelessWidget {
  final VoidCallback? onClosed;
  const PetButton({super.key, this.onClosed});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      iconSize: 40,
      icon: const Text('🥚', style: TextStyle(fontSize: 34)),
      onPressed: () {
        Sfx.play('click');
        Buzz.tick();
        Navigator.of(context)
            .push(MaterialPageRoute<void>(builder: (_) => const PetScreen()))
            .then((_) => onClosed?.call());
      },
    );
  }
}

// ───────────── شاشة الحيوان ─────────────

class PetScreen extends StatefulWidget {
  const PetScreen({super.key});
  @override
  State<PetScreen> createState() => _PetScreenState();
}

class _Particle {
  final String e;
  Offset p, v;
  final double born, life, size;
  _Particle(this.e, this.p, this.v, this.born, this.life, this.size);
}

class _PetScreenState extends State<PetScreen> with SingleTickerProviderStateMixin {
  PetStore? pet;
  late final Ticker _ticker;
  final rnd = Random();

  double t = 0, _last = 0;
  Mood mood = Mood.idle;
  double moodStart = 0, moodEnd = 0;

  Offset petPos = Offset.zero, vel = Offset.zero;
  Offset _startPos = Offset.zero, _panStart = Offset.zero;
  bool dragging = false, flying = false, lifted = false;
  double pathLen = 0, lastTouch = 0, petSize = 120;
  final List<double> taps = [];
  final List<_Particle> parts = [];
  Size area = Size.zero;
  String toast = '';
  double toastEnd = 0;
  String toy = '⚽';

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
    PetStore.load().then((p) {
      if (!mounted) return;
      p.resetDayIfNeeded();
      setState(() => pet = p);
      if (p.stage >= 1 && p.name.isEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _hatch());
      }
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  bool get isNight {
    final h = DateTime.now().hour;
    return h >= 21 || h < 6;
  }

  Mood get restMood => isNight ? Mood.sleeping : Mood.idle;

  void _setMood(Mood m, double secs) {
    mood = m;
    moodStart = t;
    moodEnd = t + secs;
  }

  void _say(String key) {
    toast = petT(key);
    toastEnd = t + 2.8;
  }

  void _touch() => lastTouch = t;
  Offset get _center => Offset(area.width / 2, area.height / 2) + petPos;

  void _burst(String e, int n, {double speed = 120, double up = -80}) {
    for (var i = 0; i < n; i++) {
      final a = rnd.nextDouble() * 2 * pi;
      final s = speed * (0.5 + rnd.nextDouble());
      parts.add(_Particle(e, _center, Offset(cos(a) * s, sin(a) * s + up), t,
          1.0 + rnd.nextDouble(), 18 + rnd.nextDouble() * 16));
    }
  }

  // ───── كل إطار ─────
  void _onTick(Duration d) {
    final now = d.inMicroseconds / 1e6;
    final dt = (now - _last).clamp(0.0, 0.05).toDouble();
    _last = now;
    t = now;

    if (!dragging && petPos != Offset.zero) {
      if (flying) {
        petPos += vel * dt;
        vel = vel * pow(0.15, dt).toDouble();
        final hx = max(10.0, area.width / 2 - petSize / 2);
        final hy = max(10.0, area.height / 2 - petSize / 2);
        if (petPos.dx.abs() > hx) {
          petPos = Offset(petPos.dx.sign * hx, petPos.dy);
          vel = Offset(-vel.dx * 0.7, vel.dy);
          Sfx.play('land');
          Buzz.land();
        }
        if (petPos.dy.abs() > hy) {
          petPos = Offset(petPos.dx, petPos.dy.sign * hy);
          vel = Offset(vel.dx, -vel.dy * 0.7);
          Sfx.play('land');
          Buzz.land();
        }
        if (vel.distance < 80) {
          flying = false;
          _setMood(Mood.dizzy, 2.5);
          Sfx.play('stomp');
        }
      } else {
        petPos = Offset.lerp(petPos, Offset.zero, (dt * 6).clamp(0.0, 1.0).toDouble())!;
        if (petPos.distance < 0.5) petPos = Offset.zero;
      }
    }

    for (final p in parts) {
      p.p += p.v * dt;
      p.v = Offset(p.v.dx * 0.97, p.v.dy + 60 * dt);
    }
    parts.removeWhere((p) => t - p.born > p.life);

    if ((moodEnd == 0 || t > moodEnd) && !flying) {
      mood = restMood;
      moodEnd = 0;
    }

    if (mood == Mood.idle && pet != null && pet!.stage > 0 &&
        t - lastTouch > 8 && rnd.nextDouble() < dt * 0.3) {
      toy = rnd.nextBool() ? '⚽' : '🦋';
      _setMood(Mood.playing, 4);
    }

    if (mounted) setState(() {});
  }

  // ───── اللمس ─────
  void _onTap() {
    _touch();
    taps.add(t);
    taps.removeWhere((x) => t - x > 1.0);
    if (pet!.stage == 0) {
      _setMood(Mood.happy, 0.6);
      Sfx.play('egg');
      Buzz.tick();
      return;
    }
    if (taps.length >= 4) {
      _setMood(Mood.giggle, 1.5);
      Sfx.play('magic');
      Buzz.magic();
      _burst('😂', 2);
    } else {
      _setMood(Mood.happy, 0.7);
      Sfx.play('jump');
      Buzz.jump();
      _burst('⭐', 3);
    }
  }

  void _onLongPress() {
    _touch();
    _setMood(Mood.hug, 2);
    Sfx.play('correct');
    Buzz.heartbeat();
    _burst('💖', 7, speed: 80, up: -120);
  }

  void _onPanStart(DragStartDetails d) {
    _touch();
    dragging = true;
    lifted = false;
    flying = false;
    pathLen = 0;
    _panStart = d.globalPosition;
    _startPos = petPos;
    vel = Offset.zero;
  }

  void _onPanUpdate(DragUpdateDetails d) {
    _touch();
    pathLen += d.delta.distance;
    final net = d.globalPosition - _panStart;
    if (lifted || net.distance > 70) {
      if (!lifted) {
        lifted = true;
        _setMood(Mood.held, 60);
        Sfx.play('slide');
      }
      petPos = _startPos + net;
    } else if (pathLen > 220 && pet!.stage > 0) {
      if (mood != Mood.purr) {
        _setMood(Mood.purr, 2);
        Sfx.play('magic');
        Buzz.tick();
        _burst('🎵', 2, speed: 60);
      } else {
        moodEnd = t + 1.2;
      }
    }
  }

  void _onPanEnd(DragEndDetails d) {
    dragging = false;
    if (!lifted) return;
    final v = d.velocity.pixelsPerSecond;
    if (v.distance > 900) {
      vel = v;
      flying = true;
      _setMood(Mood.flying, 10);
      Sfx.play('whoosh');
      Buzz.dash();
    } else {
      _setMood(Mood.happy, 0.6);
    }
  }

  // ───── الأكل ─────
  void _feed(Food f) {
    final p = pet!;
    _touch();
    p.resetDayIfNeeded();

    if (p.stage == 0) {
      _say('egg');
      Sfx.play('wrong');
      _setMood(Mood.happy, 0.6);
      return;
    }
    if (p.feedsToday >= kDailyFeedLimit) {
      _say('full');
      _setMood(Mood.purr, 1.5);
      return;
    }
    if (f.type == FoodType.golden) {
      if (p.golden <= 0) {
        _say('noGolden');
        Sfx.play('wrong');
        return;
      }
      p.golden--;
    } else {
      if (p.form != PetForm.none && kDislike[p.form] == f.type) {
        _say('yuck');
        Sfx.play('wrong');
        Buzz.wrong();
        _setMood(Mood.yuck, 1.5);
        return;
      }
      if (p.wallet < f.price) {
        _say('noCoins');
        Sfx.play('wrong');
        Buzz.wrong();
        return;
      }
      p.wallet -= f.price;
      if (f.type == FoodType.fruit) p.fruit++;
      if (f.type == FoodType.fish) p.fish++;
      if (f.type == FoodType.sweet) p.sweet++;
    }

    final fav = p.form != PetForm.none && kFavorite[p.form] == f.type;
    final before = p.stage;
    p.feedsToday++;
    p.xp += f.xp + (fav ? 5 : 0);
    p.decideForm();
    p.save();

    Sfx.play(fav ? 'correct' : 'coin');
    Buzz.coin();
    _setMood(Mood.eating, 1.2);
    _burst(fav ? '🎶' : '✨', fav ? 5 : 3, speed: 70);

    if (p.stage > before) {
      Future.delayed(const Duration(milliseconds: 1200), _evolve);
    }
  }

  void _evolve() {
    if (!mounted) return;
    _setMood(Mood.evolving, 2.5);
    Sfx.play('win');
    Buzz.win();
    _burst('🎉', 12, speed: 260);
    _burst('✨', 15, speed: 200);
    toast = '${petT('evolved')} 🎉  ${petT('s${pet!.stage}')}';
    toastEnd = t + 3;
  }

  Future<void> _hatch() async {
    _setMood(Mood.evolving, 2.5);
    Sfx.play('egg');
    Sfx.play('win');
    Buzz.win();
    _burst('🎉', 15, speed: 260);
    _burst('🥚', 4, speed: 150);
    await Future.delayed(const Duration(milliseconds: 2600));
    if (!mounted) return;
    final c = TextEditingController(text: petT('defaultName'));
    final name = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Directionality(
        textDirection: L.dir,
        child: AlertDialog(
          title: Text(petT('nameTitle')),
          content: TextField(controller: c, maxLength: 12, autofocus: true),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, c.text.trim()),
              child: Text(petT('ok')),
            ),
          ],
        ),
      ),
    );
    pet!.name = (name == null || name.isEmpty) ? petT('defaultName') : name;
    await pet!.save();
  }

  // ───── الرسم ─────
  String _emoji() {
    final p = pet!;
    if (p.stage == 0) return '🥚';
    if (p.stage == 1) return '🐣';
    final i = p.stage - 2;
    switch (p.form) {
      case PetForm.forest:
        return ['🦎', '🐊', '🐉'][i];
      case PetForm.sea:
        return ['🐠', '🐬', '🐋'][i];
      case PetForm.magic:
        return '🦄';
      case PetForm.none:
        return '🐥';
    }
  }

  ui.Image? _sprite() {
    final p = pet!;
    if (p.stage == 0) return Sprites.get('egg');
    if (p.stage == 1 || p.form == PetForm.none) return Sprites.get('pet_baby');
    return Sprites.get('pet_${p.form.name}_${p.stage}');
  }

  Widget _petImage(double size) {
    final img = _sprite();
    if (img != null) {
      return RawImage(image: img, width: size, height: size, fit: BoxFit.contain);
    }
    return Text(_emoji(), style: TextStyle(fontSize: size * 0.75));
  }

  static const _bubbles = {
    Mood.purr: '😌',
    Mood.hug: '🥰',
    Mood.hungry: '😋',
    Mood.eating: '😋',
    Mood.yuck: '🤢',
    Mood.sleeping: '💤',
    Mood.giggle: '😆',
    Mood.held: '😮',
  };

  Widget _petView(double size) {
    final p = pet!;
    final ph = moodEnd > moodStart
        ? ((t - moodStart) / (moodEnd - moodStart)).clamp(0.0, 1.0).toDouble()
        : 0.0;
    double dx = 0, dy = 0, rot = 0, sx = 1, sy = 1;
    final breath = sin(t * 2 * pi * (mood == Mood.sleeping ? 0.3 : 0.8));
    sy += 0.03 * breath;
    sx -= 0.015 * breath;

    switch (mood) {
      case Mood.happy:
        dy = -45 * sin(ph * pi);
        break;
      case Mood.giggle:
        rot = 0.18 * sin(t * 40);
        dy = -8 * sin(t * 20).abs();
        break;
      case Mood.purr:
        rot = 0.06 * sin(t * 5);
        sx *= 1.05;
        break;
      case Mood.hug:
        sx *= 1.15;
        sy *= 1.15;
        break;
      case Mood.dizzy:
        rot = 0.25 * sin(t * 7);
        break;
      case Mood.hungry:
        sy *= 1.06;
        dy = -6 * sin(t * 10).abs();
        break;
      case Mood.eating:
        sy *= 1 + 0.1 * sin(t * 25);
        sx *= 1 - 0.05 * sin(t * 25);
        break;
      case Mood.yuck:
        dx = 10 * sin(t * 50);
        break;
      case Mood.playing:
        dx = 70 * sin((t - moodStart) * 2);
        dy = -20 * sin((t - moodStart) * 4).abs();
        break;
      case Mood.held:
        rot = 0.15 * sin(t * 12);
        break;
      case Mood.flying:
        rot = t * 12;
        break;
      case Mood.evolving:
        final s = 1 + 0.4 * sin(ph * pi);
        sx *= s;
        sy *= s;
        rot = ph * 4 * pi;
        break;
      default:
        break;
    }

    final bubble = _bubbles[mood];
    return Stack(
      alignment: Alignment.center,
      clipBehavior: Clip.none,
      children: [
        if (mood == Mood.evolving)
          Container(
            width: size * 1.6,
            height: size * 1.6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [
                Colors.yellow.withValues(alpha: 0.8 * sin(ph * pi)),
                Colors.transparent,
              ]),
            ),
          ),
        Transform.translate(
          offset: Offset(dx, dy),
          child: Transform.rotate(
            angle: rot,
            child: Transform(
              alignment: Alignment.bottomCenter,
              transform: Matrix4.diagonal3Values(sx, sy, 1),
              child: dressed('pet', size, _petImage(size)),
            ),
          ),
        ),
        if (p.stage == 4 && Outfits.wearing('pet', Slot.head) == null)
          Transform.translate(
            offset: Offset(dx, dy - size / 2 - 8),
            child: const Text('👑', style: TextStyle(fontSize: 28)),
          ),
        if (bubble != null)
          Transform.translate(
            offset: Offset(dx + size / 2, dy - size / 2),
            child: Text(bubble, style: const TextStyle(fontSize: 30)),
          ),
        if (mood == Mood.dizzy)
          for (var i = 0; i < 3; i++)
            Transform.translate(
              offset: Offset(cos(t * 5 + i * 2.09) * 40,
                  -size / 2 - 5 + sin(t * 5 + i * 2.09) * 10),
              child: const Text('💫', style: TextStyle(fontSize: 22)),
            ),
        if (mood == Mood.playing)
          Transform.translate(
            offset: toy == '⚽'
                ? Offset(dx + 55, size / 2 - 15 - 40 * sin(t * 6).abs())
                : Offset(dx + 50 * cos(t * 3), -size / 2 + 20 * sin(t * 6)),
            child: Text(toy, style: const TextStyle(fontSize: 28)),
          ),
      ],
    );
  }

  Widget _foodChip(Food f) {
    final p = pet!;
    final label = f.type == FoodType.golden ? '×${L.num(p.golden)}' : '🪙${L.num(f.price)}';
    final chip = Container(
      width: 74,
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 4))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(f.emoji, style: const TextStyle(fontSize: 32)),
        Text(label, style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF4E342E))),
      ]),
    );
    return Draggable<Food>(
      data: f,
      feedback: Material(
        color: Colors.transparent,
        child: Text(f.emoji, style: const TextStyle(fontSize: 54)),
      ),
      childWhenDragging: Opacity(opacity: 0.3, child: chip),
      child: chip,
    );
  }

  Widget _sidePanel(PetStore p) {
    const white = TextStyle(color: Colors.white, fontWeight: FontWeight.w900);
    return Container(
      width: 210,
      color: Colors.black.withValues(alpha: 0.15),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Column(children: [
        Row(children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 30),
            onPressed: () {
              Sfx.play('click');
              Navigator.maybePop(context);
            },
          ),
          Expanded(
            child: Text(p.name.isEmpty ? petT('pet') : p.name,
                overflow: TextOverflow.ellipsis, style: white.copyWith(fontSize: 20)),
          ),
        ]),
        Text(petT('s${p.stage}'), style: white.copyWith(fontSize: 16, color: const Color(0xFFFFEB3B))),
        const SizedBox(height: 4),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: p.progress,
            minHeight: 10,
            backgroundColor: Colors.white30,
            valueColor: const AlwaysStoppedAnimation(Colors.amber),
          ),
        ),
        const SizedBox(height: 4),
        Text('${petT('feeds')}: ${L.num(p.feedsToday)}/${L.num(kDailyFeedLimit)}', style: white),
        Text('🪙 ${L.num(p.wallet)}', style: white.copyWith(fontSize: 22)),
        const SizedBox(height: 6),
        Expanded(
          child: Center(
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: [for (final f in kFoods) _foodChip(f)],
            ),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = pet;
    final night = isNight;
    return Directionality(
      textDirection: L.dir,
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: night
                  ? const [Color(0xFF0B1A4A), Color(0xFF2C3E8F)]
                  : const [Color(0xFF4FC3F7), Color(0xFF81C784), Color(0xFF388E3C)],
            ),
          ),
          child: SafeArea(
            child: p == null
                ? const Center(child: CircularProgressIndicator())
                : Row(children: [
                    Expanded(
                      child: LayoutBuilder(builder: (context, c) {
                        area = Size(c.maxWidth, c.maxHeight);
                        petSize = min(110.0 + p.stage * 22, area.height * 0.5);
                        final center = _center;
                        final w = petSize + 120, h = petSize + 120;
                        return Stack(clipBehavior: Clip.none, children: [
                          if (night)
                            const Positioned(top: 10, left: 20, child: Text('🌙', style: TextStyle(fontSize: 40))),
                          Positioned(
                            left: center.dx - w / 2,
                            top: center.dy - h / 2,
                            width: w,
                            height: h,
                            child: DragTarget<Food>(
                              onWillAcceptWithDetails: (_) {
                                _touch();
                                if (p.stage > 0) _setMood(Mood.hungry, 30);
                                return true;
                              },
                              onLeave: (_) {
                                if (mood == Mood.hungry) moodEnd = t;
                              },
                              onAcceptWithDetails: (d) => _feed(d.data),
                              builder: (context, _, __) => GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: _onTap,
                                onLongPress: _onLongPress,
                                onPanStart: _onPanStart,
                                onPanUpdate: _onPanUpdate,
                                onPanEnd: _onPanEnd,
                                child: Center(child: _petView(petSize)),
                              ),
                            ),
                          ),
                          for (final q in parts)
                            Positioned(
                              left: q.p.dx - q.size / 2,
                              top: q.p.dy - q.size / 2,
                              child: IgnorePointer(
                                child: Opacity(
                                  opacity: (1 - (t - q.born) / q.life).clamp(0.0, 1.0).toDouble(),
                                  child: Text(q.e, style: TextStyle(fontSize: q.size)),
                                ),
                              ),
                            ),
                          if (t < toastEnd)
                            Positioned(
                              top: 8,
                              left: 16,
                              right: 16,
                              child: IgnorePointer(
                                child: Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Text(toast,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                                ),
                              ),
                            ),
                        ]);
                      }),
                    ),
                    _sidePanel(p),
                  ]),
          ),
        ),
      ),
    );
  }
}
