import 'dart:math';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'engine.dart';
import 'outfits.dart';
import 'sprites.dart';

final Map<String, TextPainter> _tpCache = {};

TextPainter textPainter(String s, double size, Color color, {bool bold = true, Color? stroke}) {
  final key = '$s|$size|${color.toARGB32()}|$bold|${stroke?.toARGB32()}';
  final hit = _tpCache[key];
  if (hit != null) return hit;
  if (_tpCache.length > 300) _tpCache.clear();
  final style = TextStyle(
    fontSize: size,
    fontWeight: bold ? FontWeight.w900 : FontWeight.w500,
    color: stroke == null ? color : null,
    foreground: stroke == null ? null : (Paint()..color = color),
    shadows: const [Shadow(color: Color(0x99000000), blurRadius: 4, offset: Offset(0, 2))],
  );
  final tp = TextPainter(text: TextSpan(text: s, style: style), textDirection: TextDirection.rtl, textAlign: TextAlign.center)
    ..layout();
  _tpCache[key] = tp;
  return tp;
}

void drawText(Canvas c, String s, Offset center, double size, Color color) {
  final tp = textPainter(s, size, color);
  tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
}

class GamePainter extends CustomPainter {
  final Engine e;
  final List<Offset> stroke;
  GamePainter(this.e, this.stroke) : super(repaint: e);

  final Paint _p = Paint();

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.height / kViewH;
    e.viewW = size.width / scale;
    final t = e.time;

    canvas.save();
    // screen shake (trauma²) and zoom punch
    final sh = e.trauma * e.trauma * 18 * scale;
    final shx = sh * (sin(t * 67.3) + sin(t * 41.1)) / 2;
    final shy = sh * (sin(t * 59.7 + 1) + sin(t * 37.9)) / 2;
    canvas.translate(size.width / 2 + shx, size.height / 2 + shy);
    canvas.scale(e.zoom);
    canvas.translate(-size.width / 2, -size.height / 2);
    canvas.scale(scale);

    _sky(canvas);
    _parallax(canvas);

    canvas.save();
    canvas.translate(-e.camX, 0);
    _ground(canvas);
    for (final pl in e.plats) { _platform(canvas, pl.r); }
    for (final b in e.bridges) { _bridge(canvas, b); }
    _nest(canvas);
    for (final g in e.gates) { _gate(canvas, g); }
    for (final r in e.rocks) { _rock(canvas, r.r); }
    for (final b in e.branches) { _branch(canvas, b); }
    for (final c in e.crates) { if (!c.broken) _crate(canvas, c.r); }
    for (final c in e.coinList) { if (!c.taken) _coin(canvas, c.x, c.y + sin(t * 4 + c.bob) * 4, t + c.bob); }
    for (final egg in e.eggs) { if (!egg.taken && !egg.hidden) _egg(canvas, egg.x, egg.y + (egg.vy == 0 ? sin(t * 3) * 5 : 0.0), 1); }
    for (final h in e.hogs) { _hog(canvas, h); }
    _hero(canvas);
    if (e.chasing || e.boulderX > 0 && e.gates.any((g) => g.chase && g.state == 3) && e.boulderX + 400 > e.camX) {
      _boulder(canvas);
    }
    if (e.crowOn) _crow(canvas, e.crowX, e.crowY);
    _particles(canvas, false);
    for (final ft in e.texts) {
      final tp = textPainter(ft.text, ft.size, ft.color.withValues(alpha: ft.life.clamp(0.0, 1.0).toDouble()));
      tp.paint(canvas, Offset(ft.x - tp.width / 2, ft.y - tp.height / 2));
    }
    // drawing guide
    if (e.mode == Mode.drawBridge) {
      final b = e.bridges.first;
      _dashed(canvas, Offset(b.x0 - 10, kGroundY - 4), Offset(b.x1 + 10, kGroundY - 4), const Color(0xCCFFFFFF), 6);
    }
    if (e.mode == Mode.drawShield) {
      _dashedCircle(canvas, Offset(e.p.x, e.p.y - 30), 60, const Color(0xCC80D8FF));
    }
    canvas.restore();

    _foreground(canvas);
    canvas.restore();

    // screen-space overlays (real pixels)
    _particlesScreen(canvas, scale);
    if (e.timeScale < .7) {
      final k = ((.7 - e.timeScale) / .7).clamp(0.0, 1.0).toDouble();
      final rect = Offset.zero & size;
      _p.shader = ui.Gradient.radial(rect.center, size.longestSide * .6,
          [const Color(0x00000000), Color.fromRGBO(10, 20, 60, .55 * k)], [.55, 1]);
      canvas.drawRect(rect, _p);
      _p.shader = null;
    }
    if (e.chasing) {
      final rect = Offset.zero & size;
      final pulse = .18 + .08 * sin(t * 8);
      _p.shader = ui.Gradient.linear(Offset.zero, Offset(size.width * .35, 0),
          [Color.fromRGBO(200, 30, 0, pulse), const Color(0x00000000)]);
      canvas.drawRect(rect, _p);
      _p.shader = null;
    }
    if (e.flash > 0) {
      canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white.withValues(alpha: e.flash.clamp(0.0, 1.0).toDouble()));
    }
    // finger stroke
    if (stroke.length > 1) {
      final path = Path()..moveTo(stroke.first.dx, stroke.first.dy);
      for (final o in stroke.skip(1)) { path.lineTo(o.dx, o.dy); }
      canvas.drawPath(path, Paint()
        ..color = const Color(0x66FFF59D)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 26
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));
      canvas.drawPath(path, Paint()
        ..color = Colors.white
        ..style = PaintingStyle.stroke
        ..strokeWidth = 9
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round);
    }
  }

  // ---------- background ----------
  void _sky(Canvas c) {
    final w = e.viewW;
    final chase = e.chasing;
    final top = chase ? const Color(0xFFFF8A65) : const Color(0xFF4FC3F7);
    final bottom = chase ? const Color(0xFFFFE0B2) : const Color(0xFFE1F5FE);
    _p.shader = ui.Gradient.linear(Offset.zero, const Offset(0, kViewH), [top, bottom]);
    c.drawRect(Rect.fromLTWH(-40, -40, w + 80, kViewH + 80), _p);
    _p.shader = null;
    // sun with rays
    final sunPos = Offset(w * .82, 62);
    _p.color = const Color(0x33FFF59D);
    for (var i = 0; i < 3; i++) { c.drawCircle(sunPos, 44.0 + i * 16 + sin(e.time * 2 + i) * 3, _p); }
    _p.color = const Color(0xFFFFEE58);
    c.drawCircle(sunPos, 34, _p);
    // clouds
    _p.color = const Color(0xEEFFFFFF);
    for (var i = 0; i < 6; i++) {
      final x = ((i * 260 - e.camX * .08 - e.time * 8) % (w + 300)) - 150;
      final y = 40.0 + (i * 37) % 80;
      c.drawOval(Rect.fromCenter(center: Offset(x, y), width: 110, height: 34), _p);
      c.drawCircle(Offset(x - 18, y - 12), 22, _p);
      c.drawCircle(Offset(x + 16, y - 16), 26, _p);
    }
  }

  void _parallax(Canvas c) {
    final w = e.viewW;
    // far mountains
    _layer(c, .18, 200, 70, 380, const Color(0xFF9FA8DA), w, snow: true);
    // hills
    _layer(c, .38, 240, 45, 220, const Color(0xFF81C784), w);
    // tree line
    final off = e.camX * .62;
    for (var i = -1; i < (w / 90).ceil() + 2; i++) {
      final wx = (off / 90).floor() * 90 + i * 90;
      final x = wx - off;
      final hgt = 80.0 + (wx * 7919 % 50).abs();
      _p.color = const Color(0xFF5D4037);
      c.drawRect(Rect.fromLTWH(x - 5, 268 - hgt * .4, 10, hgt * .4 + 10), _p);
      _p.color = const Color(0xFF388E3C);
      c.drawCircle(Offset(x, 268 - hgt * .5), 30, _p);
      _p.color = const Color(0xFF43A047);
      c.drawCircle(Offset(x - 14, 260 - hgt * .4), 22, _p);
      c.drawCircle(Offset(x + 15, 258 - hgt * .45), 24, _p);
    }
  }

  void _layer(Canvas c, double factor, double base, double amp, double wave, Color color, double w, {bool snow = false}) {
    final off = e.camX * factor;
    final path = Path()..moveTo(-20, kViewH);
    for (double x = -20; x <= w + 20; x += 10) {
      final wx = x + off;
      final y = base - amp * (sin(wx / wave) * .6 + sin(wx / (wave * .37) + 1.3) * .4).abs();
      path.lineTo(x, y);
    }
    path.lineTo(w + 20, kViewH);
    path.close();
    _p.color = color;
    c.drawPath(path, _p);
    if (snow) {
      _p.color = const Color(0x44FFFFFF);
      c.drawPath(path, _p..maskFilter = const MaskFilter.blur(BlurStyle.inner, 6));
      _p.maskFilter = null;
    }
  }

  void _foreground(Canvas c) {
    final off = e.camX * 1.3;
    _p.color = const Color(0xCC2E7D32);
    for (var i = -1; i < (e.viewW / 260).ceil() + 2; i++) {
      final wx = (off / 260).floor() * 260 + i * 260;
      final x = wx - off;
      if ((wx ~/ 260) % 3 == 0) continue;
      c.drawCircle(Offset(x, kViewH + 6), 34, _p);
      c.drawCircle(Offset(x + 30, kViewH + 14), 28, _p);
    }
  }

  // ---------- world ----------
  void _ground(Canvas c) {
    final l = e.camX - 50, r = e.camX + e.viewW + 50;
    // chasm darkness
    _p.shader = ui.Gradient.linear(const Offset(0, kGroundY), const Offset(0, kViewH), [const Color(0xFF3E2723), const Color(0xFF0D0605)]);
    c.drawRect(Rect.fromLTRB(l, kGroundY + 10, r, kViewH + 40), _p);
    _p.shader = null;
    for (final s in e.ground) {
      if (s.x1 < l || s.x0 > r) continue;
      final rect = Rect.fromLTRB(max(s.x0, l), kGroundY, min(s.x1, r), kViewH + 40);
      _p.shader = ui.Gradient.linear(const Offset(0, kGroundY), const Offset(0, kViewH), [const Color(0xFF8D6E63), const Color(0xFF5D4037)]);
      c.drawRect(rect, _p);
      _p.shader = null;
      // stones in dirt
      _p.color = const Color(0x336D4C41);
      for (double x = (rect.left / 70).floor() * 70.0; x < rect.right; x += 70) {
        c.drawOval(Rect.fromCenter(center: Offset(x + 20, kGroundY + 30 + (x % 3) * 8), width: 22, height: 10), _p);
      }
      // grass
      _p.color = const Color(0xFF66BB6A);
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTRB(rect.left, kGroundY - 6, rect.right, kGroundY + 12), const Radius.circular(6)), _p);
      _p.color = const Color(0xFF81C784);
      for (double x = (rect.left / 14).floor() * 14.0; x < rect.right; x += 14) {
        final sway = sin(e.time * 3 + x * .1) * 2;
        final path = Path()
          ..moveTo(x, kGroundY - 4)
          ..lineTo(x + 4 + sway, kGroundY - 13)
          ..lineTo(x + 8, kGroundY - 4)
          ..close();
        c.drawPath(path, _p);
      }
    }
  }

  void _platform(Canvas c, Rect r) {
    _p.color = const Color(0xFF6D4C41);
    c.drawRRect(RRect.fromRectAndRadius(r.inflate(1), const Radius.circular(8)), _p);
    _p.color = const Color(0xFF66BB6A);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(r.left - 2, r.top - 5, r.width + 4, 10), const Radius.circular(5)), _p);
    _p.color = const Color(0xFF4E342E);
    c.drawRect(Rect.fromLTWH(r.left + 10, r.bottom, 6, 14), _p);
    c.drawRect(Rect.fromLTWH(r.right - 16, r.bottom, 6, 14), _p);
  }

  void _bridge(Canvas c, Bridge b) {
    if (b.built <= 0) return;
    final n = 10;
    final pw = (b.x1 - b.x0) / n;
    final shown = (b.built * n).ceil();
    // ropes
    _p
      ..color = const Color(0xFF8D6E63)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    c.drawLine(Offset(b.x0, kGroundY - 28), Offset(b.x0 + (b.x1 - b.x0) * b.built, kGroundY - 28), _p);
    _p.style = PaintingStyle.fill;
    for (var i = 0; i < shown; i++) {
      final drop = (i == shown - 1 && b.built < 1) ? (1 - (b.built * n - i)) * -60 : 0.0;
      _p.color = i.isEven ? const Color(0xFFBCAAA4) : const Color(0xFFA1887F);
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(b.x0 + i * pw + 1, kGroundY - 4 + drop, pw - 2, 14), const Radius.circular(3)), _p);
      _p.color = const Color(0xFF6D4C41);
      c.drawRect(Rect.fromLTWH(b.x0 + i * pw + pw / 2 - 2, kGroundY - 28 + drop, 3, 24), _p);
    }
  }

  void _coin(Canvas c, double x, double y, double t) {
    final squeeze = cos(t * 3).abs() * .7 + .3;
    _p.color = const Color(0x55FFF59D);
    c.drawCircle(Offset(x, y), 18, _p);
    _p.color = const Color(0xFFF9A825);
    c.drawOval(Rect.fromCenter(center: Offset(x, y), width: 26 * squeeze, height: 26), _p);
    _p.color = const Color(0xFFFFD54F);
    c.drawOval(Rect.fromCenter(center: Offset(x, y), width: 20 * squeeze, height: 20), _p);
    if (squeeze > .6) {
      c.save();
      c.translate(x, y);
      c.scale(squeeze, 1);
      drawText(c, '🦉', Offset.zero, 12, Colors.black);
      c.restore();
    }
  }

  void _egg(Canvas c, double x, double y, double s) {
    final img = Sprites.get('egg');
    _p.color = Color.fromRGBO(255, 235, 59, .35 + .15 * sin(e.time * 5));
    c.drawCircle(Offset(x, y), 30 * s, _p);
    if (img != null) {
      _img(c, img, Offset(x, y + 20 * s), 44 * s);
      return;
    }
    final r = Rect.fromCenter(center: Offset(x, y), width: 30 * s, height: 38 * s);
    _p.shader = ui.Gradient.radial(Offset(x - 6 * s, y - 8 * s), 26 * s, [const Color(0xFFFFFDE7), const Color(0xFFFFC107), const Color(0xFFFF8F00)], [0, .5, 1]);
    c.drawOval(r, _p);
    _p.shader = null;
    _p.color = const Color(0x88FFFFFF);
    c.drawOval(Rect.fromCenter(center: Offset(x - 6 * s, y - 9 * s), width: 7 * s, height: 11 * s), _p);
  }

  void _rock(Canvas c, Rect r) {
    final path = Path()
      ..moveTo(r.left, r.bottom)
      ..lineTo(r.left + r.width * .1, r.top + r.height * .3)
      ..lineTo(r.left + r.width * .45, r.top)
      ..lineTo(r.right - r.width * .1, r.top + r.height * .2)
      ..lineTo(r.right, r.bottom)
      ..close();
    _p.shader = ui.Gradient.linear(r.topLeft, r.bottomRight, [const Color(0xFFBDBDBD), const Color(0xFF616161)]);
    c.drawPath(path, _p);
    _p.shader = null;
    _p.color = const Color(0x55FFFFFF);
    c.drawCircle(Offset(r.left + r.width * .38, r.top + r.height * .3), 5, _p);
  }

  void _branch(Canvas c, Branch b) {
    final r = b.r;
    // hanging log with leaves
    _p.color = const Color(0xFF5D4037);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(r.left - 10, r.bottom - 26, r.width + 20, 26), const Radius.circular(13)), _p);
    _p.color = const Color(0xFF795548);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(r.left - 6, r.bottom - 22, r.width + 12, 8), const Radius.circular(4)), _p);
    _p.color = const Color(0xFF4E342E);
    c.drawRect(Rect.fromLTWH(r.left + 8, -20, 6, r.bottom - 6), _p);
    c.drawRect(Rect.fromLTWH(r.right - 14, -20, 6, r.bottom - 6), _p);
    _p.color = const Color(0xFF2E7D32);
    for (var i = 0; i < 5; i++) {
      c.drawCircle(Offset(r.left + i * r.width / 4, r.bottom - 30 + sin(e.time * 2 + i) * 2), 16, _p);
    }
    // warning stripes on the log end
    drawText(c, '⬇', Offset(r.center.dx, r.bottom + 14 + sin(e.time * 6) * 3), 16, const Color(0xFFFFEB3B));
  }

  void _crate(Canvas c, Rect r) {
    _p.color = const Color(0xFFA1887F);
    c.drawRect(r, _p);
    _p
      ..color = const Color(0xFF5D4037)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4;
    c.drawRect(r.deflate(2), _p);
    c.drawLine(r.topLeft + const Offset(4, 4), r.bottomRight - const Offset(4, 4), _p);
    c.drawLine(r.topRight + const Offset(-4, 4), r.bottomLeft + const Offset(4, -4), _p);
    _p.style = PaintingStyle.fill;
    drawText(c, '❓', r.center, 18, Colors.white);
  }

  void _gate(Canvas c, Gate g) {
    final x = g.x;
    const top = kGroundY - 190.0;
    // pillars
    for (final px in [x - 70.0, x + 30.0]) {
      _p.shader = ui.Gradient.linear(Offset(px, 0), Offset(px + 40, 0), [const Color(0xFF9E9E9E), const Color(0xFF616161)]);
      c.drawRect(Rect.fromLTWH(px, top, 40, kGroundY - top), _p);
      _p.shader = null;
    }
    // arch
    if (g.state != 2 || g.chase) {
      _p.color = const Color(0xFF757575);
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - 80, top - 26, 160, 30), const Radius.circular(10)), _p);
    }
    double doorY = 0;
    var showDoor = g.state <= 1;
    if (g.state == 3) { showDoor = true; doorY = (1 - g.drop) * -170; }
    if (showDoor) {
      final door = Rect.fromLTWH(x - 30, top + 4 + doorY, 60, kGroundY - top - 4);
      _p.color = g.chase ? const Color(0xFF6D4C41) : const Color(0xFF8D8D8D);
      c.drawRect(door, _p);
      _p
        ..color = const Color(0x55000000)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;
      for (double y = door.top + 30; y < door.bottom; y += 30) { c.drawLine(Offset(door.left, y), Offset(door.right, y), _p); }
      _p.style = PaintingStyle.fill;
      if (g.state == 0) {
        final glow = .5 + .5 * sin(e.time * 4);
        _p.color = Color.fromRGBO(0, 229, 255, .35 + .3 * glow);
        c.drawCircle(door.center, 24, _p);
        drawText(c, '❓', door.center, 26, Colors.white);
      }
      if (g.state == 1) {
        _p
          ..color = const Color(0xFF212121)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        final cracks = (g.t / .8 * 6).ceil();
        final rnd = Random(g.x.toInt());
        for (var i = 0; i < cracks; i++) {
          var o = door.center + Offset(rnd.nextDouble() * 20 - 10, rnd.nextDouble() * 40 - 20);
          final path = Path()..moveTo(o.dx, o.dy);
          for (var k = 0; k < 4; k++) {
            o += Offset(rnd.nextDouble() * 30 - 15, rnd.nextDouble() * 30 - 15);
            path.lineTo(o.dx, o.dy);
          }
          c.drawPath(path, _p);
        }
        _p.style = PaintingStyle.fill;
      }
    } else {
      // rubble
      _p.color = const Color(0xFF757575);
      for (var i = 0; i < 6; i++) {
        c.drawOval(Rect.fromCenter(center: Offset(x - 40 + i * 16.0, kGroundY - 6), width: 22, height: 14), _p);
      }
    }
  }

  void _nest(Canvas c) {
    final x = e.nestX;
    _p.color = const Color(0xFF6D4C41);
    c.drawRect(Rect.fromLTWH(x - 8, kGroundY - 120, 16, 120), _p);
    _p.color = const Color(0xFF2E7D32);
    c.drawCircle(Offset(x, kGroundY - 150), 50, _p);
    _p.color = const Color(0xFF8D6E63);
    c.drawOval(Rect.fromCenter(center: Offset(x, kGroundY - 110), width: 90, height: 34), _p);
    _p
      ..color = const Color(0xFF5D4037)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (var i = 0; i < 6; i++) {
      c.drawArc(Rect.fromCenter(center: Offset(x, kGroundY - 112 + i * 2.0), width: 86 - i * 6.0, height: 26), .2, pi - .4, false, _p);
    }
    _p.style = PaintingStyle.fill;
    final got = e.finished && e.finishT > 3.3;
    _egg(c, x, kGroundY - 132 - (got ? sin(e.time * 4).abs() * 10 : 0), got ? 1.5 : 0.0001);
  }

  void _hog(Canvas c, Hog h) {
    if (!h.alive && h.y > kViewH + 80) return;
    c.save();
    c.translate(h.x, h.y);
    if (!h.alive) c.rotate(h.deadT * 10);
    c.scale(h.dir < 0 ? 1.0 : -1.0, 1 - h.squash * .5);
    final img = Sprites.get('hedgehog');
    if (img != null) {
      _img(c, img, Offset.zero, 40);
    } else {
      _p.color = const Color(0xFF4E342E);
      for (var i = 0; i < 7; i++) {
        final a = pi + .25 + i * .42;
        final path = Path()
          ..moveTo(cos(a - .2) * 18, -12 + sin(a - .2) * 16)
          ..lineTo(cos(a) * 30, -12 + sin(a) * 28)
          ..lineTo(cos(a + .2) * 18, -12 + sin(a + .2) * 16)
          ..close();
        c.drawPath(path, _p);
      }
      _p.color = const Color(0xFF8D6E63);
      c.drawOval(const Rect.fromLTWH(-22, -28, 44, 28), _p);
      _p.color = const Color(0xFFD7CCC8);
      c.drawOval(const Rect.fromLTWH(-24, -16, 18, 14), _p);
      _p.color = Colors.black;
      c.drawCircle(const Offset(-24, -11), 3, _p);
      c.drawCircle(const Offset(-14, -18), 2.6, _p);
      _p.color = const Color(0xFF3E2723);
      final step = sin(e.time * 12) * 3;
      c.drawOval(Rect.fromLTWH(-14 + step, -4, 9, 5), _p);
      c.drawOval(Rect.fromLTWH(6 - step, -4, 9, 5), _p);
    }
    c.restore();
  }

  void _boulder(Canvas c) {
    const r = 92.0;
    final center = Offset(e.boulderX, kGroundY - r + 4);
    _p.color = const Color(0x55000000);
    c.drawOval(Rect.fromCenter(center: Offset(center.dx, kGroundY + 6), width: r * 2, height: 18), _p);
    c.save();
    c.translate(center.dx, center.dy);
    c.rotate(e.boulderRot);
    _p.shader = ui.Gradient.radial(const Offset(-30, -30), r * 1.6, [const Color(0xFFBCAAA4), const Color(0xFF6D4C41), const Color(0xFF3E2723)], [0, .6, 1]);
    c.drawCircle(Offset.zero, r, _p);
    _p.shader = null;
    _p
      ..color = const Color(0xFF3E2723)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4;
    c.drawLine(const Offset(-40, -20), const Offset(10, 10), _p);
    c.drawLine(const Offset(10, 10), const Offset(30, -30), _p);
    c.drawLine(const Offset(-20, 40), const Offset(30, 50), _p);
    _p.style = PaintingStyle.fill;
    _p.color = const Color(0x55FFFFFF);
    c.drawCircle(const Offset(-30, -40), 12, _p);
    c.restore();
    // angry eyes on the boulder (cartoon, not scary)
    _p.color = Colors.white;
    c.drawOval(Rect.fromCenter(center: center + const Offset(30, -20), width: 26, height: 20), _p);
    c.drawOval(Rect.fromCenter(center: center + const Offset(62, -14), width: 22, height: 18), _p);
    _p.color = Colors.black;
    c.drawCircle(center + const Offset(36, -18), 6, _p);
    c.drawCircle(center + const Offset(66, -12), 5, _p);
  }

  void _crow(Canvas c, double x, double y) {
    c.save();
    c.translate(x, y);
    final img = Sprites.get('crow');
    final flap = sin(e.time * 18);
    if (img != null) {
      c.scale(1, 1 + flap * .05);
      _img(c, img, const Offset(0, 30), 64);
      c.restore();
      return;
    }
    // wings
    _p.color = const Color(0xFF263238);
    for (final side in [-1.0, 1.0]) {
      final path = Path()
        ..moveTo(0, 0)
        ..lineTo(side * 46, -20 - flap * 22)
        ..lineTo(side * 34, 6 - flap * 8)
        ..close();
      c.drawPath(path, _p);
    }
    _p.color = const Color(0xFF212121);
    c.drawOval(const Rect.fromLTWH(-24, -14, 48, 30), _p);
    c.drawCircle(const Offset(-22, -12), 13, _p);
    _p.color = const Color(0xFFFFB300);
    final beak = Path()..moveTo(-33, -14)..lineTo(-50, -8)..lineTo(-33, -6)..close();
    c.drawPath(beak, _p);
    _p.color = Colors.white;
    c.drawCircle(const Offset(-25, -15), 5, _p);
    _p.color = Colors.black;
    c.drawCircle(const Offset(-26, -15), 2.6, _p);
    // cheeky eyebrow
    _p
      ..color = Colors.black
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    c.drawLine(const Offset(-31, -23), const Offset(-19, -20), _p);
    _p.style = PaintingStyle.fill;
    c.restore();
  }

  void _hero(Canvas c) {
    final p = e.p;
    if (p.invuln > 0 && (e.time * 14).floor().isEven && e.mode != Mode.win) return;
    final owl = e.hero == HeroKind.owl;
    final suffix = p.face == Face.happy ? '_happy' : (p.face == Face.sad ? '_sad' : '');
    final base = owl ? 'owl' : 'fox';
    final img = Sprites.get('$base$suffix') ?? Sprites.get(base);
    final bob = p.onGround && p.vx > 40 ? sin(p.runT * 2) * 3 : 0.0;
    final tilt = p.onGround ? 0.0 : (p.vy / 3000).clamp(-.25, .25).toDouble();

    // shadow
    _p.color = const Color(0x44000000);
    c.drawOval(Rect.fromCenter(center: Offset(p.x, kGroundY + 2), width: 44, height: 10), _p);

    c.save();
    c.translate(p.x, p.y);
    c.rotate(tilt + (p.dashT > 0 ? .15 : 0));
    final slide = p.slideT > 0 ? .55 : 1.0;
    c.scale(p.sx * (p.slideT > 0 ? 1.2 : 1.0), p.sy * slide);
    c.translate(0, -bob.abs());
    const outfitBox = Rect.fromLTWH(-37, -74, 74, 74);
    drawOutfit(c, base, outfitBox, e.time, behind: true);
    if (img != null) {
      _img(c, img, Offset.zero, 74);
    } else if (owl) {
      _owl(c, p);
    } else {
      _fox(c, p);
    }
    drawOutfit(c, base, outfitBox, e.time, behind: false);
    c.restore();

    if (e.shield) {
      final rr = 48 + sin(e.time * 10) * 3;
      _p
        ..shader = ui.Gradient.radial(Offset(p.x, p.y - 30), rr, [const Color(0x0080D8FF), const Color(0x8880D8FF), const Color(0xEEFFFFFF)], [.5, .9, 1]);
      c.drawCircle(Offset(p.x, p.y - 30), rr, _p);
      _p.shader = null;
    }
  }

  bool _blink() => (e.time % 3.2) < .12;

  void _eyes(Canvas c, Player p, double y, double gap, double r) {
    for (final dx in [-gap, gap]) {
      if (p.face == Face.happy) {
        _p
          ..color = Colors.black
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        c.drawArc(Rect.fromCenter(center: Offset(dx, y + 2), width: r * 1.6, height: r * 1.4), pi, pi, false, _p);
        _p.style = PaintingStyle.fill;
        continue;
      }
      _p.color = Colors.white;
      c.drawCircle(Offset(dx, y), r, _p);
      if (_blink()) {
        _p.color = const Color(0xFF5D4037);
        c.drawRect(Rect.fromCenter(center: Offset(dx, y), width: r * 2, height: r * 2), _p);
        _p.color = Colors.black;
        c.drawRect(Rect.fromCenter(center: Offset(dx, y), width: r * 1.8, height: 2), _p);
      } else {
        _p.color = Colors.black;
        c.drawCircle(Offset(dx + r * .25, y + (p.face == Face.sad ? r * .3 : 0)), r * .5, _p);
        _p.color = Colors.white;
        c.drawCircle(Offset(dx + r * .4, y - r * .2), r * .18, _p);
      }
      if (p.face == Face.sad) {
        _p
          ..color = Colors.black
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5;
        c.drawLine(Offset(dx - r, y - r - 2 + (dx < 0 ? 4 : 0)), Offset(dx + r, y - r - 2 + (dx < 0 ? 0 : 4)), _p);
        _p.style = PaintingStyle.fill;
      }
    }
  }

  void _owl(Canvas c, Player p) {
    final air = !p.onGround;
    final flap = air ? sin(e.time * 30) * .8 : sin(p.runT) * .15;
    _p.color = const Color(0xFF6D4C41);
    for (final side in [-1.0, 1.0]) {
      c.save();
      c.translate(side * 18, -36);
      c.rotate(side * (.3 + flap));
      c.drawOval(const Rect.fromLTWH(-6, 0, 12, 30), _p);
      c.restore();
    }
    _p.shader = ui.Gradient.linear(const Offset(0, -60), Offset.zero, [const Color(0xFFA1887F), const Color(0xFF795548)]);
    c.drawOval(const Rect.fromLTWH(-22, -60, 44, 60), _p);
    _p.shader = null;
    _p.color = const Color(0xFFD7CCC8);
    c.drawOval(const Rect.fromLTWH(-13, -34, 26, 30), _p);
    // ear tufts
    _p.color = const Color(0xFF5D4037);
    c.drawPath(Path()..moveTo(-18, -54)..lineTo(-16, -70)..lineTo(-6, -58)..close(), _p);
    c.drawPath(Path()..moveTo(18, -54)..lineTo(16, -70)..lineTo(6, -58)..close(), _p);
    _p.color = const Color(0xFFFFE0B2);
    c.drawCircle(const Offset(-9, -45), 10, _p);
    c.drawCircle(const Offset(9, -45), 10, _p);
    _eyes(c, p, -45, 9, 7);
    _p.color = const Color(0xFFFF9800);
    c.drawPath(Path()..moveTo(-4, -38)..lineTo(4, -38)..lineTo(0, -30)..close(), _p);
    _p.color = const Color(0xFFFF9800);
    final step = p.onGround ? sin(p.runT * 2) * 4 : 0.0;
    c.drawOval(Rect.fromLTWH(-12 + step, -4, 10, 5), _p);
    c.drawOval(Rect.fromLTWH(2 - step, -4, 10, 5), _p);
  }

  void _fox(Canvas c, Player p) {
    final swish = sin(e.time * 6) * .3 + (p.onGround ? 0 : -.4);
    // tail
    c.save();
    c.translate(-16, -18);
    c.rotate(-.9 + swish);
    _p.color = const Color(0xFFF57C00);
    c.drawOval(const Rect.fromLTWH(-8, -36, 18, 40), _p);
    _p.color = Colors.white;
    c.drawOval(const Rect.fromLTWH(-5, -38, 12, 12), _p);
    c.restore();
    _p.shader = ui.Gradient.linear(const Offset(0, -56), Offset.zero, [const Color(0xFFFFA726), const Color(0xFFEF6C00)]);
    c.drawOval(const Rect.fromLTWH(-18, -40, 36, 40), _p);
    c.drawCircle(const Offset(4, -48), 18, _p);
    _p.shader = null;
    // ears
    _p.color = const Color(0xFFE65100);
    c.drawPath(Path()..moveTo(-10, -60)..lineTo(-6, -78)..lineTo(2, -62)..close(), _p);
    c.drawPath(Path()..moveTo(8, -62)..lineTo(16, -78)..lineTo(20, -58)..close(), _p);
    _p.color = Colors.white;
    c.drawOval(const Rect.fromLTWH(-2, -46, 26, 16), _p);
    c.drawOval(const Rect.fromLTWH(-10, -28, 20, 22), _p);
    _eyes(c, p, -52, 7, 5.5);
    _p.color = Colors.black;
    c.drawCircle(const Offset(22, -40), 3.5, _p);
    _p.color = const Color(0xFF4E342E);
    final step = p.onGround ? sin(p.runT * 2) * 5 : 0.0;
    c.drawOval(Rect.fromLTWH(-12 + step, -5, 10, 6), _p);
    c.drawOval(Rect.fromLTWH(3 - step, -5, 10, 6), _p);
  }

  void _img(Canvas c, ui.Image img, Offset feet, double height) {
    final w = height * img.width / img.height;
    final dst = Rect.fromLTWH(feet.dx - w / 2, feet.dy - height, w, height);
    c.drawImageRect(img, Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), dst,
        Paint()..filterQuality = FilterQuality.medium);
  }

  // ---------- particles ----------
  void _particles(Canvas c, bool screen) {
    for (final q in e.parts) {
      if (q.screen != screen) continue;
      _particle(c, q);
    }
  }

  void _particlesScreen(Canvas c, double scale) {
    c.save();
    c.scale(scale);
    _particles(c, true);
    c.restore();
  }

  void _particle(Canvas c, Particle q) {
    final a = (q.life / q.max).clamp(0.0, 1.0).toDouble();
    _p.color = q.color.withValues(alpha: q.color.a * (q.kind == 2 ? 1.0 : a));
    switch (q.kind) {
      case 1:
        c.save();
        c.translate(q.x, q.y);
        c.rotate(q.rot);
        c.drawRect(Rect.fromCenter(center: Offset.zero, width: q.size, height: q.size * .8), _p);
        c.restore();
        break;
      case 2:
        c.save();
        c.translate(q.x + sin(q.rot) * 10, q.y);
        c.rotate(q.rot);
        c.drawOval(Rect.fromCenter(center: Offset.zero, width: q.size * 1.6, height: q.size * .8), _p);
        c.restore();
        break;
      case 3:
        final s = q.size * (.6 + a * .6);
        final path = Path();
        for (var i = 0; i < 8; i++) {
          final r = i.isEven ? s : s * .4;
          final ang = q.rot + i * pi / 4;
          final o = Offset(q.x + cos(ang) * r, q.y + sin(ang) * r);
          if (i == 0) { path.moveTo(o.dx, o.dy); } else { path.lineTo(o.dx, o.dy); }
        }
        path.close();
        c.drawPath(path, _p);
        break;
      case 4:
        _p
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;
        c.drawCircle(Offset(q.x, q.y), q.size * (2 - a) * 1.5, _p);
        _p.style = PaintingStyle.fill;
        break;
      case 5:
        c.save();
        c.translate(q.x + sin(q.rot * 2) * 6, q.y);
        c.rotate(q.rot * .5);
        c.drawOval(Rect.fromCenter(center: Offset.zero, width: q.size * .5, height: q.size * 1.6), _p);
        c.restore();
        break;
      default:
        c.drawCircle(Offset(q.x, q.y), q.size * (.5 + a * .5), _p);
    }
  }

  void _dashed(Canvas c, Offset a, Offset b, Color color, double w) {
    final paint = Paint()
      ..color = color.withValues(alpha: .5 + .5 * sin(e.time * 6).abs())
      ..strokeWidth = w
      ..strokeCap = StrokeCap.round;
    final len = (b - a).distance;
    final dir = (b - a) / len;
    for (double d = 0; d < len; d += 22) {
      c.drawLine(a + dir * d, a + dir * min(len, d + 11), paint);
    }
    // moving finger hint
    final k = (e.time * .6) % 1;
    drawText(c, '👆', a + dir * len * k + const Offset(0, 26), 26, Colors.white);
  }

  void _dashedCircle(Canvas c, Offset center, double r, Color color) {
    final paint = Paint()
      ..color = color.withValues(alpha: .5 + .5 * sin(e.time * 6).abs())
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 16; i++) {
      c.drawArc(Rect.fromCircle(center: center, radius: r), i * pi / 8, pi / 16, false, paint);
    }
    final ang = e.time * 3;
    drawText(c, '👆', center + Offset(cos(ang) * r, sin(ang) * r + 20), 24, Colors.white);
  }

  @override
  bool shouldRepaint(covariant GamePainter old) => true;
}
