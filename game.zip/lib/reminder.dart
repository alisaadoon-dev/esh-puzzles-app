// التذكير اليومي: إشعار يدعو الطفل للعب كل يوم الساعة 5 مساءً
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class Reminder {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const int _id = 7;
  static const int hour = 17; // الساعة 5 مساءً، بعد المدرسة

  /// العنوان ثم النص. {n} مكان اسم الطفل
  static const Map<String, List<String>> _text = {
    'ar': ['عش الألغاز 🦉', 'صديقك ينتظرك{n}! تعال حلّ لغز اليوم 🧩'],
    'en': ['Puzzle Nest 🦉', 'Your buddy is waiting{n}! Come solve today\'s puzzle 🧩'],
    'fr': ['Le Nid des Énigmes 🦉', 'Ton ami t\'attend{n} ! Viens résoudre l\'énigme du jour 🧩'],
    'es': ['Nido de Acertijos 🦉', '¡Tu amigo te espera{n}! Ven a resolver el acertijo de hoy 🧩'],
    'pt': ['Ninho dos Enigmas 🦉', 'Seu amigo está esperando{n}! Venha resolver o enigma de hoje 🧩'],
    'tr': ['Bilmece Yuvası 🦉', 'Arkadaşın seni bekliyor{n}! Gel, günün bilmecesini çöz 🧩'],
    'id': ['Sarang Teka-Teki 🦉', 'Temanmu menunggu{n}! Ayo pecahkan teka-teki hari ini 🧩'],
  };

  static Future<void> _init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
    );
    await _plugin.initialize(settings);
    _ready = true;
  }

  /// يطلب إذن الإشعارات (أندرويد 13 وما بعده)
  static Future<void> askPermission() async {
    try {
      await _init();
      await _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
  }

  /// يضبط التذكير من الغد، لأن الطفل لعب اليوم ما دام فتح اللعبة
  static Future<void> schedule(
      {required String lang, String name = '', bool on = true}) async {
    try {
      await _init();
      await _plugin.cancel(_id);
      if (!on) return;
      final t = _text[lang] ?? _text['ar']!;
      final n = name.isEmpty ? '' : (lang == 'ar' ? ' يا $name' : ', $name');
      final body = t[1].replaceAll('{n}', n);
      final now = DateTime.now();
      final when = DateTime(now.year, now.month, now.day, hour)
          .add(const Duration(days: 1));
      final at = tz.TZDateTime.from(when, tz.UTC);
      const details = NotificationDetails(
        android: AndroidNotificationDetails(
          'daily_reminder',
          'Daily reminder',
          channelDescription: 'Daily puzzle reminder',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
        ),
      );
      await _plugin.zonedSchedule(
        _id,
        t[0],
        body,
        at,
        details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } catch (_) {}
  }
}
