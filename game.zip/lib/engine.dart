import 'dart:math';
import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'audio.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'pet.dart' show PetStore;
import 'puzzles.dart';

const double kGroundY = 300;
const double kViewH = 360;
const double kGravity = 2300;
const double kJumpV = 820;

enum Mode { intro, play, drawBridge, drawShield, puzzle, cinematic, dead, win, paused }
enum HeroKind { owl, fox }
enum Face { normal, happy, sad }
enum Swipe { up, down, forward, back, tap }

class Seg { double x0, x1; Seg(this.x0, this.x1); }
class Plat { final Rect r; Plat(this.r); }
class Coin { double x, y; bool taken = false; double bob; Coin(this.x, this.y) : bob = x * 0.03; }
class Egg { double x, y, vy = 0; bool taken = false, hidden; final int id; Egg(this.id, this.x, this.y, {this.hidden = false}); }
class Rock { final double x, w, h; Rock(this.x, this.w, this.h); Rect get r => Rect.fromLTWH(x, kGroundY - h, w, h); }
class Branch { final double x, w; Branch(this.x, this.w); Rect get r => Rect.fromLTWH(x, kGroundY - 150, w, 116); }
class Hog {
  double x, dir = -1, squash = 0, deadT = 0, vy = 0, y = kGroundY;
  final double x0, x1;
  bool alive = true;
  Hog(this.x, this.x0, this.x1);
  Rect get r => Rect.fromLTWH(x - 22, y - 30, 44, 30);
}
class Crate {
  final double x, y; // top-left
  bool broken = false;
  final int eggId; // -1 none
  Crate(this.x, this.y, {this.eggId = -1});
  Rect get r => Rect.fromLTWH(x, y, 50, 50);
}
class Gate {
  final double x;
  final bool chase;
  int state = 0; // 0 closed, 1 breaking, 2 open, 3 slammed shut behind
  double t = 0, drop = 0;
  Gate(this.x, {this.chase = false});
}
class Bridge { final double x0, x1; double built = 0; bool active = false; Bridge(this.x0, this.x1); }
class Trigger { final double x; final String id; bool fired = false; Trigger(this.x, this.id); }

class Particle {
  double x, y, vx, vy, life, max, size, rot, vr, grav;
  Color color;
  int kind; // 0 circle, 1 square, 2 leaf, 3 star, 4 ring, 5 feather
  bool screen;
  Particle(this.x, this.y, this.vx, this.vy, this.life, this.size, this.color,
      {this.kind = 0, this.grav = 600, this.rot = 0, this.vr = 0, this.screen = false})
      : max = life;
}

class FloatText {
  double x, y, life;
  final String text;
  final Color color;
  final double size;
  FloatText(this.x, this.y, this.text, this.color, {this.size = 22}) : life = 1.0;
}

class Player {
  double x = 80, y = kGroundY, vx = 0, vy = 0;
  bool onGround = true;
  int jumpsLeft = 0;
  double coyote = 0, slideT = 0, dashT = 0, dashCd = 0, invuln = 0, faceT = 0, runT = 0;
  double sx = 1, sy = 1; // squash & stretch
  Face face = Face.normal;
  double get h => slideT > 0 ? 30 : 56;
  Rect get r => Rect.fromLTWH(x - 20, y - h, 40, h);
}

class Engine extends ChangeNotifier {
  final HeroKind hero;
  final Random rnd = Random();
  final PuzzleMaker puzzles = PuzzleMaker();
  final ValueNotifier<int> ui = ValueNotifier(0);

  Engine(this.hero) { _build(); }

  // ---------- state ----------
  Mode mode = Mode.intro;
  Mode _beforePause = Mode.play;
  int introStep = 0;
  final Player p = Player();
  int hearts = 3, coins = 0, hurtCount = 0;
  final Set<int> eggsFound = {};
  double checkpoint = 80;
  double time = 0, timeScale = 1, targetScale = 1;
  double hitstop = 0, trauma = 0, zoom = 1, flash = 0, quakeT = 0;
  double camX = 0;
  double viewW = 640;
  double runSpeed = 260;
  String? subtitle;
  double subtitleT = 0;
  String? waitFor; // tutorial: 'up' | 'down' | 'forward'
  Puzzle? puzzle;
  int puzzleFails = 0;
  Gate? puzzleGate;
  double drawTimer = 0; // seconds left to draw shield
  int? wrongPick;
  bool shield = false;
  double shieldT = 0;
  bool chasing = false;
  double boulderX = 0, boulderRot = 0;
  double heartbeatT = 0;
  // crow
  bool crowOn = false;
  double crowX = 0, crowY = 0, crowT = 0;
  int crowPhase = 0; // 1 arrive, 2 waiting dive, 3 dive, 4 flee
  // finish
  double finishT = 0;
  bool finished = false;

  final List<Seg> ground = [];
  final List<Plat> plats = [];
  final List<Coin> coinList = [];
  final List<Egg> eggs = [];
  final List<Rock> rocks = [];
  final List<Branch> branches = [];
  final List<Hog> hogs = [];
  final List<Crate> crates = [];
  final List<Gate> gates = [];
  final List<Bridge> bridges = [];
  final List<Trigger> triggers = [];
  final List<Particle> parts = [];
  final List<FloatText> texts = [];
  double levelEnd = 8800;
  double nestX = 8600;

  // ---------- level ----------
  void _build() {
    ground.addAll([Seg(-400, 3450), Seg(3650, 4060), Seg(4170, 6800), Seg(6930, 9400)]);
    bridges.add(Bridge(3450, 3650));

    void arc(double x0, double x1, double yTop, int n) {
      for (var i = 0; i < n; i++) {
        final t = n == 1 ? .5 : i / (n - 1);
        coinList.add(Coin(x0 + (x1 - x0) * t, kGroundY - 40 - (kGroundY - 40 - yTop) * sin(pi * t)));
      }
    }
    void line(double x0, double y, int n, [double gap = 42]) {
      for (var i = 0; i < n; i++) { coinList.add(Coin(x0 + i * gap, y)); }
    }

    triggers.add(Trigger(150, 'tut_jump'));
    rocks.add(Rock(400, 46, 44));
    arc(340, 500, 170, 5);
    rocks.add(Rock(640, 50, 50));
    rocks.add(Rock(820, 40, 38));
    arc(780, 900, 180, 4);
    triggers.add(Trigger(960, 'tut_slide'));
    branches.add(Branch(1130, 130));
    line(1140, kGroundY - 18, 3, 45);
    branches.add(Branch(1340, 110));
    line(1350, kGroundY - 18, 3, 40);
    triggers.add(Trigger(1480, 'tut_stomp'));
    hogs.add(Hog(1700, 1600, 1820));
    line(1640, 190, 4);
    // platforms with coins
    plats.add(Plat(const Rect.fromLTWH(1960, 240, 130, 18)));
    plats.add(Plat(const Rect.fromLTWH(2150, 190, 130, 18)));
    plats.add(Plat(const Rect.fromLTWH(2340, 140, 120, 18)));
    line(1980, 210, 3); line(2170, 160, 3); line(2355, 110, 3);
    rocks.add(Rock(2200, 44, 40));
    triggers.add(Trigger(2520, 'tut_dash'));
    hogs.add(Hog(2760, 2700, 2830));
    // egg 1: high in the sky — owl double jump only
    eggs.add(Egg(0, 3000, 52));
    if (hero == HeroKind.owl) triggers.add(Trigger(2840, 'owl_double'));
    line(2920, 150, 2, 160);
    // crates with egg 2 inside — fox dash only
    triggers.add(Trigger(3080, 'crate'));
    crates.add(Crate(3200, kGroundY - 50, eggId: 1));
    crates.add(Crate(3200, kGroundY - 100));
    eggs.add(Egg(1, 3225, kGroundY - 30, hidden: true));
    triggers.add(Trigger(3330, 'checkpoint'));
    triggers.add(Trigger(3400, 'bridge'));
    line(3460, 230, 5, 45);
    triggers.add(Trigger(3760, 'checkpoint'));
    arc(3800, 3960, 200, 4);
    triggers.add(Trigger(4000, 'jump_now'));
    arc(4010, 4220, 150, 5);
    gates.add(Gate(4520));
    triggers.add(Trigger(4560, 'checkpoint'));
    line(4600, kGroundY - 18, 4);
    triggers.add(Trigger(4800, 'crow'));
    hogs.add(Hog(5200, 5120, 5300));
    rocks.add(Rock(5420, 50, 46));
    branches.add(Branch(5600, 120));
    hogs.add(Hog(5850, 5760, 5960));
    // egg 3 on a platform guarded by a hedgehog
    plats.add(Plat(const Rect.fromLTWH(6050, 200, 140, 18)));
    eggs.add(Egg(2, 6120, 168));
    hogs.add(Hog(6120, 6040, 6200));
    line(6240, 230, 3);
    triggers.add(Trigger(6300, 'checkpoint'));
    triggers.add(Trigger(6420, 'quake'));
    // chase section
    rocks.add(Rock(6650, 46, 42));
    arc(6760, 6990, 150, 5);
    branches.add(Branch(7120, 120));
    hogs.add(Hog(7330, 7300, 7380));
    rocks.add(Rock(7520, 50, 48));
    branches.add(Branch(7700, 120));
    rocks.add(Rock(7900, 46, 44));
    gates.add(Gate(8150, chase: true));
    line(8300, 200, 6, 40);
    triggers.add(Trigger(8450, 'checkpoint'));
    triggers.add(Trigger(nestX - 60, 'finish'));
  }

  // ---------- helpers ----------
  bool _disposed = false;
  void _ui() { if (!_disposed) ui.value++; }

  void say(String key, {double secs = 2.6}) {
    subtitle = L.line(key);
    subtitleT = secs;
    Sfx.say(key);
    _ui();
  }

  void shake(double amount) => trauma = min(1.0, trauma + amount);

  void burst(double x, double y, int n, List<Color> colors,
      {double speed = 300, int kind = 0, double size = 5, double life = .7, double grav = 700, bool up = false}) {
    for (var i = 0; i < n; i++) {
      final a = up ? -pi / 2 + (rnd.nextDouble() - .5) * 1.6 : rnd.nextDouble() * pi * 2;
      final s = speed * (.35 + rnd.nextDouble() * .8);
      parts.add(Particle(x, y, cos(a) * s, sin(a) * s, life * (.6 + rnd.nextDouble() * .7),
          size * (.6 + rnd.nextDouble() * .8), colors[rnd.nextInt(colors.length)],
          kind: kind, grav: grav, rot: rnd.nextDouble() * 6, vr: (rnd.nextDouble() - .5) * 14));
    }
  }

  void float(double x, double y, String t, Color c, {double size = 22}) => texts.add(FloatText(x, y, t, c, size: size));

  bool _onGroundAt(double x) {
    for (final s in ground) {
      if (x >= s.x0 && x <= s.x1) return true;
    }
    for (final b in bridges) {
      if (b.built >= 1 && x >= b.x0 && x <= b.x1) return true;
    }
    return false;
  }

  int get difficulty => min(4, 1 + (p.x / 2600).floor());

  // ---------- input ----------
  void swipe(Swipe s) {
    if (mode == Mode.intro) { nextIntro(); return; }
    if (mode != Mode.play && mode != Mode.cinematic) return;
    if (waitFor != null) {
      final ok = (waitFor == 'up' && (s == Swipe.up || s == Swipe.tap)) ||
          (waitFor == 'down' && s == Swipe.down) || (waitFor == 'forward' && s == Swipe.forward);
      if (!ok) return;
      waitFor = null;
      targetScale = 1;
      Sfx.setMusicVolume(.45);
      _ui();
    }
    switch (s) {
      case Swipe.up:
      case Swipe.tap:
        _jump();
        break;
      case Swipe.down:
        _slide();
        break;
      case Swipe.forward:
        _dash();
        break;
      case Swipe.back:
        break;
    }
  }

  void _jump() {
    if (p.onGround || p.coyote > 0) {
      p.vy = -kJumpV;
      p.onGround = false;
      p.coyote = 0;
      p.slideT = 0;
      p.jumpsLeft = hero == HeroKind.owl ? 1 : 0;
      p.sx = .75; p.sy = 1.3;
      Sfx.play('jump', volume: .8);
      Buzz.jump();
      burst(p.x, p.y, 8, const [Color(0xFFD8C8A0), Color(0xFFBFAF85)], speed: 140, size: 5, grav: 200, up: true);
    } else if (p.jumpsLeft > 0) {
      p.jumpsLeft--;
      p.vy = -kJumpV * .9;
      p.sx = .8; p.sy = 1.25;
      Sfx.play('double_jump', volume: .9);
      Buzz.jump();
      burst(p.x, p.y - 20, 14, const [Color(0xFFFFFFFF), Color(0xFFE8D7B0)], kind: 5, speed: 220, size: 8, grav: 120, life: .9);
    }
  }

  void _slide() {
    if (p.onGround) {
      p.slideT = .65;
      p.sx = 1.3; p.sy = .7;
      Sfx.play('slide', volume: .7);
      Buzz.tick();
    } else {
      p.vy = max(p.vy, 1000.0); // ground pound
      p.slideT = .5;
    }
  }

  void _dash() {
    if (p.dashCd > 0) return;
    p.dashT = hero == HeroKind.fox ? .38 : .24;
    p.dashCd = .7;
    p.sx = 1.35; p.sy = .8;
    Sfx.play('dash', volume: .9);
    Buzz.dash();
    zoom = 1.04;
  }

  // ---------- flow ----------
  void nextIntro() {
    Sfx.play('click');
    introStep++;
    if (introStep >= 3) {
      startPlay();
    } else {
      Sfx.say(['intro1', 'intro2', 'intro3'][introStep]);
      _ui();
    }
  }

  void beginIntro() {
    Sfx.music('forest', volume: .3);
    Sfx.say('intro1');
  }

  void startPlay() {
    mode = Mode.play;
    Sfx.music('forest');
    _ui();
  }

  void pause() {
    if (mode == Mode.paused || mode == Mode.win || mode == Mode.dead) return;
    _beforePause = mode;
    mode = Mode.paused;
    _ui();
  }

  void resume() {
    if (mode != Mode.paused) return;
    mode = _beforePause;
    _ui();
  }

  void retryFromCheckpoint() {
    hearts = 3;
    _respawn();
    mode = Mode.play;
    Sfx.music(chasing ? 'chase' : 'forest');
    _ui();
  }

  void _respawn() {
    p.x = checkpoint;
    p.y = kGroundY;
    p.vy = 0;
    p.onGround = true;
    p.invuln = 1.5;
    p.slideT = 0;
    p.dashT = 0;
    if (chasing) boulderX = p.x - 520;
    for (final t in triggers) {
      if (t.x > checkpoint && (t.id == 'jump_now' || t.id.startsWith('tut_'))) t.fired = false;
    }
    waitFor = null;
    targetScale = 1;
    camX = p.x - viewW * .3;
  }

  void _hurt({bool fell = false}) {
    if (!fell && (p.invuln > 0 || shield)) return;
    hearts--;
    hurtCount++;
    p.invuln = 1.5;
    p.face = Face.sad; p.faceT = 1.4;
    Sfx.play('hurt');
    Buzz.hurt();
    shake(.55);
    hitstop = .09;
    flash = .25;
    burst(p.x, p.y - 30, 16, const [Color(0xFFFF5252), Color(0xFFFFFFFF)], speed: 300, kind: 3, size: 7);
    if (rnd.nextBool()) say('hurt', secs: 1.4);
    if (hearts <= 0) {
      mode = Mode.dead;
      Sfx.play('lose');
      Sfx.music(null);
      say('lose');
      _ui();
      return;
    }
    if (fell) {
      _respawn();
    } else {
      p.vy = -520;
      p.onGround = false;
      p.x -= 30;
    }
    _ui();
  }

  void _happy() { p.face = Face.happy; p.faceT = 1.6; }

  // ---------- puzzles ----------
  void _startPuzzle(Gate g) {
    puzzleGate = g;
    puzzle = puzzles.next(g.chase ? min(4, difficulty + 1) : difficulty);
    wrongPick = null;
    mode = Mode.puzzle;
    if (g.chase) {
      targetScale = .05;
      Sfx.play('slowmo');
      say('chase_gate', secs: 2.2);
      Future.delayed(const Duration(milliseconds: 1900), () { if (puzzle != null && mode == Mode.puzzle) Sfx.say(puzzle!.voice); });
    } else {
      say('gate', secs: 2.2);
      Future.delayed(const Duration(milliseconds: 1900), () { if (puzzle != null && mode == Mode.puzzle) Sfx.say(puzzle!.voice); });
    }
    _ui();
  }

  void answer(int i) {
    final pz = puzzle;
    final g = puzzleGate;
    if (pz == null || g == null || mode != Mode.puzzle) return;
    if (i == pz.answer) {
      Sfx.play('correct');
      Buzz.correct();
      say(['good1', 'good2', 'good3'][rnd.nextInt(3)], secs: 1.6);
      _happy();
      coins += 3;
      float(p.x, p.y - 80, '+${L.num(3)} 🪙', const Color(0xFFFFD54F), size: 26);
      puzzle = null;
      puzzleFails = 0;
      g.state = 1;
      g.t = 0;
      mode = Mode.play;
      if (!g.chase) targetScale = 1;
    } else {
      wrongPick = i;
      puzzleFails++;
      Sfx.play('wrong');
      Buzz.wrong();
      shake(.25);
      say(rnd.nextBool() ? 'wrong1' : 'wrong2', secs: 1.5);
      p.face = Face.sad; p.faceT = 1.0;
      // new puzzle after a short moment so the child sees it was wrong
      Future.delayed(const Duration(milliseconds: 750), () {
        if (mode == Mode.puzzle && puzzleGate == g) {
          puzzle = puzzles.next(max(1, (g.chase ? difficulty + 1 : difficulty) - (puzzleFails >= 2 ? 1 : 0)));
          wrongPick = null;
          Sfx.say(puzzle!.voice);
          _ui();
        }
      });
    }
    _ui();
  }

  // ---------- drawing ----------
  /// Called with a finished stroke in screen pixels. Returns true if accepted.
  bool drawn(String shape) {
    if (mode == Mode.drawBridge && shape == 'line') {
      final b = bridges.firstWhere((b) => b.active, orElse: () => bridges.first);
      b.active = false;
      b.built = 0.0001;
      mode = Mode.play;
      Sfx.play('magic');
      Sfx.play('bridge');
      Buzz.magic();
      say('good2', secs: 1.4);
      _happy();
      burst((b.x0 + b.x1) / 2, kGroundY, 30, const [Color(0xFFFFF176), Color(0xFFFFFFFF), Color(0xFF80DEEA)], kind: 3, speed: 260, size: 7, grav: 100);
      _ui();
      return true;
    }
    if (mode == Mode.drawShield && shape == 'circle') {
      shield = true;
      shieldT = 3.5;
      mode = Mode.play;
      crowPhase = 3;
      crowT = 0;
      targetScale = .45;
      Sfx.play('shield');
      Buzz.magic();
      _happy();
      burst(p.x, p.y - 30, 26, const [Color(0xFF80D8FF), Color(0xFFFFFFFF)], kind: 4, speed: 200, size: 10, grav: 0);
      _ui();
      return true;
    }
    if (mode == Mode.drawBridge || mode == Mode.drawShield) {
      Sfx.play('wrong', volume: .6);
      Buzz.wrong();
      say('wrong1', secs: 1.2);
    }
    return false;
  }

  // ---------- triggers ----------
  void _fire(Trigger t) {
    t.fired = true;
    switch (t.id) {
      case 'tut_jump':
        say('tut_jump', secs: 3);
        waitFor = 'up';
        targetScale = .18;
        break;
      case 'tut_slide':
        say('tut_slide', secs: 3);
        waitFor = 'down';
        targetScale = .18;
        break;
      case 'tut_stomp':
        say('tut_stomp', secs: 3);
        break;
      case 'tut_dash':
        say('tut_dash', secs: 3);
        waitFor = 'forward';
        targetScale = .18;
        break;
      case 'owl_double':
        say('owl_double', secs: 3.2);
        break;
      case 'crate':
        say('crate', secs: 3);
        break;
      case 'checkpoint':
        if (t.x > checkpoint) {
          checkpoint = t.x;
          Sfx.play('checkpoint', volume: .7);
          burst(t.x, kGroundY - 60, 14, const [Color(0xFF69F0AE), Color(0xFFFFFFFF)], kind: 3, speed: 160, grav: 50);
        }
        break;
      case 'bridge':
        p.vx = 0;
        bridges.first.active = true;
        mode = Mode.drawBridge;
        say('draw_bridge', secs: 3.5);
        break;
      case 'jump_now':
        say('jump_now', secs: 1.6);
        waitFor = 'up';
        targetScale = .12;
        Sfx.play('slowmo');
        Sfx.setMusicVolume(.15);
        break;
      case 'crow':
        crowOn = true;
        crowPhase = 1;
        crowT = 0;
        crowX = p.x + viewW * .8;
        crowY = 40;
        Sfx.play('crow');
        say('crow_laugh', secs: 2.2);
        break;
      case 'quake':
        mode = Mode.cinematic;
        quakeT = 2.0;
        Sfx.music(null);
        Sfx.play('quake');
        Buzz.quake();
        say('quake', secs: 2);
        break;
      case 'finish':
        mode = Mode.cinematic;
        finishT = 0;
        finished = true;
        break;
    }
    _ui();
  }

  // ---------- update ----------
  void update(double dtReal) {
    final dt = dtReal.clamp(0.0, 1 / 30).toDouble();
    time += dt;
    if (subtitleT > 0) {
      subtitleT -= dt;
      if (subtitleT <= 0) { subtitle = null; _ui(); }
    }
    if (mode == Mode.paused || mode == Mode.intro) { notifyListeners(); return; }

    // effects that run in real time
    trauma = max(0.0, trauma - dt * 1.6);
    flash = max(0.0, flash - dt * 2.5);
    zoom += (1 - zoom) * min(1.0, dt * 4);
    if (hitstop > 0) { hitstop -= dt; notifyListeners(); return; }
    timeScale += (targetScale - timeScale) * min(1.0, dt * (targetScale < timeScale ? 10 : 4));
    final d = dt * timeScale;

    _updateParticles(d, dt);

    if (mode == Mode.dead || mode == Mode.win) { notifyListeners(); return; }

    // timers
    p.invuln = max(0.0, p.invuln - d);
    p.dashCd = max(0.0, p.dashCd - d);
    p.coyote = max(0.0, p.coyote - d);
    if (p.faceT > 0) { p.faceT -= dt; if (p.faceT <= 0) p.face = Face.normal; }
    p.sx += (1 - p.sx) * min(1.0, d * 10);
    p.sy += (1 - p.sy) * min(1.0, d * 10);
    if (shieldT > 0) { shieldT -= d; if (shieldT <= 0) shield = false; }

    // cinematic: earthquake → boulder chase
    if (quakeT > 0) {
      quakeT -= dt;
      trauma = max(trauma, .55);
      if (rnd.nextDouble() < .5) {
        parts.add(Particle(camX + rnd.nextDouble() * viewW, -10, 0, 200, 1.6, 4 + rnd.nextDouble() * 6,
            const Color(0xFF8D6E63), kind: 1, grav: 900, vr: 6));
      }
      if (quakeT <= 0) {
        chasing = true;
        boulderX = p.x - 560;
        runSpeed = 335;
        mode = Mode.play;
        Sfx.music('chase', volume: .55);
        Sfx.play('boom');
        Buzz.boom();
        shake(.8);
        say('run', secs: 2);
        _ui();
      }
    }

    // finish cinematic
    if (finished && mode == Mode.cinematic) {
      _updateFinish(dt);
    }

    // --- player movement ---
    double target = (mode == Mode.play) ? runSpeed : 0;
    if (finished) target = 0;
    // stop at closed gates / missing bridges
    for (final g in gates) {
      if (g.state == 0 && p.x < g.x && p.x > g.x - 70 && mode == Mode.play) {
        target = 0;
        p.x = min(p.x, g.x - 40);
        if (mode == Mode.play) _startPuzzle(g);
      }
    }
    for (final b in bridges) {
      if (b.built < 1 && p.x < b.x0 && p.x > b.x0 - 90) {
        target = 0;
        p.x = min(p.x, b.x0 - 30);
      }
    }
    if (p.slideT > 0) { p.slideT -= d; target *= 1.08; }
    p.vx += (target - p.vx) * min(1.0, d * 8);
    var vx = p.vx;
    if (p.dashT > 0) {
      p.dashT -= d;
      vx += hero == HeroKind.fox ? 560 : 400;
      if (rnd.nextDouble() < .7) {
        parts.add(Particle(p.x - 20, p.y - 10 - rnd.nextDouble() * 40, -120, 0, .3, 10,
            hero == HeroKind.fox ? const Color(0x88FF8A3D) : const Color(0x88C9A27A), kind: 0, grav: 0));
      }
    }
    // gate blocking also while dashing
    for (final g in gates) {
      if (g.state == 0 && p.x < g.x - 20 && p.x + vx * d > g.x - 40) vx = 0;
    }
    // crates are solid
    final prevX = p.x;
    p.x += vx * d;
    for (final c in crates) {
      if (c.broken) continue;
      final pr = p.r;
      if (pr.overlaps(c.r.deflate(2)) && p.y > c.r.top + 8) {
        if (p.dashT > 0 && hero == HeroKind.fox) {
          _breakCrate(c);
        } else {
          p.x = min(p.x, max(prevX, c.r.left - 21));
          p.vx = 0;
        }
      }
    }

    // vertical
    final prevFoot = p.y;
    p.vy += kGravity * d;
    p.y += p.vy * d;
    final wasGround = p.onGround;
    p.onGround = false;
    if (p.vy >= 0) {
      // ground
      if (p.y >= kGroundY && prevFoot <= kGroundY + 12 && _onGroundAt(p.x)) {
        p.y = kGroundY;
        p.onGround = true;
      }
      // platforms
      for (final pl in plats) {
        if (p.x > pl.r.left - 8 && p.x < pl.r.right + 8 && prevFoot <= pl.r.top + 2 && p.y >= pl.r.top) {
          p.y = pl.r.top; p.onGround = true;
        }
      }
      for (final c in crates) {
        if (c.broken) continue;
        if (p.x > c.r.left - 6 && p.x < c.r.right + 6 && prevFoot <= c.r.top + 2 && p.y >= c.r.top) {
          p.y = c.r.top; p.onGround = true;
        }
      }
      if (p.onGround) {
        if (!wasGround && p.vy > 300) {
          p.sx = 1.3; p.sy = .72;
          Sfx.play('land', volume: .6, minGapMs: 120);
          Buzz.land();
          burst(p.x, p.y, 10, const [Color(0xFFD8C8A0), Color(0xFFBFAF85)], speed: 160, size: 5, grav: 300, up: true);
          if (p.vy > 950) shake(.2);
        }
        p.vy = 0;
        p.jumpsLeft = hero == HeroKind.owl ? 1 : 0;
      }
    }
    if (wasGround && !p.onGround && p.vy >= 0) p.coyote = .12;
    if (p.y > 470) { _hurt(fell: true); }
    if (p.onGround && p.vx > 40) {
      p.runT += d * p.vx / 40;
      if (rnd.nextDouble() < d * 8) {
        parts.add(Particle(p.x - 12, p.y - 2, -60, -30, .4, 4, const Color(0x99C8B88F), grav: 0));
      }
    }

    _updateWorld(d, dt);
    _collide();

    // triggers
    for (final t in triggers) {
      if (!t.fired && p.x >= t.x && (mode == Mode.play)) _fire(t);
    }

    // camera
    final lead = chasing ? .52 : .28;
    final tx = p.x - viewW * lead;
    camX += (tx - camX) * min(1.0, dt * 5);
    notifyListeners();
  }

  void _breakCrate(Crate c) {
    c.broken = true;
    Sfx.play('crate');
    Buzz.crack();
    shake(.35);
    hitstop = .05;
    burst(c.r.center.dx, c.r.center.dy, 18, const [Color(0xFFA1887F), Color(0xFF8D6E63), Color(0xFF6D4C41)], kind: 1, speed: 420, size: 9);
    if (c.eggId >= 0) {
      for (final e in eggs) {
        if (e.id == c.eggId) { e.hidden = false; e.vy = -500; }
      }
    }
  }

  void _updateWorld(double d, double dt) {
    // bridge building animation
    for (final b in bridges) {
      if (b.built > 0 && b.built < 1) {
        final before = (b.built * 10).floor();
        b.built = min(1.0, b.built + d * 1.4);
        if ((b.built * 10).floor() > before) {
          final px = b.x0 + (b.x1 - b.x0) * b.built;
          burst(px, kGroundY, 4, const [Color(0xFFBCAAA4), Color(0xFFFFFFFF)], speed: 120, size: 4, up: true);
          Buzz.tick();
        }
      }
    }
    // hedgehogs
    for (final h in hogs) {
      if (h.alive) {
        h.x += h.dir * 55 * d;
        if (h.x < h.x0) { h.x = h.x0; h.dir = 1; }
        if (h.x > h.x1) { h.x = h.x1; h.dir = -1; }
      } else {
        h.deadT += d;
        h.vy += kGravity * d;
        h.y += h.vy * d;
      }
      h.squash = max(0.0, h.squash - d * 3);
    }
    // eggs popping out of crates
    for (final e in eggs) {
      if (!e.hidden && e.vy != 0) {
        e.vy += kGravity * .6 * d;
        e.y += e.vy * d;
        if (e.y > kGroundY - 22) { e.y = kGroundY - 22; e.vy = 0; }
      }
    }
    // gates
    for (final g in gates) {
      if (g.state == 1) {
        final before = g.t;
        g.t += dt;
        for (final mark in [.0, .25, .5]) {
          if (before < mark + .001 && g.t >= mark + .001) {
            Sfx.play('gate_crack', minGapMs: 0);
            Buzz.crack();
            shake(.25);
            burst(g.x, kGroundY - 120 + rnd.nextDouble() * 60, 8, const [Color(0xFF9E9E9E), Color(0xFF757575)], kind: 1, speed: 200, size: 6);
          }
        }
        if (g.t >= .8) {
          g.state = 2;
          g.t = 0;
          Sfx.play('gate_break');
          Buzz.boom();
          shake(.75);
          flash = .3;
          hitstop = .07;
          zoom = 1.08;
          for (var i = 0; i < 4; i++) {
            burst(g.x, kGroundY - 40 - i * 40, 10, const [Color(0xFF9E9E9E), Color(0xFF616161), Color(0xFFBDBDBD)], kind: 1, speed: 480, size: 12, life: 1.2, grav: 1100);
          }
          burst(g.x, kGroundY - 80, 30, const [Color(0xFFFFF59D), Color(0xFFFFFFFF)], kind: 3, speed: 340, size: 6, grav: 200);
          if (g.chase) {
            // let the hero run through, then slam it shut on the boulder
            targetScale = .6;
          }
        }
      } else if (g.state == 2) {
        g.t += dt;
        if (g.chase && p.x > g.x + 120) {
          g.state = 3;
          g.drop = 0;
          targetScale = 1;
        }
      } else if (g.state == 3) {
        g.drop = min(1.0, g.drop + dt * 4);
      }
    }
    // boulder chase
    if (chasing) {
      boulderRot += d * 4;
      final chaseGate = gates.firstWhere((g) => g.chase);
      final speed = mode == Mode.puzzle ? 60.0 : 330.0;
      boulderX += speed * d;
      if (mode == Mode.play) boulderX = max(boulderX, p.x - 430);
      if (rnd.nextDouble() < d * 30) {
        parts.add(Particle(boulderX - 60 + rnd.nextDouble() * 60, kGroundY - 4, -80 - rnd.nextDouble() * 80, -60 - rnd.nextDouble() * 120, .7, 8 + rnd.nextDouble() * 10,
            const Color(0x88A1887F), grav: -40));
      }
      trauma = max(trauma, .08);
      heartbeatT -= dt;
      final dist = p.x - boulderX;
      if (heartbeatT <= 0) {
        heartbeatT = dist < 260 ? .45 : .8;
        Sfx.play('heartbeat', volume: .6);
        Buzz.heartbeat();
      }
      if (chaseGate.state == 3 && boulderX + 90 >= chaseGate.x) {
        // smash!
        chasing = false;
        runSpeed = 260;
        Sfx.play('boom');
        Sfx.play('gate_break');
        Buzz.boom();
        shake(1);
        flash = .6;
        hitstop = .15;
        zoom = 1.1;
        for (var i = 0; i < 5; i++) {
          burst(chaseGate.x - 40, kGroundY - 30 - i * 30, 14, const [Color(0xFF8D6E63), Color(0xFF6D4C41), Color(0xFF9E9E9E)], kind: 1, speed: 600, size: 13, life: 1.3, grav: 1200);
        }
        Sfx.music('forest');
        say('good3', secs: 2);
        _happy();
        for (var i = 0; i < 12; i++) {
          coinList.add(Coin(chaseGate.x + 200 + i * 35, 120 + rnd.nextDouble() * 120));
        }
      } else if (dist < 95 && mode == Mode.play) {
        _hurt();
        boulderX = p.x - 380;
      } else if (dist < 80 && mode == Mode.puzzle) {
        _hurt();
        boulderX = p.x - 330;
      }
    }
    // crow
    if (crowOn) _updateCrow(d, dt);
  }

  void _updateCrow(double d, double dt) {
    crowT += dt;
    switch (crowPhase) {
      case 1: { // swoop in to hover above-right
        final tx = p.x + 220, ty = 70.0;
        crowX += (tx - crowX) * min(1.0, dt * 3);
        crowY += (ty - crowY) * min(1.0, dt * 3);
        if (crowT > 2.2) {
          crowPhase = 2;
          crowT = 0;
          mode = Mode.drawShield;
          drawTimer = 6;
          targetScale = .08;
          Sfx.play('slowmo');
          say('draw_circle', secs: 3);
          _ui();
        }
        break;
      }
      case 2: // waiting for the circle
        crowX = p.x + 220 + sin(time * 3) * 10;
        crowY = 70 + sin(time * 5) * 8;
        drawTimer -= dt;
        if (drawTimer <= 0 && mode == Mode.drawShield) {
          mode = Mode.play;
          crowPhase = 3;
          crowT = 0;
          targetScale = .5;
          _ui();
        }
        break;
      case 3: { // dive at the hero
        final tx = p.x, ty = p.y - 35;
        crowX += (tx - crowX) * min(1.0, d * 6);
        crowY += (ty - crowY) * min(1.0, d * 6);
        if ((Offset(crowX, crowY) - Offset(tx, ty)).distance < 45 || crowT > 2.5) {
          if (shield) {
            Sfx.play('shield_hit');
            Buzz.boom();
            shake(.6);
            hitstop = .12;
            flash = .35;
            burst(crowX, crowY, 30, const [Color(0xFF212121), Color(0xFF424242), Color(0xFF37474F)], kind: 5, speed: 380, size: 10, life: 1.4, grav: 150);
            coins += 5;
            float(p.x, p.y - 90, '+${L.num(5)} 🪙', const Color(0xFFFFD54F), size: 26);
            say('crow_flee', secs: 2.6);
          } else {
            _hurt();
          }
          Sfx.play('crow');
          crowPhase = 4;
          crowT = 0;
          targetScale = 1;
        }
        break;
      }
      case 4: // flee
        crowX += 500 * d;
        crowY -= 260 * d;
        if (crowT > 3) { crowOn = false; }
        break;
    }
  }

  void _updateFinish(double dt) {
    finishT += dt;
    p.vx = 0;
    if (finishT < .1) {
      Sfx.music(null);
    }
    if (finishT > .5 && finishT - dt <= .5) {
      // crow swoops in, drops the golden egg, flees
      crowOn = true; crowPhase = 0; crowX = p.x + 400; crowY = 30;
      Sfx.play('crow');
      say('crow_flee', secs: 2.8);
    }
    if (crowOn && crowPhase == 0) {
      crowX += (nestX + 40 - crowX) * min(1.0, dt * 2);
      crowY += (60 - crowY) * min(1.0, dt * 2);
      if (finishT > 3.0) { crowPhase = 4; crowT = 0; }
    }
    if (finishT > 3.3 && finishT - dt <= 3.3) {
      Sfx.play('egg');
      Sfx.play('win');
      Buzz.win();
      say('win', secs: 3);
      _happy();
      p.faceT = 99;
      flash = .4;
      for (var i = 0; i < 90; i++) {
        parts.add(Particle(rnd.nextDouble() * viewW, -20 - rnd.nextDouble() * 200, (rnd.nextDouble() - .5) * 80, 60 + rnd.nextDouble() * 120,
            4, 8, [const Color(0xFFFF5252), const Color(0xFFFFEB3B), const Color(0xFF69F0AE), const Color(0xFF40C4FF), const Color(0xFFE040FB)][i % 5],
            kind: 1, grav: 60, vr: 8, screen: true));
      }
    }
    if (finishT > 5.5) {
      mode = Mode.win;
      PetStore.onAdventureWon(coins: coins, allEggs: eggsFound.length >= 3);
      Sfx.music('forest', volume: .3);
      Future.delayed(const Duration(milliseconds: 3200), () => Sfx.say('teaser'));
      _ui();
    }
  }

  void _collide() {
    final pr = p.r;
    final center = Offset(p.x, p.y - p.h / 2);
    for (final c in coinList) {
      if (c.taken) continue;
      if ((Offset(c.x, c.y) - center).distance < 34) {
        c.taken = true;
        coins++;
        Sfx.play('coin', volume: .7, minGapMs: 30);
        Buzz.coin();
        burst(c.x, c.y, 7, const [Color(0xFFFFE082), Color(0xFFFFFFFF)], kind: 3, speed: 150, size: 5, grav: 100, life: .5);
        _ui();
      }
    }
    for (final e in eggs) {
      if (e.taken || e.hidden) continue;
      if ((Offset(e.x, e.y) - center).distance < 40) {
        e.taken = true;
        eggsFound.add(e.id);
        Sfx.play('egg');
        Buzz.correct();
        flash = .3;
        hitstop = .08;
        zoom = 1.06;
        _happy();
        say('egg', secs: 2);
        burst(e.x, e.y, 34, const [Color(0xFFFFD700), Color(0xFFFFF59D), Color(0xFFFFFFFF)], kind: 3, speed: 330, size: 8, grav: 120, life: 1.1);
        float(e.x, e.y - 30, '🥚 ${L.num(eggsFound.length)}/${L.num(3)}', const Color(0xFFFFF59D), size: 28);
        _ui();
      }
    }
    for (final r in rocks) {
      if (pr.deflate(4).overlaps(r.r)) {
        if (p.dashT > 0 && hero == HeroKind.fox) {
          // fox bounces off safely
          p.dashT = 0;
          p.vy = -600;
          p.onGround = false;
          Sfx.play('stomp');
        } else {
          _hurt();
        }
      }
    }
    for (final b in branches) {
      if (pr.deflate(3).overlaps(b.r) && p.slideT <= 0) _hurt();
    }
    for (final h in hogs) {
      if (!h.alive) continue;
      if (pr.overlaps(h.r)) {
        final fromAbove = p.vy > 0 && (p.y - h.r.top) < 22;
        if (fromAbove || p.dashT > 0) {
          h.alive = false;
          h.vy = -500;
          h.squash = 1;
          p.vy = fromAbove ? -680 : p.vy;
          p.onGround = false;
          p.jumpsLeft = hero == HeroKind.owl ? 1 : 0;
          coins += 2;
          Sfx.play('stomp');
          Buzz.stomp();
          hitstop = .06;
          shake(.25);
          burst(h.x, h.y - 15, 16, const [Color(0xFF8D6E63), Color(0xFFFFFFFF), Color(0xFFFFE082)], kind: 3, speed: 280, size: 6);
          float(h.x, h.y - 50, '+${L.num(2)} 🪙', const Color(0xFFFFD54F));
          _ui();
        } else {
          _hurt();
        }
      }
    }
  }

  void _updateParticles(double d, double dt) {
    for (final q in parts) {
      final s = q.screen ? dt : d;
      q.vy += q.grav * s;
      q.x += q.vx * s;
      q.y += q.vy * s;
      q.rot += q.vr * s;
      q.life -= s;
    }
    parts.removeWhere((q) => q.life <= 0);
    if (parts.length > 500) parts.removeRange(0, parts.length - 500);
    for (final t in texts) {
      t.y -= 50 * dt;
      t.life -= dt * .8;
    }
    texts.removeWhere((t) => t.life <= 0);
    // ambient leaves
    if (rnd.nextDouble() < d * 2.2) {
      parts.add(Particle(camX + viewW + 20, rnd.nextDouble() * 200, -40 - rnd.nextDouble() * 60, 30, 9, 6 + rnd.nextDouble() * 4,
          [const Color(0xFF7CB342), const Color(0xFFFFB300), const Color(0xFF9CCC65)][rnd.nextInt(3)],
          kind: 2, grav: 8, vr: 2));
    }
  }

  int get stars {
    var s = 1;
    if (eggsFound.length >= 3) s++;
    if (hurtCount == 0) s++;
    return s;
  }

  @override
  void dispose() {
    _disposed = true;
    ui.dispose();
    super.dispose();
  }
}
