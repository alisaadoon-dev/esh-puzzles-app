// lib/rewards.dart
// المكافأة اليومية (7 أيام متتالية) وصناديق الكنوز (خشبي / فضي / ذهبي).
// العملات تُحفظ في نفس محفظة الحيوان الأليف (pet_wallet).

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'audio.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'widgets.dart';

// ───────────── النصوص ─────────────

const _rs = {
  'ar': {
    'daily': 'هدية اليوم',
    'day': 'اليوم',
    'claim': 'خذ الهدية',
    'come_back': 'عُد غداً لهدية أكبر!',
    'streak_lost': 'فاتك يوم… بدأنا من جديد',
    'chests': 'صناديق الكنز',
    'wood': 'خشبي',
    'silver': 'فضي',
    'gold': 'ذهبي',
    'tap_open': 'اضغط على الصندوق ٣ مرات لتفتحه!',
    'no_chests': 'ليست لديك صناديق. انتصر في المراحل لتربح صندوقاً!',
    'open_another': 'افتح صندوقاً آخر',
    'back': 'رجوع',
    'golden_treat': 'ثمرة ذهبية لصديقك!',
    'chest_won': 'ربحت صندوق كنز!',
    'great': 'رائع!',
  },
  'en': {
    'daily': "Today's gift",
    'day': 'Day',
    'claim': 'Claim',
    'come_back': 'Come back tomorrow for a bigger gift!',
    'streak_lost': 'You missed a day… starting over',
    'chests': 'Treasure chests',
    'wood': 'Wooden',
    'silver': 'Silver',
    'gold': 'Golden',
    'tap_open': 'Tap the chest 3 times to open it!',
    'no_chests': 'No chests yet. Win the adventure to earn one!',
    'open_another': 'Open another',
    'back': 'Back',
    'golden_treat': 'A golden treat for your pet!',
    'chest_won': 'You won a treasure chest!',
    'great': 'Great!',
  },
  'fr': {
    'daily': 'Cadeau du jour',
    'day': 'Jour',
    'claim': 'Prendre',
    'come_back': 'Reviens demain pour un plus gros cadeau !',
    'streak_lost': 'Tu as manqué un jour… on recommence',
    'chests': 'Coffres au trésor',
    'wood': 'En bois',
    'silver': 'En argent',
    'gold': 'En or',
    'tap_open': 'Touche le coffre 3 fois pour l\'ouvrir !',
    'no_chests': 'Pas de coffre. Gagne l\'aventure pour en gagner un !',
    'open_another': 'Ouvrir un autre',
    'back': 'Retour',
    'golden_treat': 'Un trésor doré pour ton ami !',
    'chest_won': 'Tu as gagné un coffre !',
    'great': 'Super !',
  },
};

String rT(String k) => (_rs[L.lang] ?? _rs['ar']!)[k] ?? k;

// ───────────── الإعدادات ─────────────

enum ChestTier { wood, silver, gold }

class DayGift {
  final int coins;
  final ChestTier? chest;
  const DayGift(this.coins, [this.chest]);
}

/// هدايا الأيام السبعة. اليوم السابع هو الأكبر.
const kDailyGifts = [
  DayGift(10),
  DayGift(15),
  DayGift(20, ChestTier.wood),
  DayGift(25),
  DayGift(30),
  DayGift(40, ChestTier.silver),
  DayGift(50, ChestTier.gold),
];

/// أقصى عدد صناديق تُربح من المغامرة في اليوم (حتى لا تتكرر بلا حد).
const kMaxWinChestsPerDay = 5;

// ───────────── حفظ البيانات ─────────────

String _dayStr(DateTime d) => d.toIso8601String().substring(0, 10);
String get _today => _dayStr(DateTime.now());
String get _yesterday => _dayStr(DateTime.now().subtract(const Duration(days: 1)));

class Rewards {
  static Future<int> wallet() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getInt('coins') ?? 30;
  }

  static Future<void> _addCoins(SharedPreferences sp, int n) async {
    await sp.setInt('coins', (sp.getInt('coins') ?? 30) + n);
  }

  static String _key(ChestTier t) => 'chest_${t.name}';

  static Future<Map<ChestTier, int>> chests() async {
    final sp = await SharedPreferences.getInstance();
    return {for (final t in ChestTier.values) t: sp.getInt(_key(t)) ?? 0};
  }

  static Future<int> chestCount() async {
    final c = await chests();
    return c.values.fold<int>(0, (a, b) => a + b);
  }

  static Future<void> addChest(ChestTier t) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_key(t), (sp.getInt(_key(t)) ?? 0) + 1);
  }

  /// يُستدعى عند الانتصار في المغامرة. يرجع نوع الصندوق الذي رُبح، أو null.
  static Future<ChestTier?> onAdventureWon(int stars) async {
    try {
      final sp = await SharedPreferences.getInstance();
      if (sp.getString('chest_win_day') != _today) {
        await sp.setString('chest_win_day', _today);
        await sp.setInt('chest_win_count', 0);
      }
      final n = sp.getInt('chest_win_count') ?? 0;
      if (n >= kMaxWinChestsPerDay) return null;
      await sp.setInt('chest_win_count', n + 1);
      final tier = stars >= 3 ? ChestTier.silver : ChestTier.wood;
      await addChest(tier);
      return tier;
    } catch (_) {
      return null;
    }
  }

  // ---- المكافأة اليومية ----

  static Future<bool> dailyAvailable() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getString('daily_last') != _today;
  }

  /// رقم اليوم الذي سيأخذه الطفل الآن (1..7)، وهل انقطعت السلسلة.
  static Future<(int, bool)> dailyNext() async {
    final sp = await SharedPreferences.getInstance();
    final last = sp.getString('daily_last') ?? '';
    final streak = sp.getInt('daily_streak') ?? 0;
    if (last == _today) return (streak == 0 ? 1 : streak, false);
    if (last == _yesterday && streak > 0) return (streak % 7 + 1, false);
    return (1, last.isNotEmpty && streak > 0);
  }

  static Future<DayGift?> claimDaily() async {
    final sp = await SharedPreferences.getInstance();
    if (sp.getString('daily_last') == _today) return null;
    final (day, _) = await dailyNext();
    final g = kDailyGifts[day - 1];
    await _addCoins(sp, g.coins);
    if (g.chest != null) await addChest(g.chest!);
    await sp.setInt('daily_streak', day);
    await sp.setString('daily_last', _today);
    return g;
  }

  // ---- فتح الصندوق ----

  /// يفتح صندوقاً واحداً ويرجع (عملات، ثمرة ذهبية؟).
  static Future<(int, bool)?> openChest(ChestTier t) async {
    final sp = await SharedPreferences.getInstance();
    final have = sp.getInt(_key(t)) ?? 0;
    if (have <= 0) return null;
    final r = Random();
    late int coins;
    late bool golden;
    switch (t) {
      case ChestTier.wood:
        coins = 10 + r.nextInt(16);
        golden = r.nextDouble() < .1;
        break;
      case ChestTier.silver:
        coins = 25 + r.nextInt(26);
        golden = r.nextDouble() < .35;
        break;
      case ChestTier.gold:
        coins = 60 + r.nextInt(61);
        golden = true;
        break;
    }
    await sp.setInt(_key(t), have - 1);
    await _addCoins(sp, coins);
    if (golden) await sp.setInt('pet_golden', (sp.getInt('pet_golden') ?? 0) + 1);
    return (coins, golden);
  }
}

// ───────────── رسم الصندوق ─────────────

class _Palette {
  final Color body, bodyDark, band, bandDark;
  const _Palette(this.body, this.bodyDark, this.band, this.bandDark);
}

const _palettes = {
  ChestTier.wood: _Palette(Color(0xFFA1662F), Color(0xFF6D3F17), Color(0xFF8D99A6), Color(0xFF546270)),
  ChestTier.silver: _Palette(Color(0xFF3F6FB5), Color(0xFF1F3F75), Color(0xFFE0E6EE), Color(0xFF9AA6B4)),
  ChestTier.gold: _Palette(Color(0xFFB0283A), Color(0xFF6E1020), Color(0xFFFFD54F), Color(0xFFC79100)),
};

/// صندوق كنز مرسوم بالكود. [open] من 0 (مغلق) إلى 1 (مفتوح تماماً).
class ChestPainter extends CustomPainter {
  final ChestTier tier;
  final double open;
  final double spin;
  ChestPainter(this.tier, {this.open = 0, this.spin = 0});

  @override
  void paint(Canvas c, Size s) {
    final p = _palettes[tier]!;
    final w = s.width, h = s.height;
    final bodyTop = h * .45, bodyBottom = h * .95;
    final left = w * .08, right = w * .92;

    // ضوء وأشعة عند الفتح
    if (open > 0) {
      final center = Offset(w / 2, bodyTop);
      final rays = Paint()..color = const Color(0xFFFFF59D).withValues(alpha: .35 * open);
      for (var i = 0; i < 12; i++) {
        final a = spin + i * pi / 6;
        final path = Path()
          ..moveTo(center.dx, center.dy)
          ..lineTo(center.dx + cos(a - .1) * w * 1.1, center.dy + sin(a - .1) * w * 1.1)
          ..lineTo(center.dx + cos(a + .1) * w * 1.1, center.dy + sin(a + .1) * w * 1.1)
          ..close();
        c.drawPath(path, rays);
      }
      c.drawCircle(center, w * .55 * open, Paint()
        ..shader = RadialGradient(colors: [const Color(0xFFFFF9C4).withValues(alpha: open), const Color(0x00FFF176)])
            .createShader(Rect.fromCircle(center: center, radius: w * .55)));
    }

    // الظل
    c.drawOval(Rect.fromLTRB(left, bodyBottom - h * .03, right, bodyBottom + h * .05),
        Paint()..color = Colors.black.withValues(alpha: .3));

    // جسم الصندوق
    final body = RRect.fromLTRBR(left, bodyTop, right, bodyBottom, Radius.circular(w * .06));
    c.drawRRect(body, Paint()
      ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [p.body, p.bodyDark])
          .createShader(body.outerRect));
    // ألواح الخشب
    final plank = Paint()
      ..color = p.bodyDark.withValues(alpha: .5)
      ..strokeWidth = 2;
    for (var i = 1; i < 3; i++) {
      final y = bodyTop + (bodyBottom - bodyTop) * i / 3;
      c.drawLine(Offset(left + 4, y), Offset(right - 4, y), plank);
    }
    // الأشرطة المعدنية
    final band = Paint()..color = p.band;
    final bandEdge = Paint()
      ..color = p.bandDark
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    for (final x in [w * .2, w * .72]) {
      final r = Rect.fromLTWH(x, bodyTop, w * .08, bodyBottom - bodyTop);
      c.drawRect(r, band);
      c.drawRect(r, bandEdge);
    }
    c.drawRRect(body, Paint()
      ..color = Colors.white.withValues(alpha: .9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3);

    // داخل الصندوق المضيء
    if (open > 0) {
      final inner = Rect.fromLTRB(left + 6, bodyTop - 2, right - 6, bodyTop + h * .06);
      c.drawRect(inner, Paint()..color = Color.lerp(const Color(0xFF3E2723), const Color(0xFFFFEE58), open)!);
    }

    // الغطاء: يدور حول الحافة الخلفية (نقلبه عمودياً)
    final lidH = h * .26;
    c.save();
    c.translate(0, bodyTop);
    final flip = 1 - 1.7 * open; // 1 مغلق → -0.7 مفتوح
    c.scale(1, flip);
    final lid = Path()
      ..moveTo(left, 0)
      ..lineTo(left, -lidH * .45)
      ..quadraticBezierTo(w / 2, -lidH * 1.45, right, -lidH * .45)
      ..lineTo(right, 0)
      ..close();
    c.drawPath(lid, Paint()
      ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
          colors: open > .5 ? [p.bodyDark, p.body] : [Color.lerp(p.body, Colors.white, .2)!, p.body])
          .createShader(Rect.fromLTRB(left, -lidH, right, 0)));
    for (final x in [w * .2, w * .72]) {
      c.drawRect(Rect.fromLTWH(x, -lidH * 1.05, w * .08, lidH * 1.05), band);
    }
    c.drawPath(lid, Paint()
      ..color = Colors.white.withValues(alpha: .9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3);
    c.restore();

    // القفل
    if (open < .3) {
      final lockR = RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(w / 2, bodyTop + h * .05), width: w * .16, height: h * .16), Radius.circular(w * .03));
      c.drawRRect(lockR, Paint()..color = const Color(0xFFFFD54F));
      c.drawRRect(lockR, Paint()
        ..color = const Color(0xFF8D6E00)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5);
      c.drawCircle(Offset(w / 2, bodyTop + h * .04), w * .022, Paint()..color = const Color(0xFF3E2723));
      c.drawRect(Rect.fromCenter(center: Offset(w / 2, bodyTop + h * .08), width: w * .018, height: h * .05),
          Paint()..color = const Color(0xFF3E2723));
    }
  }

  @override
  bool shouldRepaint(covariant ChestPainter o) => o.open != open || o.spin != spin || o.tier != tier;
}

// ───────────── جزيئات العملات ─────────────

class _Coin {
  Offset p, v;
  double rot;
  final double vr, size;
  double age = 0;
  _Coin(this.p, this.v, this.rot, this.vr, this.size);
}

class _CoinPainter extends CustomPainter {
  final List<_Coin> coins;
  final int frame;
  _CoinPainter(this.coins, this.frame);

  @override
  void paint(Canvas c, Size s) {
    for (final k in coins) {
      final a = (1 - (k.age - 1.2).clamp(0.0, 1.0)).toDouble();
      if (a <= 0) continue;
      c.save();
      c.translate(k.p.dx, k.p.dy);
      // دوران العملة حول محورها: نضغطها أفقياً
      c.scale(cos(k.rot).abs() * .8 + .2, 1);
      final r = k.size;
      c.drawCircle(Offset.zero, r, Paint()..color = const Color(0xFFC79100).withValues(alpha: a));
      c.drawCircle(Offset.zero, r * .8, Paint()
        ..shader = const RadialGradient(colors: [Color(0xFFFFF59D), Color(0xFFFFC107)])
            .createShader(Rect.fromCircle(center: Offset.zero, radius: r)));
      c.drawCircle(Offset.zero, r * .45, Paint()
        ..color = const Color(0xFFE0A000).withValues(alpha: a)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2);
      c.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _CoinPainter o) => true;
}

/// يدير انفجار العملات في أي شاشة.
mixin _CoinBurst<T extends StatefulWidget> on State<T>, TickerProvider {
  final List<_Coin> coinParts = [];
  late final Ticker _coinTicker;
  Duration _coinLast = Duration.zero;
  int coinFrame = 0;
  final _rnd = Random();

  void initCoins() {
    _coinTicker = createTicker((d) {
      final dt = ((d - _coinLast).inMicroseconds / 1e6).clamp(0.0, .05).toDouble();
      _coinLast = d;
      if (coinParts.isEmpty) return;
      for (final k in coinParts) {
        k.age += dt;
        k.v = Offset(k.v.dx * .99, k.v.dy + 900 * dt);
        k.p += k.v * dt;
        k.rot += k.vr * dt;
      }
      coinParts.removeWhere((k) => k.age > 2.3);
      if (mounted) setState(() => coinFrame++);
    })
      ..start();
  }

  void disposeCoins() => _coinTicker.dispose();

  void burstCoins(Offset from, int n) {
    for (var i = 0; i < n; i++) {
      final a = -pi / 2 + (_rnd.nextDouble() - .5) * 2.2;
      final sp = 350 + _rnd.nextDouble() * 450;
      coinParts.add(_Coin(from, Offset(cos(a) * sp, sin(a) * sp), _rnd.nextDouble() * 6, 6 + _rnd.nextDouble() * 10,
          10 + _rnd.nextDouble() * 8));
    }
  }

  Widget coinLayer() => Positioned.fill(
      child: IgnorePointer(child: CustomPaint(painter: _CoinPainter(coinParts, coinFrame))));
}

Widget _rewardPanel(Widget child) => Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xF2FFF8E1),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0xFFFF6F00), width: 5),
        boxShadow: [
          const BoxShadow(color: Color(0xFFBF360C), offset: Offset(0, 8)),
          BoxShadow(color: Colors.black.withValues(alpha: .45), offset: const Offset(0, 14), blurRadius: 18),
        ],
      ),
      child: child,
    );

String _chestName(ChestTier t) => rT(t.name);

// ───────────── نافذة المكافأة اليومية ─────────────

Future<void> showDailyReward(BuildContext context) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'daily',
    barrierColor: const Color(0xAA000000),
    transitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (_, __, ___) => const DailyRewardDialog(),
    transitionBuilder: (_, a, __, child) =>
        ScaleTransition(scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack), child: child),
  );
}

class DailyRewardDialog extends StatefulWidget {
  const DailyRewardDialog({super.key});
  @override
  State<DailyRewardDialog> createState() => _DailyRewardDialogState();
}

class _DailyRewardDialogState extends State<DailyRewardDialog> with TickerProviderStateMixin<DailyRewardDialog>, _CoinBurst<DailyRewardDialog> {
  int day = 1;
  bool lost = false, available = false, claimed = false, loading = true;
  final _todayKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    initCoins();
    () async {
      final (d, l) = await Rewards.dailyNext();
      final av = await Rewards.dailyAvailable();
      if (!mounted) return;
      setState(() {
        day = d;
        lost = l;
        available = av;
        claimed = !av;
        loading = false;
      });
    }();
  }

  @override
  void dispose() {
    disposeCoins();
    super.dispose();
  }

  Future<void> _claim() async {
    final g = await Rewards.claimDaily();
    if (!mounted || g == null) return;
    // انفجار العملات من مربع اليوم
    final box = _todayKey.currentContext?.findRenderObject() as RenderBox?;
    final me = context.findRenderObject() as RenderBox?;
    var from = Offset(MediaQuery.of(context).size.width / 2, MediaQuery.of(context).size.height / 2);
    if (box != null && me != null) {
      from = me.globalToLocal(box.localToGlobal(box.size.center(Offset.zero)));
    }
    burstCoins(from, 18 + g.coins ~/ 3);
    Sfx.play('win');
    Sfx.play('coin');
    Buzz.win();
    for (var i = 1; i <= 6; i++) {
      Future.delayed(Duration(milliseconds: 120 * i), () => Sfx.play('coin', minGapMs: 0, volume: .7));
    }
    setState(() {
      claimed = true;
      available = false;
    });
  }

  Widget _tile(int i) {
    final d = i + 1;
    final g = kDailyGifts[i];
    final isToday = d == day;
    final past = d < day || (isToday && claimed);
    final big = d == 7;
    Widget content = Column(mainAxisSize: MainAxisSize.min, children: [
      Text('${rT('day')} ${L.num(d)}',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: isToday ? Colors.white : const Color(0xFF5D4037))),
      const SizedBox(height: 2),
      if (g.chest != null)
        SizedBox(width: big ? 46 : 34, height: big ? 40 : 30, child: CustomPaint(painter: ChestPainter(g.chest!)))
      else
        const Text('🪙', style: TextStyle(fontSize: 26)),
      Text('+${L.num(g.coins)}',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: isToday ? Colors.white : const Color(0xFFE65100))),
    ]);
    if (past) {
      content = Stack(alignment: Alignment.center, children: [
        Opacity(opacity: .45, child: content),
        const Text('✅', style: TextStyle(fontSize: 28)),
      ]);
    }
    final tile = Container(
      key: isToday ? _todayKey : null,
      width: big ? 86 : 70,
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      decoration: BoxDecoration(
        color: isToday && !claimed ? const Color(0xFFFF6F00) : (big ? const Color(0xFFFFE082) : Colors.white),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isToday ? const Color(0xFFFFEB3B) : const Color(0xFFBCAAA4), width: isToday ? 4 : 2),
        boxShadow: const [BoxShadow(color: Color(0x55000000), offset: Offset(0, 4), blurRadius: 4)],
      ),
      child: content,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: isToday && !claimed ? Pulse(amount: .08, child: tile) : tile,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: L.dir,
      child: Material(
        type: MaterialType.transparency,
        child: Stack(children: [
          Center(
            child: SingleChildScrollView(
              child: _rewardPanel(Column(mainAxisSize: MainAxisSize.min, children: [
                OutlinedText('🎁 ${rT('daily')}', size: 30, color: const Color(0xFFFFEB3B)),
                if (lost && !claimed)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(rT('streak_lost'),
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFFD84315))),
                  ),
                const SizedBox(height: 10),
                if (loading)
                  const SizedBox(height: 90, child: Center(child: CircularProgressIndicator()))
                else
                  Directionality(
                    textDirection: L.dir,
                    child: Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end,
                        children: [for (var i = 0; i < 7; i++) _tile(i)]),
                  ),
                const SizedBox(height: 14),
                if (available)
                  Pulse(amount: .06, child: Btn3D(
                    color: const Color(0xFF43A047),
                    padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    onTap: _claim,
                    child: Text(rT('claim'), style: const TextStyle(fontSize: 24)),
                  ))
                else if (!loading) ...[
                  Text(rT('come_back'),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF00897B))),
                  const SizedBox(height: 10),
                  Btn3D(
                    color: const Color(0xFFFF6F00),
                    onTap: () => Navigator.of(context).pop(),
                    child: Text(rT('great')),
                  ),
                ],
              ])),
            ),
          ),
          coinLayer(),
        ]),
      ),
    );
  }
}

// ───────────── شاشة صناديق الكنز ─────────────

class ChestScreen extends StatefulWidget {
  const ChestScreen({super.key});
  @override
  State<ChestScreen> createState() => _ChestScreenState();
}

class _ChestScreenState extends State<ChestScreen> with TickerProviderStateMixin<ChestScreen>, _CoinBurst<ChestScreen> {
  Map<ChestTier, int> have = {for (final t in ChestTier.values) t: 0};
  int wallet = 0;
  ChestTier? sel;
  int taps = 0;
  double open = 0, shake = 0, spin = 0;
  (int, bool)? result;
  late final AnimationController _anim = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
  late final AnimationController _rays = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  late final AnimationController _shakeC = AnimationController(vsync: this, duration: const Duration(milliseconds: 380));
  final _chestKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    initCoins();
    _anim.addListener(() => setState(() => open = Curves.easeOutBack.transform(_anim.value).clamp(0.0, 1.0).toDouble()));
    _shakeC.addListener(() => setState(() => shake = _shakeC.value));
    _reload();
  }

  @override
  void dispose() {
    _anim.dispose();
    _rays.dispose();
    _shakeC.dispose();
    disposeCoins();
    super.dispose();
  }

  Future<void> _reload() async {
    final c = await Rewards.chests();
    final w = await Rewards.wallet();
    if (!mounted) return;
    setState(() {
      have = c;
      wallet = w;
    });
  }

  void _pick(ChestTier t) {
    if ((have[t] ?? 0) <= 0) {
      Sfx.play('wrong');
      Buzz.wrong();
      return;
    }
    Sfx.play('whoosh');
    Buzz.tick();
    _anim.value = 0;
    setState(() {
      sel = t;
      taps = 0;
      open = 0;
      result = null;
    });
  }

  Future<void> _tapChest() async {
    if (sel == null || result != null || taps >= 3) return;
    taps++;
    _shakeC.forward(from: 0);
    if (taps < 3) {
      Sfx.play(taps == 1 ? 'crate' : 'gate_crack');
      Buzz.crack();
      setState(() {});
      return;
    }
    final r = await Rewards.openChest(sel!);
    if (!mounted || r == null) return;
    Sfx.play('gate_break');
    Sfx.play('magic');
    Buzz.boom();
    _anim.forward(from: 0);
    final box = _chestKey.currentContext?.findRenderObject() as RenderBox?;
    final me = context.findRenderObject() as RenderBox?;
    if (box != null && me != null) {
      final c = me.globalToLocal(box.localToGlobal(Offset(box.size.width / 2, box.size.height * .45)));
      burstCoins(c, 14 + r.$1 ~/ 3);
    }
    for (var i = 1; i <= 8; i++) {
      Future.delayed(Duration(milliseconds: 100 * i), () => Sfx.play('coin', minGapMs: 0, volume: .7));
    }
    Future.delayed(const Duration(milliseconds: 500), () {
      Sfx.play('win');
      Buzz.win();
    });
    setState(() => result = r);
    _reload();
  }

  Widget _shelfItem(ChestTier t) {
    final n = have[t] ?? 0;
    final isSel = sel == t;
    return GestureDetector(
      onTap: () => _pick(t),
      child: AnimatedScale(
        scale: isSel ? 1.1 : 1,
        duration: const Duration(milliseconds: 200),
        child: Opacity(
          opacity: n > 0 ? 1 : .4,
          child: Container(
            width: 96,
            margin: const EdgeInsets.symmetric(vertical: 5),
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: isSel ? const Color(0xFFFFF8E1) : const Color(0xCCFFFFFF),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: isSel ? const Color(0xFFFF6F00) : Colors.white, width: isSel ? 4 : 2),
            ),
            child: Stack(clipBehavior: Clip.none, children: [
              Column(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(width: 64, height: 52, child: CustomPaint(painter: ChestPainter(t))),
                Text(_chestName(t),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Color(0xFF4E342E))),
              ]),
              if (n > 0)
                Positioned(
                  top: -10, right: -10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white, width: 2)),
                    child: Text(L.num(n), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _stage(Size size) {
    final total = have.values.fold<int>(0, (a, b) => a + b);
    if (sel == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: OutlinedText(total == 0 ? rT('no_chests') : rT('tap_open'), size: 22, color: const Color(0xFFFFF59D)),
        ),
      );
    }
    final cs = min(size.height * .55, 240.0);
    // اهتزاز يكبر مع كل ضغطة
    final amp = 6.0 + taps * 6;
    final dx = sin(shake * pi * 8) * amp * (1 - shake);
    final rot = sin(shake * pi * 6) * .06 * taps * (1 - shake);
    final grow = 1 + taps * .06 + (result != null ? .1 * open : 0);
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      if (result == null)
        Pulse(child: OutlinedText('👆 ${L.num(3 - taps)}', size: 30, color: const Color(0xFFFFEB3B)))
      else
        PopIn(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            OutlinedText('+${L.num(result!.$1)} 🪙', size: 40, color: const Color(0xFFFFEB3B)),
            if (result!.$2) OutlinedText('🌟 ${rT('golden_treat')}', size: 20, color: const Color(0xFFFFF59D)),
          ]),
        ),
      GestureDetector(
        onTap: _tapChest,
        child: Transform.translate(
          offset: Offset(dx, 0),
          child: Transform.rotate(
            angle: rot,
            child: Transform.scale(
              scale: grow,
              child: SizedBox(
                key: _chestKey,
                width: cs, height: cs * .85,
                child: CustomPaint(painter: ChestPainter(sel!, open: open, spin: _rays.value * 2 * pi)),
              ),
            ),
          ),
        ),
      ),
      if (result != null)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: (have[sel!] ?? 0) > 0
              ? Btn3D(color: const Color(0xFF43A047), onTap: () => _pick(sel!), child: Text(rT('open_another')))
              : Btn3D(color: const Color(0xFF78909C), onTap: () => setState(() { sel = null; result = null; }), child: Text(rT('great'))),
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Directionality(
      textDirection: L.dir,
      child: Scaffold(
        body: AnimatedBuilder(
          animation: _rays,
          builder: (_, __) => Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(colors: [Color(0xFF6A1B9A), Color(0xFF1A0033)], radius: 1.1),
            ),
            child: SafeArea(
              child: Stack(children: [
                Row(children: [
                  // رف الصناديق
                  SizedBox(
                    width: 120,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.only(top: 56),
                      child: Column(children: [for (final t in ChestTier.values) _shelfItem(t)]),
                    ),
                  ),
                  Expanded(child: _stage(size)),
                ]),
                Positioned(
                  top: 6, left: 8, right: 8,
                  child: Row(children: [
                    Btn3D(
                      color: const Color(0xFF78909C), depth: 4, radius: 14,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      onTap: () => Navigator.of(context).pop(),
                      child: Text(rT('back'), style: const TextStyle(fontSize: 18)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: OutlinedText('🧰 ${rT('chests')}', size: 24, color: const Color(0xFFFFEB3B))),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(color: const Color(0xAA000000), borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white70, width: 2)),
                      child: PopIn(
                        key: ValueKey(wallet),
                        child: Text('🪙 ${L.num(wallet)}',
                            style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                      ),
                    ),
                  ]),
                ),
                coinLayer(),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

// ───────────── أزرار القائمة ─────────────

/// زر بشارة حمراء (عدد أو نقطة).
class BadgeButton extends StatelessWidget {
  final Widget icon;
  final String? badge;
  final VoidCallback onTap;
  final bool glow;
  const BadgeButton({super.key, required this.icon, required this.onTap, this.badge, this.glow = false});

  @override
  Widget build(BuildContext context) {
    final b = Stack(clipBehavior: Clip.none, children: [
      IconButton(iconSize: 40, icon: icon, onPressed: onTap),
      if (badge != null)
        Positioned(
          top: 2, right: 2,
          child: IgnorePointer(
            child: Container(
              constraints: const BoxConstraints(minWidth: 20),
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.white, width: 2)),
              child: Text(badge!, textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12)),
            ),
          ),
        ),
    ]);
    return glow ? Pulse(amount: .12, child: b) : b;
  }
}
