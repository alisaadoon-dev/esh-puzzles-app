import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'audio.dart';
import 'engine.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'painter.dart';
import 'puzzles.dart';
import 'shapes.dart';
import 'sprites.dart';
import 'widgets.dart';

// ======================= MENU =======================
class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  HeroKind hero = HeroKind.owl;

  @override
  void initState() {
    super.initState();
    Sfx.music('forest', volume: .35);
  }

  Widget _heroPic(HeroKind h, double size) {
    final img = Sprites.get(h == HeroKind.owl ? 'owl_happy' : 'fox_happy') ?? Sprites.get(h == HeroKind.owl ? 'owl' : 'fox');
    if (img != null) return RawImage(image: img, height: size, fit: BoxFit.contain);
    return Text(h == HeroKind.owl ? '🦉' : '🦊', style: TextStyle(fontSize: size * .8));
  }

  Widget _heroCard(HeroKind h) {
    final sel = hero == h;
    return GestureDetector(
      onTap: () {
        setState(() => hero = h);
        Sfx.play(h == HeroKind.owl ? 'double_jump' : 'dash');
        Buzz.tick();
      },
      child: AnimatedScale(
        scale: sel ? 1.08 : .92,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutBack,
        child: Container(
          width: 170,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: sel ? const Color(0xFFFFF8E1) : const Color(0xCCFFFFFF),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: sel ? const Color(0xFFFF6F00) : Colors.white, width: sel ? 5 : 3),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .3), offset: const Offset(0, 6), blurRadius: 10)],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            SizedBox(height: 90, child: sel ? Pulse(amount: .06, child: _heroPic(h, 90)) : _heroPic(h, 90)),
            Text(L.t(h == HeroKind.owl ? 'owl' : 'fox'),
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF4E342E))),
            Text(L.t(h == HeroKind.owl ? 'owl_power' : 'fox_power'), textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF6D4C41))),
          ]),
        ),
      ),
    );
  }

  Widget _langChip(String code, String label) {
    final sel = L.lang == code;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ChoiceChip(
        label: Text(label, style: TextStyle(fontWeight: FontWeight.w800, color: sel ? Colors.white : const Color(0xFF4E342E))),
        selected: sel,
        selectedColor: const Color(0xFFFF6F00),
        backgroundColor: Colors.white,
        onSelected: (_) => setState(() { L.lang = code; Sfx.play('click'); }),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: L.dir,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                colors: [Color(0xFF4FC3F7), Color(0xFF81C784), Color(0xFF388E3C)]),
          ),
          child: SafeArea(
            child: Stack(children: [
              Positioned(top: 4, left: 8, child: Row(children: [
                IconButton(
                  icon: Icon(Sfx.enabled ? Icons.volume_up_rounded : Icons.volume_off_rounded, color: Colors.white, size: 30),
                  onPressed: () => setState(() {
                    Sfx.enabled = !Sfx.enabled;
                    if (Sfx.enabled) { Sfx.music('forest', volume: .35); } else { Sfx.stopAll(); }
                  }),
                ),
                IconButton(
                  icon: Icon(Buzz.enabled ? Icons.vibration_rounded : Icons.phone_android_rounded, color: Colors.white, size: 30),
                  onPressed: () => setState(() { Buzz.enabled = !Buzz.enabled; Buzz.tick(); }),
                ),
              ])),
              Positioned(top: 8, right: 8, child: Directionality(textDirection: TextDirection.ltr, child: Row(children: [
                _langChip('ar', 'العربية'), _langChip('en', 'English'), _langChip('fr', 'Français'),
              ]))),
              Center(
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const SizedBox(height: 30),
                    PopIn(child: OutlinedText(L.t('title'), size: 44, color: const Color(0xFFFFEB3B))),
                    OutlinedText(L.t('subtitle'), size: 20),
                    const SizedBox(height: 10),
                    OutlinedText(L.t('choose'), size: 18, color: const Color(0xFFFFF3E0)),
                    const SizedBox(height: 8),
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      _heroCard(HeroKind.owl), const SizedBox(width: 22), _heroCard(HeroKind.fox),
                    ]),
                    const SizedBox(height: 16),
                    Pulse(amount: .05, child: Btn3D(
                      color: const Color(0xFFFF6F00),
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
                      onTap: () {
                        Navigator.of(context).push(PageRouteBuilder(
                          transitionDuration: const Duration(milliseconds: 500),
                          pageBuilder: (_, __, ___) => GameScreen(hero: hero),
                          transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
                        )).then((_) { if (mounted) setState(() {}); Sfx.music('forest', volume: .35); });
                      },
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
                        const SizedBox(width: 6),
                        Text(L.t('play'), style: const TextStyle(fontSize: 24)),
                      ]),
                    )),
                    const SizedBox(height: 20),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ======================= GAME =======================
class GameScreen extends StatefulWidget {
  final HeroKind hero;
  const GameScreen({super.key, required this.hero});
  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late Engine e;
  late final Ticker _ticker;
  Duration _last = Duration.zero;
  final List<Offset> _stroke = [];
  Offset? _start;
  DateTime _startT = DateTime.now();
  bool _consumed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    e = Engine(widget.hero);
    e.beginIntro();
    _ticker = createTicker((elapsed) {
      final dt = (elapsed - _last).inMicroseconds / 1e6;
      _last = elapsed;
      e.update(dt);
    })..start();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) {
      e.pause();
      Sfx.setMusicVolume(0);
    } else {
      Sfx.setMusicVolume(.45);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    e.dispose();
    super.dispose();
  }

  void _restart({HeroKind? hero}) {
    final old = e;
    setState(() {
      e = Engine(hero ?? old.hero);
      e.startPlay();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old.dispose());
  }

  bool get _drawing => e.mode == Mode.drawBridge || e.mode == Mode.drawShield;

  // ---- touch ----
  void _down(PointerDownEvent ev) {
    _start = ev.localPosition;
    _startT = DateTime.now();
    _consumed = false;
    _stroke
      ..clear()
      ..add(ev.localPosition);
  }

  void _move(PointerMoveEvent ev) {
    if (_start == null) return;
    if (_drawing) {
      _stroke.add(ev.localPosition);
      return;
    }
    if (_consumed) return;
    final d = ev.localPosition - _start!;
    if (d.distance > 34) {
      _consumed = true;
      if (d.dy.abs() > d.dx.abs()) {
        e.swipe(d.dy < 0 ? Swipe.up : Swipe.down);
      } else {
        e.swipe(d.dx > 0 ? Swipe.forward : Swipe.back);
      }
    }
  }

  void _up(PointerUpEvent ev) {
    final size = MediaQuery.of(context).size;
    if (_drawing && _stroke.length > 3) {
      final pts = List<Offset>.from(_stroke);
      String shape = 'none';
      if (e.mode == Mode.drawBridge && Shapes.isLine(pts, size.width * .22)) shape = 'line';
      if (e.mode == Mode.drawShield && Shapes.isCircle(pts, size.height * .14)) shape = 'circle';
      e.drawn(shape);
    } else if (!_consumed && _start != null && DateTime.now().difference(_startT).inMilliseconds < 300) {
      e.swipe(Swipe.tap);
    }
    _start = null;
    Future.delayed(const Duration(milliseconds: 250), () { if (mounted) _stroke.clear(); });
  }

  // ---- UI ----
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) { if (!didPop) e.pause(); },
      child: Directionality(
        textDirection: L.dir,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: Stack(children: [
            Positioned.fill(
              child: Listener(
                behavior: HitTestBehavior.opaque,
                onPointerDown: _down,
                onPointerMove: _move,
                onPointerUp: _up,
                child: CustomPaint(painter: GamePainter(e, _stroke)),
              ),
            ),
            Positioned.fill(
              child: ValueListenableBuilder<int>(
                valueListenable: e.ui,
                builder: (_, __, ___) => _overlay(context),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _overlay(BuildContext context) {
    final kids = <Widget>[];
    if (e.mode != Mode.intro) kids.add(_hud());
    if (e.subtitle != null && e.mode != Mode.intro) {
      kids.add(Positioned(
        left: 0, right: 0, bottom: e.mode == Mode.puzzle ? null : 14, top: e.mode == Mode.puzzle ? 54 : null,
        child: IgnorePointer(child: Center(child: PopIn(
          key: ValueKey(e.subtitle),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            decoration: BoxDecoration(color: const Color(0xDD1A237E), borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white, width: 2.5)),
            child: Text(e.subtitle!, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
          ),
        ))),
      ));
    }
    if (e.waitFor != null) kids.add(_tutorialHint());
    if (_drawing) {
      kids.add(Positioned(
        top: 60, left: 0, right: 0,
        child: IgnorePointer(child: Center(child: Pulse(child: OutlinedText(
          '✍️ ${L.t('draw_here')}', size: 22, color: const Color(0xFFFFF59D))))),
      ));
    }
    switch (e.mode) {
      case Mode.intro:
        kids.add(_intro());
        break;
      case Mode.puzzle:
        if (e.puzzle != null) kids.add(_puzzle(e.puzzle!));
        break;
      case Mode.paused:
        kids.add(_pauseMenu());
        break;
      case Mode.dead:
        kids.add(_dead());
        break;
      case Mode.win:
        kids.add(_win());
        break;
      default:
        break;
    }
    return Stack(children: kids);
  }

  Widget _hud() {
    final hearts = List.generate(3, (i) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 1),
      child: AnimatedScale(
        scale: i < e.hearts ? 1 : .7,
        duration: const Duration(milliseconds: 300),
        child: Text(i < e.hearts ? '❤️' : '🤍', style: const TextStyle(fontSize: 26)),
      ),
    ));
    Widget pill(Widget child) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(color: const Color(0xAA000000), borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white70, width: 2)),
          child: child,
        );
    return Positioned(
      top: 8, left: 10, right: 10,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          pill(Row(children: hearts)),
          const SizedBox(width: 8),
          pill(Row(children: [
            Container(
              width: 26, height: 26, alignment: Alignment.center,
              decoration: const BoxDecoration(shape: BoxShape.circle,
                  gradient: RadialGradient(colors: [Color(0xFFFFE082), Color(0xFFF9A825)])),
              child: const Text('🦉', style: TextStyle(fontSize: 14)),
            ),
            const SizedBox(width: 6),
            PopIn(key: ValueKey(e.coins), child: Text(L.num(e.coins),
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900))),
          ])),
          const SizedBox(width: 8),
          pill(Text('🥚 ${L.num(e.eggsFound.length)}/${L.num(3)}',
              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900))),
          const Spacer(),
          if (e.mode != Mode.win && e.mode != Mode.dead)
            Btn3D(
              color: const Color(0xFF29B6F6),
              depth: 4,
              radius: 14,
              padding: const EdgeInsets.all(6),
              onTap: e.pause,
              child: const Icon(Icons.pause_rounded, color: Colors.white, size: 28),
            ),
        ]),
      ),
    );
  }

  Widget _tutorialHint() {
    final icon = switch (e.waitFor) {
      'up' => Icons.keyboard_double_arrow_up_rounded,
      'down' => Icons.keyboard_double_arrow_down_rounded,
      _ => Icons.keyboard_double_arrow_right_rounded,
    };
    return Positioned.fill(
      child: IgnorePointer(
        child: Center(
          child: Pulse(amount: .2, child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x88000000),
                border: Border.all(color: const Color(0xFFFFEB3B), width: 4)),
            child: Icon(icon, size: 70, color: const Color(0xFFFFEB3B)),
          )),
        ),
      ),
    );
  }

  Widget _panel({required Widget child, Color color = const Color(0xF2FFF8E1)}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0xFFFF6F00), width: 5),
        boxShadow: [
          const BoxShadow(color: Color(0xFFBF360C), offset: Offset(0, 8)),
          BoxShadow(color: Colors.black.withValues(alpha: .45), offset: const Offset(0, 14), blurRadius: 18),
        ],
      ),
      child: child,
    );
  }

  Widget _intro() {
    const pics = ['🪺✨', '🐦‍⬛💨🥚', ''];
    final step = e.introStep.clamp(0, 2).toInt();
    final keys = ['intro1', 'intro2', 'intro3'];
    final hero = e.hero == HeroKind.owl ? 'owl_happy' : 'fox_happy';
    final img = Sprites.get(hero) ?? Sprites.get(e.hero == HeroKind.owl ? 'owl' : 'fox');
    return Positioned.fill(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: e.nextIntro,
        child: Container(
          decoration: const BoxDecoration(gradient: RadialGradient(colors: [Color(0xFF1B5E20), Color(0xFF081C0A)], radius: 1.1)),
          child: SafeArea(
            child: Stack(children: [
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  PopIn(
                    key: ValueKey(step),
                    child: step == 2
                        ? (img != null
                            ? RawImage(image: img, height: 130)
                            : Text(e.hero == HeroKind.owl ? '🦉' : '🦊', style: const TextStyle(fontSize: 100)))
                        : Text(pics[step], style: const TextStyle(fontSize: 90)),
                  ),
                  const SizedBox(height: 14),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: OutlinedText(L.line(keys[step]), size: 24, color: const Color(0xFFFFF59D), outline: Colors.black),
                  ),
                  const SizedBox(height: 16),
                  Pulse(child: Text(L.rtl ? 'اضغط للمتابعة 👆' : (L.lang == 'fr' ? 'Touche pour continuer 👆' : 'Tap to continue 👆'),
                      style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w700))),
                ]),
              ),
              Positioned(
                bottom: 12, left: 16,
                child: Btn3D(
                  color: const Color(0xFF78909C), depth: 4,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  onTap: e.startPlay,
                  child: Text(L.t('skip'), style: const TextStyle(fontSize: 18)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _puzzle(Puzzle pz) {
    final big = pz.bigOptions;
    final n = pz.options.length;
    final cols = big ? (n <= 4 ? n : (n <= 6 ? 3 : 4)) : n;
    final size = MediaQuery.of(context).size;
    final cell = big ? (n > 6 ? 58.0 : 66.0) : 64.0;
    return Positioned.fill(
      child: Container(
        color: const Color(0x55000000),
        alignment: Alignment.center,
        child: PopIn(
          key: ValueKey(pz),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: size.width * .8, maxHeight: size.height * .86),
            child: _panel(
              child: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(pz.question, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF4E342E))),
                    IconButton(
                      icon: const Icon(Icons.volume_up_rounded, color: Color(0xFFFF6F00), size: 30),
                      onPressed: () => Sfx.say(pz.voice),
                    ),
                  ]),
                  if (pz.show.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: Wrap(alignment: WrapAlignment.center, spacing: 4, runSpacing: 4, children: [
                        for (var i = 0; i < pz.show.length; i++)
                          PopIn(delayMs: i * 60, child: Text(pz.show[i],
                              style: TextStyle(fontSize: pz.show.length > 14 ? 24 : 32, fontWeight: FontWeight.w900, color: const Color(0xFF3E2723)))),
                      ]),
                    ),
                  ],
                  const SizedBox(height: 12),
                  ShakeOnChange(
                    shakeKey: e.wrongPick,
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: SizedBox(
                        width: cols * (cell + 12),
                        child: Wrap(alignment: WrapAlignment.center, spacing: 12, runSpacing: 12, children: [
                          for (var i = 0; i < n; i++)
                            SizedBox(
                              width: cell, height: cell,
                              child: Btn3D(
                                color: e.wrongPick == i ? const Color(0xFFE53935)
                                    : [const Color(0xFF42A5F5), const Color(0xFF66BB6A), const Color(0xFFAB47BC), const Color(0xFFFFA726)][i % 4],
                                padding: EdgeInsets.zero,
                                depth: 6,
                                radius: 16,
                                onTap: () => e.answer(i),
                                child: Text(pz.options[i], style: TextStyle(fontSize: big ? 32 : 28)),
                              ),
                            ),
                        ]),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _pauseMenu() {
    return Positioned.fill(
      child: Container(
        color: const Color(0x99000000),
        alignment: Alignment.center,
        child: _panel(child: Column(mainAxisSize: MainAxisSize.min, children: [
          OutlinedText(L.t('paused'), size: 32, color: const Color(0xFFFFEB3B)),
          const SizedBox(height: 10),
          Row(mainAxisSize: MainAxisSize.min, children: [
            _toggle(Sfx.enabled ? Icons.volume_up_rounded : Icons.volume_off_rounded, L.t('sound'), () {
              Sfx.enabled = !Sfx.enabled;
              if (!Sfx.enabled) { Sfx.stopAll(); } else { Sfx.music(e.chasing ? 'chase' : 'forest'); }
            }),
            const SizedBox(width: 16),
            _toggle(Buzz.enabled ? Icons.vibration_rounded : Icons.phone_android_rounded, L.t('vibration'), () => Buzz.enabled = !Buzz.enabled),
          ]),
          const SizedBox(height: 14),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Btn3D(color: const Color(0xFF66BB6A), onTap: e.resume, child: Text(L.t('resume'))),
            const SizedBox(width: 10),
            Btn3D(color: const Color(0xFFFFA726), onTap: () => _restart(), child: Text(L.t('restart'))),
            const SizedBox(width: 10),
            Btn3D(color: const Color(0xFF78909C), onTap: () => Navigator.of(context).pop(), child: Text(L.t('menu'))),
          ]),
        ])),
      ),
    );
  }

  Widget _toggle(IconData icon, String label, VoidCallback onTap) {
    return Btn3D(
      color: const Color(0xFF5C6BC0),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      onTap: () => setState(onTap),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: Colors.white),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontSize: 18)),
      ]),
    );
  }

  Widget _dead() {
    return Positioned.fill(
      child: Container(
        color: const Color(0xAA000000),
        alignment: Alignment.center,
        child: PopIn(child: _panel(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('💔', style: TextStyle(fontSize: 60)),
          OutlinedText(L.t('game_over'), size: 30, color: const Color(0xFFFF8A80)),
          const SizedBox(height: 14),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Btn3D(color: const Color(0xFF66BB6A), onTap: e.retryFromCheckpoint, child: Text(L.t('retry'))),
            const SizedBox(width: 10),
            Btn3D(color: const Color(0xFF78909C), onTap: () => Navigator.of(context).pop(), child: Text(L.t('menu'))),
          ]),
        ]))),
      ),
    );
  }

  Widget _win() {
    final stars = e.stars;
    final labels = ['star_finish', 'star_eggs', 'star_nohit'];
    final got = [true, e.eggsFound.length >= 3, e.hurtCount == 0];
    final other = e.hero == HeroKind.owl ? HeroKind.fox : HeroKind.owl;
    return Positioned.fill(
      child: Container(
        color: const Color(0x88000000),
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: PopIn(child: _panel(child: Column(mainAxisSize: MainAxisSize.min, children: [
            OutlinedText(L.t('win_title'), size: 36, color: const Color(0xFFFFEB3B)),
            const SizedBox(height: 4),
            Directionality(
              textDirection: TextDirection.ltr,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                for (var i = 0; i < 3; i++)
                  Padding(
                    padding: EdgeInsets.only(bottom: i == 1 ? 14 : 0, left: 4, right: 4),
                    child: PopIn(delayMs: 300 + i * 350, child: Text(i < stars ? '⭐' : '☆',
                        style: TextStyle(fontSize: i == 1 ? 62 : 50, color: const Color(0xFFBDBDBD)))),
                  ),
              ]),
            ),
            for (var i = 0; i < 3; i++)
              Text('${got[i] ? '✅' : '⬜'} ${L.t(labels[i])}',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF4E342E))),
            const SizedBox(height: 6),
            Text('🦉 ${L.num(e.coins)}    🥚 ${L.num(e.eggsFound.length)}/${L.num(3)}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFFE65100))),
            if (e.eggsFound.length < 3) ...[
              const SizedBox(height: 4),
              Text(L.t('egg_hint'), textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFF6D4C41))),
            ],
            const SizedBox(height: 4),
            Text(L.line('teaser'), textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: Color(0xFF00897B))),
            const SizedBox(height: 12),
            Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 10, children: [
              Btn3D(color: const Color(0xFF66BB6A), onTap: () => _restart(), child: Text(L.t('again'))),
              Btn3D(color: const Color(0xFFFF7043), onTap: () => _restart(hero: other), child: Text(L.t('other_hero'))),
              Btn3D(color: const Color(0xFF78909C), onTap: () => Navigator.of(context).pop(), child: Text(L.t('menu'))),
            ]),
          ]))),
        ),
      ),
    );
  }
}
