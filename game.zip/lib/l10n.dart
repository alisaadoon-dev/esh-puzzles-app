import 'package:flutter/widgets.dart';
import 'lines.dart';

/// Current language: 'ar', 'en' or 'fr'.
class L {
  static String lang = 'ar';

  static bool get rtl => lang == 'ar';
  static TextDirection get dir => rtl ? TextDirection.rtl : TextDirection.ltr;

  static const Map<String, Map<String, String>> _ui = {
    'title': {'ar': 'عش الألغاز', 'en': 'Puzzle Nest', 'fr': 'Le Nid des Énigmes'},
    'subtitle': {'ar': 'مغامرة البيضة الذهبية', 'en': 'The Golden Egg Adventure', 'fr': "L'aventure de l'œuf d'or"},
    'choose': {'ar': 'اختر بطلك', 'en': 'Choose your hero', 'fr': 'Choisis ton héros'},
    'owl': {'ar': 'البومة', 'en': 'Owl', 'fr': 'Hibou'},
    'fox': {'ar': 'الثعلب', 'en': 'Fox', 'fr': 'Renard'},
    'owl_power': {'ar': 'قفزة ثانية في الهواء', 'en': 'Double jump in the air', 'fr': 'Double saut en l\'air'},
    'fox_power': {'ar': 'اندفاع يكسر الصناديق', 'en': 'Dash that smashes crates', 'fr': 'Fonce et brise les caisses'},
    'play': {'ar': 'ابدأ المغامرة', 'en': 'Start the adventure', 'fr': "Commencer l'aventure"},
    'skip': {'ar': 'تخطَّ', 'en': 'Skip', 'fr': 'Passer'},
    'paused': {'ar': 'استراحة', 'en': 'Paused', 'fr': 'Pause'},
    'resume': {'ar': 'تابع', 'en': 'Resume', 'fr': 'Continuer'},
    'restart': {'ar': 'من البداية', 'en': 'Restart', 'fr': 'Recommencer'},
    'menu': {'ar': 'القائمة', 'en': 'Menu', 'fr': 'Menu'},
    'sound': {'ar': 'الصوت', 'en': 'Sound', 'fr': 'Son'},
    'vibration': {'ar': 'الاهتزاز', 'en': 'Vibration', 'fr': 'Vibration'},
    'win_title': {'ar': 'انتصار!', 'en': 'Victory!', 'fr': 'Victoire !'},
    'again': {'ar': 'العب مجدداً', 'en': 'Play again', 'fr': 'Rejouer'},
    'other_hero': {'ar': 'جرّب البطل الآخر', 'en': 'Try the other hero', 'fr': "Essaie l'autre héros"},
    'coins': {'ar': 'العملات', 'en': 'Coins', 'fr': 'Pièces'},
    'eggs': {'ar': 'البيض', 'en': 'Eggs', 'fr': 'Œufs'},
    'star_finish': {'ar': 'أنهيت المرحلة', 'en': 'Finished the level', 'fr': 'Niveau terminé'},
    'star_eggs': {'ar': 'جمعت البيضات الثلاث', 'en': 'Found all 3 eggs', 'fr': 'Trouvé les 3 œufs'},
    'star_nohit': {'ar': 'بدون خسارة قلب', 'en': 'No hearts lost', 'fr': 'Aucun cœur perdu'},
    'game_over': {'ar': 'انتهت القلوب!', 'en': 'Out of hearts!', 'fr': 'Plus de cœurs !'},
    'retry': {'ar': 'من آخر نقطة', 'en': 'From checkpoint', 'fr': 'Au dernier point'},
    'egg_hint': {'ar': 'بيضة لم تجدها... ربما مع البطل الآخر؟', 'en': 'An egg is still hidden... maybe the other hero can reach it?', 'fr': "Un œuf reste caché... peut-être que l'autre héros peut l'atteindre ?"},
    'draw_here': {'ar': 'ارسم هنا بإصبعك', 'en': 'Draw here with your finger', 'fr': 'Dessine ici avec ton doigt'},
  };

  static String t(String key) => _ui[key]?[lang] ?? _ui[key]?['en'] ?? key;

  static String line(String key) => kLines[key]?[lang] ?? kLines[key]?['en'] ?? '';

  static String num(int n) {
    if (lang != 'ar') return '$n';
    const d = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return n.toString().split('').map((c) {
      final i = int.tryParse(c);
      return i == null ? c : d[i];
    }).join();
  }
}
