import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'audio.dart';
import 'haptics.dart';
import 'l10n.dart';
import 'outfits.dart';
import 'screens.dart';
import 'sprites.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  // Pick the phone's language when it is one of ours.
  final sys = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
  if (sys == 'en' || sys == 'fr') L.lang = sys;
  await Sfx.init();
  await Buzz.init();
  await Sprites.loadAll(Sfx.assets);
  await Outfits.load();
  runApp(const EshApp());
}

class EshApp extends StatelessWidget {
  const EshApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'عش الألغاز',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF6F00)),
        useMaterial3: true,
      ),
      home: const MenuScreen(),
    );
  }
}
