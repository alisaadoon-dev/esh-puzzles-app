import 'dart:math';
import 'l10n.dart';

/// A multiple-choice puzzle. [show] is the picture row above the answers
/// (may be empty); [options] are the buttons; [answer] is the right index.
class Puzzle {
  final String voice; // voice line key, also the question subtitle
  final List<String> show;
  final List<String> options;
  final int answer;
  final bool bigOptions; // emoji grid (odd-one-out) vs number buttons
  Puzzle(this.voice, this.show, this.options, this.answer, {this.bigOptions = false});
  String get question => L.line(voice);
}

class PuzzleMaker {
  final Random _r;
  final List<String> _recent = [];
  PuzzleMaker([int? seed]) : _r = Random(seed);

  static const _pairs = [
    ['🍎', '🍅'], ['🐶', '🐱'], ['⭐', '🌟'], ['🐟', '🐠'], ['🌙', '🍌'],
    ['🐸', '🐢'], ['🌻', '🌼'], ['🚗', '🚕'], ['🐝', '🐞'], ['🍊', '🍑'],
    ['🦁', '🐯'], ['🍇', '🫐'], ['🐻', '🐼'], ['⚽', '🏀'], ['🌲', '🌳'],
    ['🐔', '🐤'], ['🍩', '🍪'], ['🐭', '🐹'], ['🌧️', '⛈️'], ['🦊', '🐺'],
  ];
  static const _things = ['🍎', '🍌', '⭐', '🐟', '🌸', '🍓', '🐞', '🎈', '🥕', '🐥', '🍄', '💎'];
  static const _shapes = ['🔴', '🔵', '🟢', '🟡', '🟣', '🟠', '🔺', '🔷', '⭐', '❤️'];

  /// difficulty: 1 (easy) .. 4 (hard)
  Puzzle next(int difficulty) {
    final kinds = <String>['odd', 'count', 'pattern'];
    if (difficulty >= 2) kinds.addAll(['add', 'big']);
    if (difficulty >= 3) kinds.addAll(['odd', 'pattern']);
    for (var tries = 0; tries < 20; tries++) {
      final k = kinds[_r.nextInt(kinds.length)];
      final p = _make(k, difficulty);
      final sig = '$k:${p.show.join()}${p.options.join()}';
      if (_recent.contains(sig)) continue;
      // avoid the same kind three times in a row
      if (_recent.length >= 2 && _recent.sublist(_recent.length - 2).every((s) => s.startsWith('$k:'))) continue;
      _recent.add(sig);
      if (_recent.length > 30) _recent.removeAt(0);
      return p;
    }
    return _make('odd', difficulty);
  }

  Puzzle _make(String k, int d) {
    switch (k) {
      case 'count':
        final max = [5, 7, 9, 12][d - 1];
        final n = 2 + _r.nextInt(max - 1);
        final thing = _things[_r.nextInt(_things.length)];
        return _numbers('q_count', List.filled(n, thing), n, d);
      case 'add':
        final hi = [4, 6, 9, 12][d - 1];
        final a = 1 + _r.nextInt(hi), b = 1 + _r.nextInt(hi);
        final thing = _things[_r.nextInt(_things.length)];
        final show = d <= 2
            ? [...List.filled(a, thing), '➕', ...List.filled(b, thing)]
            : [L.num(a), '➕', L.num(b), '=', '❓'];
        return _numbers('q_add', show, a + b, d);
      case 'big':
        final hi = [10, 20, 50, 99][d - 1];
        final set = <int>{};
        while (set.length < (d >= 3 ? 4 : 3)) {
          set.add(1 + _r.nextInt(hi));
        }
        final opts = set.toList()..shuffle(_r);
        final best = opts.reduce((a, b) => a > b ? a : b);
        return Puzzle('q_big', const [], opts.map(L.num).toList(), opts.indexOf(best));
      case 'pattern':
        final len = d <= 1 ? 2 : (d == 2 ? 2 + _r.nextInt(2) : 3);
        final pool = [..._shapes]..shuffle(_r);
        final unit = pool.take(len).toList();
        // ABAB / ABCABC / AABAAB at higher levels
        final seq = <String>[];
        final unitSeq = (d >= 3 && _r.nextBool()) ? [unit[0], unit[0], unit[1]] : unit;
        final shown = d >= 3 ? 7 : (d == 2 ? 6 : 5);
        for (var i = 0; i < shown; i++) {
          seq.add(unitSeq[i % unitSeq.length]);
        }
        final right = unitSeq[shown % unitSeq.length];
        final opts = <String>{right};
        for (final s in pool) {
          if (opts.length >= (d >= 2 ? 4 : 3)) break;
          opts.add(s);
        }
        final list = opts.toList()..shuffle(_r);
        return Puzzle('q_pattern', [...seq, '❓'], list, list.indexOf(right), bigOptions: true);
      case 'odd':
      default:
        final pair = _pairs[_r.nextInt(_pairs.length)];
        final flip = _r.nextBool();
        final same = flip ? pair[0] : pair[1];
        final diff = flip ? pair[1] : pair[0];
        final n = [4, 6, 9, 12][d - 1];
        final idx = _r.nextInt(n);
        final opts = List.generate(n, (i) => i == idx ? diff : same);
        return Puzzle('q_odd', const [], opts, idx, bigOptions: true);
    }
  }

  Puzzle _numbers(String voice, List<String> show, int right, int d) {
    final set = <int>{right};
    final count = d >= 2 ? 4 : 3;
    while (set.length < count) {
      final v = right + _r.nextInt(7) - 3;
      if (v > 0) set.add(v);
    }
    final opts = set.toList()..shuffle(_r);
    return Puzzle(voice, show, opts.map(L.num).toList(), opts.indexOf(right));
  }
}
