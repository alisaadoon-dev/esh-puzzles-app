// lib/share.dart
// "تحدَّ صديقك": يصنع صورة لنتيجة الطفل (البطل بملابسه + النجوم + العملات)
// ويشاركها مع نص ورابط في أي تطبيق (واتساب، تيليجرام، فيسبوك، ...).

import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'audio.dart';
import 'engine.dart' show HeroKind;
import 'l10n.dart';
import 'outfits.dart' show drawOutfit;
import 'sprites.dart';

/// الرابط الذي يُرسل مع التحدي. غيّره لرابط Google Play بعد النشر.
const kShareLink = 'https://www.youtube.com/@esh.puzzles';

/// مكافأة المشاركة (مرة واحدة في اليوم)
const kShareReward = 10;

const _ss = {
  'ar': {
    'btn': 'تحدَّ صديقك',
    'msg': '🦉 جمعتُ {stars} نجوم و{coins} عملة في لعبة عش الألغاز! هل تستطيع أن تتغلب عليّ؟ 🔥\nالعب معي:',
    'card_title': 'عش الألغاز',
    'card_q': 'هل تستطيع أن تتغلب عليّ؟',
    'reward': 'شكراً للمشاركة! +{n} عملة 🪙',
  },
  'en': {
    'btn': 'Challenge a friend',
    'msg': '🦉 I got {stars} stars and {coins} coins in Puzzle Nest! Can you beat me? 🔥\nPlay with me:',
    'card_title': 'Puzzle Nest',
    'card_q': 'Can you beat me?',
    'reward': 'Thanks for sharing! +{n} coins 🪙',
  },
  'fr': {
    'btn': 'Défie un ami',
    'msg': '🦉 J\'ai eu {stars} étoiles et {coins} pièces dans Le Nid des Énigmes ! Tu peux me battre ? 🔥\nJoue avec moi :',
    'card_title': 'Le Nid des Énigmes',
    'card_q': 'Tu peux me battre ?',
    'reward': 'Merci du partage ! +{n} pièces 🪙',
  },
};

String sT(String k) => (_ss[L.lang] ?? _ss['ar']!)[k] ?? k;

// ───────────── صورة التحدي ─────────────

void _text(Canvas c, String s, Offset center, double size, Color color, {Color? outline, double maxW = 760}) {
  if (outline != null) {
    final o = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900,
          foreground: Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = size / 5
            ..strokeJoin = StrokeJoin.round
            ..color = outline)),
      textDirection: L.dir,
      textAlign: TextAlign.center,
    )..layout(maxWidth: maxW);
    o.paint(c, center - Offset(o.width / 2, o.height / 2));
  }
  final tp = TextPainter(
    text: TextSpan(text: s, style: TextStyle(fontSize: size, fontWeight: FontWeight.w900, color: color)),
    textDirection: L.dir,
    textAlign: TextAlign.center,
  )..layout(maxWidth: maxW);
  tp.paint(c, center - Offset(tp.width / 2, tp.height / 2));
}

Future<Uint8List> _card({required HeroKind hero, required int stars, required int coins, required int eggs, int? level}) async {
  const w = 800.0, h = 800.0;
  final rec = ui.PictureRecorder();
  final c = Canvas(rec, const Rect.fromLTWH(0, 0, w, h));

  // الخلفية
  c.drawRect(const Rect.fromLTWH(0, 0, w, h), Paint()
    ..shader = ui.Gradient.linear(Offset.zero, const Offset(w, h),
        [const Color(0xFFFF8F00), const Color(0xFFE91E63), const Color(0xFF6A1B9A)], [0, .55, 1]));
  // أشعة
  final ray = Paint()..color = Colors.white.withValues(alpha: .08);
  const cc = Offset(w / 2, h * .48);
  for (var i = 0; i < 16; i++) {
    final a = i * pi / 8;
    c.drawPath(Path()
      ..moveTo(cc.dx, cc.dy)
      ..lineTo(cc.dx + cos(a - .1) * 900, cc.dy + sin(a - .1) * 900)
      ..lineTo(cc.dx + cos(a + .1) * 900, cc.dy + sin(a + .1) * 900)
      ..close(), ray);
  }
  // إطار
  c.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(18, 18, w - 36, h - 36), const Radius.circular(40)), Paint()
    ..color = Colors.white
    ..style = PaintingStyle.stroke
    ..strokeWidth = 10);

  _text(c, '🪺 ${sT('card_title')}', const Offset(w / 2, 90), 64, const Color(0xFFFFEB3B), outline: const Color(0xFF3E2723));

  // البطل بملابسه
  final base = hero == HeroKind.owl ? 'owl' : 'fox';
  final img = Sprites.get('${base}_happy') ?? Sprites.get(base);
  const box = Rect.fromLTWH(w / 2 - 150, 170, 300, 300);
  c.drawOval(Rect.fromCenter(center: Offset(w / 2, box.bottom - 6), width: 260, height: 40),
      Paint()..color = Colors.black.withValues(alpha: .25));
  drawOutfit(c, base, box, 0, behind: true);
  if (img != null) {
    final iw = img.width.toDouble(), ih = img.height.toDouble();
    final s = min(box.width / iw, box.height / ih);
    final dst = Rect.fromCenter(center: box.center, width: iw * s, height: ih * s);
    c.drawImageRect(img, Rect.fromLTWH(0, 0, iw, ih), dst, Paint()..filterQuality = FilterQuality.high);
  } else {
    _text(c, hero == HeroKind.owl ? '🦉' : '🦊', box.center, 200, Colors.white);
  }
  drawOutfit(c, base, box, 0, behind: false);

  // النجوم
  for (var i = 0; i < 3; i++) {
    final big = i == 1;
    final shown = level != null ? 3 : stars;
    _text(c, i < shown ? '⭐' : '☆', Offset(w / 2 + (i - 1) * 130, big ? 520 : 535), big ? 110 : 90,
        i < shown ? Colors.white : Colors.white54);
  }
  _text(c, level != null ? '🗺️ ${L.num(level)}     🪙 ${L.num(coins)}' : '🪙 ${L.num(coins)}     🥚 ${L.num(eggs)}/${L.num(3)}', const Offset(w / 2, 630), 52, Colors.white,
      outline: const Color(0xFF4A148C));
  _text(c, '${sT('card_q')} 🔥', const Offset(w / 2, 715), 50, const Color(0xFFFFF59D), outline: const Color(0xFF3E2723));

  final pic = rec.endRecording();
  final image = await pic.toImage(w.toInt(), h.toInt());
  final data = await image.toByteData(format: ui.ImageByteFormat.png);
  return data!.buffer.asUint8List();
}

// ───────────── المشاركة ─────────────

/// يشارك نتيجة الطفل. يرجع عدد العملات المكافأة (0 إذا لا مكافأة).
Future<int> shareChallenge({required HeroKind hero, required int stars, required int coins, required int eggs, int? level}) async {
  final text = '${sT('msg').replaceAll('{stars}', L.num(stars)).replaceAll('{coins}', L.num(coins))}\n$kShareLink';
  ShareResult? res;
  try {
    final png = await _card(hero: hero, stars: stars, coins: coins, eggs: eggs, level: level);
    res = await Share.shareXFiles(
      [XFile.fromData(png, mimeType: 'image/png', name: 'esh_challenge.png')],
      text: text,
    );
  } catch (_) {
    try {
      res = await Share.share(text);
    } catch (_) {
      return 0;
    }
  }
  if (res == null || res.status == ShareResultStatus.dismissed) return 0;
  // مكافأة مرة واحدة في اليوم
  try {
    final sp = await SharedPreferences.getInstance();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    if (sp.getString('share_day') == today) return 0;
    await sp.setString('share_day', today);
    await sp.setInt('coins', (sp.getInt('coins') ?? 30) + kShareReward);
    Sfx.play('coin');
    return kShareReward;
  } catch (_) {
    return 0;
  }
}
