import 'package:flutter/services.dart';
import 'package:vibration/vibration.dart';

/// Vibration patterns. Uses the vibration motor directly (stronger and more
/// varied than system haptics) and falls back to HapticFeedback.
class Buzz {
  static bool enabled = true;
  static bool _hasVib = false;
  static bool _amp = false;
  static DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<void> init() async {
    try {
      final v = await Vibration.hasVibrator();
      _hasVib = v == true;
      final a = await Vibration.hasAmplitudeControl();
      _amp = a == true;
    } catch (_) {
      _hasVib = false;
    }
  }

  static bool _gate(int ms) {
    if (!enabled) return false;
    final now = DateTime.now();
    if (now.difference(_last).inMilliseconds < ms) return false;
    _last = now;
    return true;
  }

  static void _vib(int ms, int amp, _Hf fallback) {
    try {
      if (_hasVib) {
        if (_amp) {
          Vibration.vibrate(duration: ms, amplitude: amp);
        } else {
          Vibration.vibrate(duration: ms);
        }
        return;
      }
    } catch (_) {}
    switch (fallback) {
      case _Hf.light:
        HapticFeedback.lightImpact();
        break;
      case _Hf.medium:
        HapticFeedback.mediumImpact();
        break;
      case _Hf.heavy:
        HapticFeedback.heavyImpact();
        break;
    }
  }

  static void _pattern(List<int> pattern, List<int> amps) {
    try {
      if (_hasVib) {
        if (_amp) {
          Vibration.vibrate(pattern: pattern, intensities: amps);
        } else {
          Vibration.vibrate(pattern: pattern);
        }
        return;
      }
    } catch (_) {}
    HapticFeedback.heavyImpact();
  }

  static void tick() { if (_gate(30)) _vib(12, 60, _Hf.light); }
  static void coin() { if (_gate(40)) _vib(15, 90, _Hf.light); }
  static void jump() { if (_gate(40)) _vib(18, 70, _Hf.light); }
  static void land() { if (_gate(60)) _vib(25, 120, _Hf.medium); }
  static void stomp() { if (_gate(40)) _pattern([0, 30, 30, 60], [0, 200, 0, 255]); }
  static void hurt() { if (_gate(80)) _pattern([0, 90, 50, 140], [0, 255, 0, 200]); }
  static void dash() { if (_gate(60)) _vib(45, 150, _Hf.medium); }
  static void correct() { if (_gate(60)) _pattern([0, 25, 60, 25, 60, 50], [0, 120, 0, 160, 0, 220]); }
  static void wrong() { if (_gate(80)) _pattern([0, 70, 60, 70], [0, 180, 0, 180]); }
  static void crack() { if (_gate(40)) _vib(40, 200, _Hf.heavy); }
  static void boom() { if (_gate(80)) _pattern([0, 200, 40, 120, 40, 260], [0, 255, 0, 200, 0, 255]); }
  static void quake() { if (_gate(80)) _pattern([0, 120, 60, 160, 50, 200, 40, 300, 40, 400], [0, 120, 0, 170, 0, 210, 0, 240, 0, 255]); }
  static void heartbeat() { if (_gate(300)) _pattern([0, 40, 110, 60], [0, 180, 0, 255]); }
  static void magic() { if (_gate(60)) _pattern([0, 20, 30, 20, 30, 20, 30, 60], [0, 80, 0, 120, 0, 160, 0, 230]); }
  static void win() { if (_gate(100)) _pattern([0, 60, 80, 60, 80, 60, 80, 300], [0, 150, 0, 190, 0, 230, 0, 255]); }
}

enum _Hf { light, medium, heavy }
