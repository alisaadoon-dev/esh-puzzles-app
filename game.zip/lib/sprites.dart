import 'dart:async';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';

/// Loads optional character pictures from assets/images. Pictures made on a
/// plain bright-green background have the green removed automatically.
class Sprites {
  static final Map<String, ui.Image> _img = {};

  static ui.Image? get(String name) => _img[name];

  static Future<void> loadAll(Set<String> assets) async {
    const names = [
      'owl', 'owl_happy', 'owl_sad', 'fox', 'fox_happy', 'fox_sad',
      'crow', 'hedgehog', 'egg',
      // الحيوان الأليف
      'pet_baby',
      'pet_forest_2', 'pet_forest_3', 'pet_forest_4',
      'pet_sea_2', 'pet_sea_3', 'pet_sea_4',
      'pet_magic_2', 'pet_magic_3', 'pet_magic_4',
    ];
    // صور الشخصيات من اللعبة الأصلية
    const classic = {
      'owl': 'owl_normal', 'owl_happy': 'owl_happy', 'owl_sad': 'owl_sad',
      'fox': 'fox_normal', 'fox_happy': 'fox_happy', 'fox_sad': 'fox_sad',
    };
    for (final n in names) {
      final paths = [
        for (final ext in ['png', 'jpg', 'jpeg', 'webp']) 'assets/images/$n.$ext',
        if (classic[n] != null) 'assets/characters/${classic[n]}.webp',
      ];
      for (final path in paths) {
        if (assets.isNotEmpty && !assets.contains(path)) continue;
        try {
          final data = await rootBundle.load(path);
          final img = await _decode(data.buffer.asUint8List());
          _img[n] = await _keyGreen(img);
          break;
        } catch (_) {}
      }
    }
  }

  static Future<ui.Image> _decode(Uint8List bytes) async {
    final codec = await ui.instantiateImageCodec(bytes, targetHeight: 320);
    final frame = await codec.getNextFrame();
    return frame.image;
  }

  static Future<ui.Image> _keyGreen(ui.Image src) async {
    final bd = await src.toByteData(format: ui.ImageByteFormat.rawRgba);
    if (bd == null) return src;
    final px = bd.buffer.asUint8List();
    // Only key if the corners are green.
    bool green(int i) => px[i + 1] > 120 && px[i + 1] > px[i] * 1.35 && px[i + 1] > px[i + 2] * 1.35;
    final w = src.width, h = src.height;
    final corners = [0, (w - 1) * 4, ((h - 1) * w) * 4, ((h - 1) * w + w - 1) * 4];
    if (corners.where(green).length < 3) return src;
    for (var i = 0; i < px.length; i += 4) {
      final r = px[i], g = px[i + 1], b = px[i + 2];
      final m = r > b ? r : b;
      if (g > 90 && g > m * 1.25) {
        final strength = ((g - m * 1.25) / 60).clamp(0.0, 1.0);
        px[i + 3] = (255 * (1 - strength)).round();
        // remove green spill on edges
        px[i + 1] = m;
      }
    }
    final c = Completer<ui.Image>();
    ui.decodeImageFromPixels(px, w, h, ui.PixelFormat.rgba8888, c.complete);
    return c.future;
  }
}
