import 'dart:math';
import 'dart:ui';

/// Very forgiving finger-drawing recognizer made for small children.
class Shapes {
  static double _len(List<Offset> p) {
    var l = 0.0;
    for (var i = 1; i < p.length; i++) {
      l += (p[i] - p[i - 1]).distance;
    }
    return l;
  }

  /// A mostly straight, mostly horizontal stroke at least [minWidth] wide.
  static bool isLine(List<Offset> p, double minWidth) {
    if (p.length < 4) return false;
    final dx = (p.last.dx - p.first.dx).abs();
    final dy = (p.last.dy - p.first.dy).abs();
    final len = _len(p);
    if (len <= 0) return false;
    final straight = (p.last - p.first).distance / len;
    return dx >= minWidth && dy < dx * 0.6 && straight > 0.72;
  }

  /// A roughly round, roughly closed loop.
  static bool isCircle(List<Offset> p, double minSize) {
    if (p.length < 8) return false;
    var minX = p.first.dx, maxX = minX, minY = p.first.dy, maxY = minY;
    var cx = 0.0, cy = 0.0;
    for (final o in p) {
      minX = min(minX, o.dx); maxX = max(maxX, o.dx);
      minY = min(minY, o.dy); maxY = max(maxY, o.dy);
      cx += o.dx; cy += o.dy;
    }
    cx /= p.length; cy /= p.length;
    final w = maxX - minX, h = maxY - minY;
    if (w < minSize || h < minSize) return false;
    if (w / h > 2.4 || h / w > 2.4) return false;
    final size = max(w, h);
    final gap = (p.last - p.first).distance;
    if (gap > size * 0.55) return false;
    // radius consistency
    final c = Offset(cx, cy);
    final rs = p.map((o) => (o - c).distance).toList();
    final mean = rs.reduce((a, b) => a + b) / rs.length;
    var varSum = 0.0;
    for (final r in rs) {
      varSum += (r - mean) * (r - mean);
    }
    final sd = sqrt(varSum / rs.length);
    if (sd / mean > 0.42) return false;
    // swept angle
    var swept = 0.0;
    for (var i = 1; i < p.length; i++) {
      final a1 = atan2(p[i - 1].dy - cy, p[i - 1].dx - cx);
      final a2 = atan2(p[i].dy - cy, p[i].dx - cx);
      var d = a2 - a1;
      while (d > pi) { d -= 2 * pi; }
      while (d < -pi) { d += 2 * pi; }
      swept += d;
    }
    return swept.abs() > pi * 1.45;
  }
}
