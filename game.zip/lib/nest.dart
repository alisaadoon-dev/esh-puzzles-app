// lib/nest.dart
// عش الطفل: يطوّر العش ويشتري زينة بالعملات، ويسحبها ويضعها حيث يريد.
// كل شيء يُحفظ في الجهاز. العملات من نفس المحفظة (pet_wallet).

import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'audio.dart';
import 'engine.dart' show HeroKind;
import 'haptics.dart';
import 'l10n.dart';
import 'sprites.dart';
import 'widgets.dart';
import 'outfits.dart' show dressed;

// ───────────── النصوص ─────────────

const _ns = {
  'ar': {
    'title': 'عشّي',
    'back': 'رجوع',
    'upgrade': 'كبّر العش',
    'max': 'أجمل عش!',
    'no_coins': 'ما عندك عملات كافية! العب المغامرة وافتح الصناديق',
    'bought': 'اسحبها وضعها حيث تحب!',
    'upgraded': 'صار عشك أجمل! 🎉',
    'locked': 'كبّر العش لتفتح هذه الزينة 🔒',
    'drag': 'اسحب الزينة لتغيّر مكانها',
    'lv0': 'عش أغصان', 'lv1': 'عش منسوج', 'lv2': 'عش دافئ', 'lv3': 'عش ملكي',
  },
  'en': {
    'title': 'My Nest',
    'back': 'Back',
    'upgrade': 'Upgrade nest',
    'max': 'Best nest ever!',
    'no_coins': 'Not enough coins! Play the adventure and open chests',
    'bought': 'Drag it anywhere you like!',
    'upgraded': 'Your nest got prettier! 🎉',
    'locked': 'Upgrade your nest to unlock this 🔒',
    'drag': 'Drag decorations to move them',
    'lv0': 'Twig nest', 'lv1': 'Woven nest', 'lv2': 'Cozy nest', 'lv3': 'Royal nest',
  },
  'fr': {
    'title': 'Mon Nid',
    'back': 'Retour',
    'upgrade': 'Agrandir le nid',
    'max': 'Le plus beau nid !',
    'no_coins': 'Pas assez de pièces ! Joue l\'aventure et ouvre des coffres',
    'bought': 'Fais-le glisser où tu veux !',
    'upgraded': 'Ton nid est plus beau ! 🎉',
    'locked': 'Agrandis ton nid pour débloquer ça 🔒',
    'drag': 'Fais glisser les décorations',
    'lv0': 'Nid de brindilles', 'lv1': 'Nid tressé', 'lv2': 'Nid douillet', 'lv3': 'Nid royal',
  },
};

String nT(String k) => (_ns[L.lang] ?? _ns['ar']!)[k] ?? k;

// ───────────── الزينة ─────────────

enum Anim { none, bob, flutter, twinkle, sway, spin }

class Decor {
  final String id, emoji;
  final int price;
  final double size;
  final Anim anim;
  final int minLevel;
  const Decor(this.id, this.emoji, this.price, {this.size = 44, this.anim = Anim.none, this.minLevel = 0});
}

const kDecor = [
  Decor('flower', '🌸', 10, anim: Anim.sway),
  Decor('mushroom', '🍄', 15),
  Decor('ladybug', '🐞', 15, size: 34, anim: Anim.bob),
  Decor('sunflower', '🌻', 20, size: 52, anim: Anim.sway),
  Decor('bow', '🎀', 20, size: 38),
  Decor('flag', '🚩', 20, anim: Anim.sway),
  Decor('balloon', '🎈', 25, size: 52, anim: Anim.bob),
  Decor('lantern', '🏮', 30, anim: Anim.sway),
  Decor('butterfly', '🦋', 30, anim: Anim.flutter),
  Decor('kite', '🪁', 40, size: 54, anim: Anim.bob, minLevel: 1),
  Decor('fireflies', '✨', 45, size: 46, anim: Anim.twinkle, minLevel: 1),
  Decor('teddy', '🧸', 50, size: 50, minLevel: 1),
  Decor('crystal', '💎', 60, size: 40, anim: Anim.twinkle, minLevel: 2),
  Decor('star', '🌟', 70, size: 50, anim: Anim.spin, minLevel: 2),
  Decor('rainbow', '🌈', 90, size: 80, minLevel: 2),
  Decor('crown', '👑', 120, size: 48, anim: Anim.bob, minLevel: 3),
  Decor('castle', '🏰', 150, size: 70, minLevel: 3),
];

/// سعر الترقية إلى المستوى التالي (0 → 1 → 2 → 3)
const kNestUpgrade = [50, 120, 250];

// ───────────── الحفظ ─────────────

class NestStore {
  int level = 0, wallet = 0;
  final Map<String, Offset> placed = {}; // id → مكان نسبي (0..1)

  static Future<NestStore> load() async {
    final sp = await SharedPreferences.getInstance();
    final s = NestStore()
      ..level = sp.getInt('nest_level') ?? 0
      ..wallet = sp.getInt('coins') ?? 30;
    for (final row in sp.getStringList('nest_items') ?? const <String>[]) {
      final p = row.split(':');
      if (p.length != 3) continue;
      final x = double.tryParse(p[1]), y = double.tryParse(p[2]);
      if (x != null && y != null) s.placed[p[0]] = Offset(x, y);
    }
    return s;
  }

  Future<void> save() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt('nest_level', level);
    await sp.setInt('coins', wallet);
    await sp.setStringList('nest_items', [
      for (final e in placed.entries) '${e.key}:${e.value.dx.toStringAsFixed(3)}:${e.value.dy.toStringAsFixed(3)}',
    ]);
  }
}

// ───────────── رسم المشهد والعش ─────────────

class _ScenePainter extends CustomPainter {
  final double t;
  final int level;
  final bool night;
  final Offset nest; // مركز العش بالبكسل
  final double nestW;
  _ScenePainter(this.t, this.level, this.night, this.nest, this.nestW);

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    // السماء
    final sky = night
        ? const [Color(0xFF0D1B4A), Color(0xFF283593), Color(0xFF4A3F8C)]
        : const [Color(0xFF4FC3F7), Color(0xFFB3E5FC), Color(0xFFE1F5FE)];
    c.drawRect(Offset.zero & s, Paint()
      ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: sky)
          .createShader(Offset.zero & s));

    if (night) {
      final rnd = Random(7);
      for (var i = 0; i < 60; i++) {
        final p = Offset(rnd.nextDouble() * w, rnd.nextDouble() * h * .6);
        final a = .4 + .6 * (0.5 + 0.5 * sin(t * 2 + i));
        c.drawCircle(p, 1 + rnd.nextDouble() * 1.5, Paint()..color = Colors.white.withValues(alpha: a));
      }
      c.drawCircle(Offset(w * .82, h * .18), 30, Paint()..color = const Color(0xFFFFF9C4));
      c.drawCircle(Offset(w * .82 + 12, h * .18 - 8), 26, Paint()..color = const Color(0xFF1A237E));
    } else {
      final sun = Offset(w * .84, h * .17);
      c.drawCircle(sun, 52 + 4 * sin(t * 2), Paint()..color = const Color(0x55FFF176));
      c.drawCircle(sun, 34, Paint()..color = const Color(0xFFFFEB3B));
      // غيوم متحركة
      final cloud = Paint()..color = Colors.white.withValues(alpha: .9);
      for (var i = 0; i < 3; i++) {
        final x = ((t * (8 + i * 4) + i * w / 3) % (w + 200)) - 100;
        final y = h * (.1 + i * .09);
        c.drawCircle(Offset(x, y), 18, cloud);
        c.drawCircle(Offset(x + 20, y - 8), 22, cloud);
        c.drawCircle(Offset(x + 44, y), 18, cloud);
      }
    }

    // التلال
    final hill1 = Path()
      ..moveTo(0, h * .82)
      ..quadraticBezierTo(w * .25, h * .66, w * .5, h * .8)
      ..quadraticBezierTo(w * .75, h * .92, w, h * .74)
      ..lineTo(w, h)
      ..lineTo(0, h)
      ..close();
    c.drawPath(hill1, Paint()..color = night ? const Color(0xFF1B5E20) : const Color(0xFF66BB6A));
    final hill2 = Path()
      ..moveTo(0, h * .92)
      ..quadraticBezierTo(w * .4, h * .8, w, h * .94)
      ..lineTo(w, h)
      ..lineTo(0, h)
      ..close();
    c.drawPath(hill2, Paint()..color = night ? const Color(0xFF0B3D0E) : const Color(0xFF388E3C));

    // جذع الشجرة والغصن
    final bark = Paint()..color = night ? const Color(0xFF3E2410) : const Color(0xFF6D4C41);
    final trunkX = w * .12;
    c.drawRRect(RRect.fromLTRBR(trunkX - 30, 0, trunkX + 30, h, const Radius.circular(10)), bark);
    final branch = Path()
      ..moveTo(trunkX, nest.dy + 4)
      ..quadraticBezierTo(nest.dx - nestW * .2, nest.dy + 26, nest.dx + nestW * .9, nest.dy + 10)
      ..lineTo(nest.dx + nestW * .9, nest.dy + 24)
      ..quadraticBezierTo(nest.dx - nestW * .2, nest.dy + 42, trunkX, nest.dy + 34)
      ..close();
    c.drawPath(branch, bark);
    // أوراق الشجرة فوق
    final leaf = Paint()..color = night ? const Color(0xFF1B5E20) : const Color(0xFF43A047);
    for (var i = 0; i < 6; i++) {
      c.drawCircle(Offset(trunkX + (i - 2) * 34 + 6 * sin(t + i), 10 + (i % 2) * 24.0), 42, leaf);
    }

    _nest(c);
  }

  void _nest(Canvas c) {
    final cx = nest.dx, cy = nest.dy, nw = nestW, nh = nestW * .42;
    const cols = [
      [Color(0xFF8D6E63), Color(0xFF5D4037)], // أغصان
      [Color(0xFFBC8F5A), Color(0xFF7B5530)], // منسوج
      [Color(0xFFD7A86E), Color(0xFF8D5A2B)], // دافئ
      [Color(0xFFFFD54F), Color(0xFFC79100)], // ملكي
    ];
    final col = cols[level.clamp(0, 3).toInt()];
    final bowl = Rect.fromCenter(center: Offset(cx, cy), width: nw, height: nh);

    // ظل
    c.drawOval(bowl.shift(const Offset(0, 10)), Paint()..color = Colors.black.withValues(alpha: .25));
    // الجسم
    c.drawOval(bowl, Paint()
      ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: col).createShader(bowl));
    // الأغصان المتقاطعة
    final twig = Paint()
      ..color = col[1]
      ..strokeWidth = level >= 1 ? 3 : 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    final rnd = Random(3 + level);
    for (var i = 0; i < 26; i++) {
      final a = rnd.nextDouble() * pi;
      final x = cx + cos(a) * nw * .45 * (rnd.nextBool() ? 1 : -1);
      final y = cy + sin(a) * nh * .35;
      c.drawLine(Offset(x - 14, y - 4), Offset(x + 14, y + 4 * (rnd.nextBool() ? 1 : -1)), twig);
    }
    // الحافة
    final rim = Rect.fromCenter(center: Offset(cx, cy - nh * .25), width: nw * .92, height: nh * .45);
    c.drawOval(rim, Paint()..color = const Color(0xFF3E2723).withValues(alpha: .65));
    c.drawOval(rim, Paint()
      ..color = col[0]
      ..style = PaintingStyle.stroke
      ..strokeWidth = level >= 1 ? 7 : 5);

    // أوراق للمستوى الدافئ وما فوق
    if (level >= 2) {
      final lp = Paint()..color = const Color(0xFF66BB6A);
      for (var i = 0; i < 6; i++) {
        final x = cx - nw * .45 + i * nw * .18;
        final y = cy - nh * .25 + (i.isEven ? -4 : 4);
        c.drawOval(Rect.fromCenter(center: Offset(x, y), width: 18, height: 9), lp);
      }
    }
    // جواهر ولمعان للمستوى الملكي
    if (level >= 3) {
      final gems = [const Color(0xFFE53935), const Color(0xFF1E88E5), const Color(0xFF43A047), const Color(0xFFAB47BC)];
      for (var i = 0; i < 5; i++) {
        final x = cx - nw * .36 + i * nw * .18;
        final y = cy + nh * .05;
        final g = Path()
          ..moveTo(x, y - 7)
          ..lineTo(x + 6, y)
          ..lineTo(x, y + 7)
          ..lineTo(x - 6, y)
          ..close();
        c.drawPath(g, Paint()..color = gems[i % 4]);
      }
      final a = .5 + .5 * sin(t * 3);
      c.drawCircle(Offset(cx + nw * .38, cy - nh * .3), 4 + 3 * a, Paint()..color = Colors.white.withValues(alpha: a));
    }
  }

  @override
  bool shouldRepaint(covariant _ScenePainter o) => true;
}

// ───────────── شاشة العش ─────────────

class NestScreen extends StatefulWidget {
  final HeroKind hero;
  const NestScreen({super.key, this.hero = HeroKind.owl});
  @override
  State<NestScreen> createState() => _NestScreenState();
}

class _NestScreenState extends State<NestScreen> with SingleTickerProviderStateMixin {
  NestStore? s;
  late final AnimationController _clock =
      AnimationController(vsync: this, duration: const Duration(seconds: 60))..repeat();
  String toast = '';
  int toastId = 0;
  String? bounceId;
  int bounceN = 0;
  double heroJump = 0;
  final rnd = Random();
  final List<(Offset, double)> sparkles = []; // (مكان، وقت البداية)

  final _sw = Stopwatch()..start();
  double get t => _sw.elapsedMicroseconds / 1e6;
  bool get night {
    final hr = DateTime.now().hour;
    return hr >= 19 || hr < 6;
  }

  @override
  void initState() {
    super.initState();
    NestStore.load().then((v) {
      if (mounted) setState(() => s = v);
    });
  }

  @override
  void dispose() {
    _clock.dispose();
    super.dispose();
  }

  void _say(String k) {
    setState(() {
      toast = nT(k);
      toastId++;
    });
    final id = toastId;
    Future.delayed(const Duration(milliseconds: 2600), () {
      if (mounted && toastId == id) setState(() => toast = '');
    });
  }

  void _sparkle(Offset p) {
    final now = t;
    for (var i = 0; i < 10; i++) {
      sparkles.add((p + Offset((rnd.nextDouble() - .5) * 120, (rnd.nextDouble() - .5) * 90), now + rnd.nextDouble() * .4));
    }
  }

  void _heroHappy() {
    Sfx.play(widget.hero == HeroKind.owl ? 'double_jump' : 'jump');
    Buzz.jump();
    setState(() => heroJump = t);
  }

  Future<void> _buy(Decor d, Size area) async {
    final st = s;
    if (st == null) return;
    if (st.placed.containsKey(d.id)) {
      // مملوكة: نجعلها تقفز ليعرف مكانها
      setState(() { bounceId = d.id; bounceN++; });
      Sfx.play('click');
      return;
    }
    if (st.level < d.minLevel) {
      Sfx.play('wrong');
      Buzz.wrong();
      _say('locked');
      return;
    }
    if (st.wallet < d.price) {
      Sfx.play('wrong');
      Buzz.wrong();
      _say('no_coins');
      return;
    }
    final pos = Offset(.3 + rnd.nextDouble() * .5, .25 + rnd.nextDouble() * .45);
    setState(() {
      st.wallet -= d.price;
      st.placed[d.id] = pos;
      bounceId = d.id;
      bounceN++;
    });
    _sparkle(Offset(pos.dx * area.width, pos.dy * area.height));
    Sfx.play('magic');
    Sfx.play('coin');
    Buzz.magic();
    _say('bought');
    _heroHappy();
    await st.save();
  }

  Future<void> _upgrade(Offset nestPx) async {
    final st = s;
    if (st == null || st.level >= 3) return;
    final price = kNestUpgrade[st.level];
    if (st.wallet < price) {
      Sfx.play('wrong');
      Buzz.wrong();
      _say('no_coins');
      return;
    }
    setState(() {
      st.wallet -= price;
      st.level++;
    });
    _sparkle(nestPx);
    _sparkle(nestPx);
    Sfx.play('win');
    Sfx.play('magic');
    Buzz.win();
    _say('upgraded');
    _heroHappy();
    await st.save();
  }

  double _animY(Decor d, double tt, int i) {
    switch (d.anim) {
      case Anim.bob:
        return sin(tt * 2 + i) * 6;
      case Anim.flutter:
        return sin(tt * 3 + i) * 10;
      default:
        return 0;
    }
  }

  double _animX(Decor d, double tt, int i) => d.anim == Anim.flutter ? cos(tt * 1.3 + i) * 14 : 0;

  double _animRot(Decor d, double tt, int i) {
    switch (d.anim) {
      case Anim.sway:
        return sin(tt * 1.6 + i) * .12;
      case Anim.spin:
        return tt * .8;
      default:
        return 0;
    }
  }

  double _animScale(Decor d, double tt, int i) {
    switch (d.anim) {
      case Anim.twinkle:
        return 1 + .12 * sin(tt * 4 + i);
      case Anim.flutter:
        return 1 + .1 * sin(tt * 18).abs();
      default:
        return 1;
    }
  }

  Widget _decorWidget(Decor d, int i, Size area) {
    final st = s!;
    final rel = st.placed[d.id]!;
    final tt = t;
    final x = rel.dx * area.width + _animX(d, tt, i);
    final y = rel.dy * area.height + _animY(d, tt, i);
    final child = Transform.rotate(
      angle: _animRot(d, tt, i),
      child: Transform.scale(
        scale: _animScale(d, tt, i),
        child: Text(d.emoji, style: TextStyle(fontSize: d.size)),
      ),
    );
    return Positioned(
      left: x - d.size * .7,
      top: y - d.size * .7,
      child: GestureDetector(
        onTap: () {
          setState(() { bounceId = d.id; bounceN++; });
          Sfx.play(d.anim == Anim.twinkle ? 'magic' : 'click', minGapMs: 120);
          Buzz.tick();
        },
        onPanStart: (_) => Buzz.tick(),
        onPanUpdate: (u) => setState(() {
          final cur = st.placed[d.id] ?? rel;
          final nx = (cur.dx + u.delta.dx / area.width).clamp(.04, .96).toDouble();
          final ny = (cur.dy + u.delta.dy / area.height).clamp(.06, .94).toDouble();
          st.placed[d.id] = Offset(nx, ny);
        }),
        onPanEnd: (_) {
          Sfx.play('land');
          Buzz.land();
          st.save();
        },
        child: Container(
          width: d.size * 1.4,
          height: d.size * 1.4,
          alignment: Alignment.center,
          child: bounceId == d.id
              ? TweenAnimationBuilder<double>(
                  key: ValueKey(bounceN),
                  tween: Tween(begin: 1.5, end: 1),
                  duration: const Duration(milliseconds: 600),
                  curve: Curves.elasticOut,
                  builder: (_, v, ch) => Transform.scale(scale: v, child: ch),
                  child: child,
                )
              : child,
        ),
      ),
    );
  }

  Widget _hero(Offset nest, double nestW) {
    final happy = t - heroJump < 1.2 && heroJump > 0;
    final base = widget.hero == HeroKind.owl ? 'owl' : 'fox';
    final img = Sprites.get(happy ? '${base}_happy' : base) ?? Sprites.get(base);
    final hs = nestW * .62;
    final jump = happy ? -sin(((t - heroJump) / 1.2).clamp(0.0, 1.0) * pi * 2).abs() * 30 : 0.0;
    final breathe = 1 + .03 * sin(t * 2.4);
    return Positioned(
      left: nest.dx - hs / 2,
      top: nest.dy - hs * .95 + jump,
      child: GestureDetector(
        onTap: _heroHappy,
        child: Transform.scale(
          scale: breathe,
          alignment: Alignment.bottomCenter,
          child: dressed(base, hs, SizedBox(
            width: hs, height: hs,
            child: img != null
                ? RawImage(image: img, fit: BoxFit.contain)
                : FittedBox(child: Text(widget.hero == HeroKind.owl ? '🦉' : '🦊')),
          )),
        ),
      ),
    );
  }

  Widget _shopCard({required Widget icon, required String label, required Widget price,
      required VoidCallback onTap, bool owned = false, bool locked = false, Color color = Colors.white}) {
    return GestureDetector(
      onTap: onTap,
      child: Opacity(
        opacity: locked ? .5 : 1,
        child: Container(
          width: 74,
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.symmetric(vertical: 4),
          decoration: BoxDecoration(
            color: owned ? const Color(0xFFC8E6C9) : color,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: owned ? const Color(0xFF43A047) : const Color(0xFFFF6F00), width: 2.5),
            boxShadow: const [BoxShadow(color: Color(0x55000000), offset: Offset(0, 3), blurRadius: 3)],
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Stack(alignment: Alignment.center, children: [
              icon,
              if (locked) const Positioned(right: 0, bottom: 0, child: Text('🔒', style: TextStyle(fontSize: 14))),
            ]),
            if (label.isNotEmpty)
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: Color(0xFF4E342E))),
            price,
          ]),
        ),
      ),
    );
  }

  Widget _priceTag(int p) => Text(p == 0 ? '✅' : '🪙 ${L.num(p)}',
      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: Color(0xFFE65100)));

  @override
  Widget build(BuildContext context) {
    final st = s;
    return Directionality(
      textDirection: L.dir,
      child: Scaffold(
        backgroundColor: const Color(0xFF4FC3F7),
        body: st == null
            ? const Center(child: CircularProgressIndicator())
            : AnimatedBuilder(
                animation: _clock,
                builder: (context, _) => Column(children: [
                  Expanded(
                    child: LayoutBuilder(builder: (context, box) {
                      final area = Size(box.maxWidth, box.maxHeight);
                      final nestW = min(area.width * .3, area.height * .55) * (1 + st.level * .08);
                      final nest = Offset(area.width * .42, area.height * .7);
                      final tt = t;
                      sparkles.removeWhere((sp) => tt - sp.$2 > 1.2);
                      return Stack(clipBehavior: Clip.none, children: [
                        Positioned.fill(child: CustomPaint(painter: _ScenePainter(tt, st.level, night, nest, nestW))),
                        _hero(nest, nestW),
                        for (var i = 0; i < kDecor.length; i++)
                          if (st.placed.containsKey(kDecor[i].id)) _decorWidget(kDecor[i], i, area),
                        // اللمعان
                        for (final sp in sparkles)
                          if (tt >= sp.$2)
                            Positioned(
                              left: sp.$1.dx - 12,
                              top: sp.$1.dy - 12 - (tt - sp.$2) * 40,
                              child: IgnorePointer(child: Opacity(
                                opacity: (1 - (tt - sp.$2) / 1.2).clamp(0.0, 1.0).toDouble(),
                                child: const Text('✨', style: TextStyle(fontSize: 22)),
                              )),
                            ),
                        // الشريط العلوي
                        Positioned(
                          top: 8, left: 8, right: 8,
                          child: SafeArea(
                            bottom: false,
                            child: Row(children: [
                              Btn3D(
                                color: const Color(0xFF78909C), depth: 4, radius: 14,
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                onTap: () => Navigator.of(context).pop(),
                                child: Text(nT('back'), style: const TextStyle(fontSize: 18)),
                              ),
                              const SizedBox(width: 12),
                              OutlinedText('🪺 ${nT('title')}', size: 24, color: const Color(0xFFFFEB3B)),
                              const SizedBox(width: 8),
                              OutlinedText(nT('lv${st.level}'), size: 15),
                              const Spacer(),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                decoration: BoxDecoration(color: const Color(0xAA000000), borderRadius: BorderRadius.circular(20),
                                    border: Border.all(color: Colors.white70, width: 2)),
                                child: PopIn(
                                  key: ValueKey(st.wallet),
                                  child: Text('🪙 ${L.num(st.wallet)}',
                                      style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                                ),
                              ),
                            ]),
                          ),
                        ),
                        if (toast.isNotEmpty)
                          Positioned(
                            left: 0, right: 0, top: 58,
                            child: IgnorePointer(child: Center(child: PopIn(
                              key: ValueKey(toastId),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                decoration: BoxDecoration(color: const Color(0xDD1A237E), borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: Colors.white, width: 2)),
                                child: Text(toast, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                              ),
                            ))),
                          ),
                      ]);
                    }),
                  ),
                  // المتجر
                  LayoutBuilder(builder: (context, box) {
                    final sceneSize = Size(box.maxWidth, MediaQuery.of(context).size.height - 96);
                    final nestPx = Offset(sceneSize.width * .42, sceneSize.height * .7);
                    return Container(
                      height: 96,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                            colors: [Color(0xFF8D6E63), Color(0xFF5D4037)]),
                        border: Border(top: BorderSide(color: Color(0xFFFFCC80), width: 4)),
                      ),
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
                        children: [
                          _shopCard(
                            color: const Color(0xFFFFF59D),
                            icon: const Text('🪺', style: TextStyle(fontSize: 30)),
                            label: st.level >= 3 ? nT('max') : nT('upgrade'),
                            price: st.level >= 3 ? _priceTag(0) : _priceTag(kNestUpgrade[st.level]),
                            onTap: () => _upgrade(nestPx),
                          ),
                          for (final d in kDecor)
                            _shopCard(
                              icon: Text(d.emoji, style: const TextStyle(fontSize: 30)),
                              label: '',
                              price: _priceTag(st.placed.containsKey(d.id) ? 0 : d.price),
                              owned: st.placed.containsKey(d.id),
                              locked: st.level < d.minLevel,
                              onTap: () => _buy(d, sceneSize),
                            ),
                        ],
                      ),
                    );
                  }),
                ]),
              ),
      ),
    );
  }
}
