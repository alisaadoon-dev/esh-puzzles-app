"""Generates the game's voice lines with the Gemini TTS API.

Run by the "Generate voices" GitHub Actions workflow. Needs the GEMINI_API_KEY
environment variable. Files that already exist are skipped, so if the free
quota runs out you can simply run the workflow again the next day and it
continues where it stopped. Output: assets/voice/<lang>/<key>.wav
"""
import base64, json, os, sys, time, urllib.request, urllib.error, wave

KEY = os.environ.get("GEMINI_API_KEY", "").strip()
if not KEY:
    sys.exit("GEMINI_API_KEY secret is missing")

HERE = os.path.dirname(os.path.abspath(__file__))
LINES = json.load(open(os.path.join(HERE, "voice_lines.json"), encoding="utf-8"))
OUT = os.path.join(HERE, "..", "assets", "voice")
LANGS = [l for l in os.environ.get("VOICE_LANGS", "ar,en,fr").split(",") if l]
MODELS = ["gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"]
VOICES = {"narrator": "Charon", "hero": "Leda", "crow": "Algenib"}
STYLE = {
    "narrator": "a warm, exciting storyteller for young children",
    "hero": "a brave, cheerful young cartoon hero",
    "crow": "a funny, cheeky cartoon villain crow (playful, not scary)",
}
LANG_NAME = {"ar": "Modern Standard Arabic (فصحى) with full clear pronunciation",
             "en": "English", "fr": "French"}
LANG_CODE = {"ar": "ar-XA", "en": "en-US", "fr": "fr-FR"}


def call(model, prompt, voice):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}},
        },
    }
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json", "x-goog-api-key": KEY})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = json.load(r)
    for part in data["candidates"][0]["content"]["parts"]:
        if "inlineData" in part:
            return base64.b64decode(part["inlineData"]["data"])
    raise RuntimeError("no audio in response")


def save_pcm(path, pcm):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(24000)
        w.writeframes(pcm)


made = skipped = 0
model_i = 0
for lang in LANGS:
    for key, line in LINES.items():
        path = os.path.join(OUT, lang, key + ".wav")
        if os.path.exists(path):
            skipped += 1
            continue
        who = line["who"]
        prompt = (f"Say this in {LANG_NAME[lang]}, in the voice of {STYLE[who]}, "
                  f"with lively emotion: {line[lang]}")
        for attempt in range(6):
            try:
                pcm = call(MODELS[model_i], prompt, VOICES[who])
                save_pcm(path, pcm)
                made += 1
                print("ok", lang, key, flush=True)
                break
            except urllib.error.HTTPError as e:
                msg = e.read().decode(errors="ignore")[:300]
                if e.code == 404 and model_i + 1 < len(MODELS):
                    model_i += 1
                    print("model not found, switching to", MODELS[model_i], flush=True)
                    continue
                if e.code == 429:
                    if "PerDay" in msg or "per day" in msg.lower():
                        print(f"Daily quota reached. Made {made}. Run again tomorrow to continue.")
                        sys.exit(0)
                    wait = 30 * (attempt + 1)
                    print("rate limited, waiting", wait, "s", flush=True)
                    time.sleep(wait)
                    continue
                print("error", e.code, key, msg, flush=True)
                time.sleep(5)
            except Exception as e:  # network hiccup or odd response
                print("error", key, e, flush=True)
                time.sleep(5)
        time.sleep(7)  # stay under the per-minute limit

print(f"done: made {made}, already had {skipped}")
