"""Synthesizes placeholder sound effects and music loops as WAV files.
Replace any file in assets/sfx or assets/music with a real recording of the same name."""
import numpy as np, wave, os, sys

SR = 22050
OUT = sys.argv[1] if len(sys.argv) > 1 else "assets"
rng = np.random.default_rng(7)


def save(path, x, sr=SR):
    x = np.asarray(x, dtype=np.float64)
    peak = np.max(np.abs(x)) or 1.0
    x = x / peak * 0.89
    data = (x * 32767).astype(np.int16)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(data.tobytes())


def t(d):
    return np.arange(int(SR * d)) / SR


def env(n, a=0.005, r=None, curve=3.0):
    tt = np.linspace(0, 1, n)
    att = max(1, int(a * SR))
    e = np.ones(n)
    e[:att] = np.linspace(0, 1, att)
    e *= (1 - tt) ** curve if r is None else np.exp(-tt * r)
    return e


def sweep(f0, f1, d, kind="sine"):
    tt = t(d)
    f = np.geomspace(f0, f1, len(tt))
    ph = 2 * np.pi * np.cumsum(f) / SR
    if kind == "square":
        return np.sign(np.sin(ph)) * 0.6
    if kind == "tri":
        return 2 / np.pi * np.arcsin(np.sin(ph))
    return np.sin(ph)


def noise(d):
    return rng.uniform(-1, 1, int(SR * d))


def lowpass(x, cutoff):
    # simple one-pole, cutoff may be array
    y = np.zeros_like(x)
    c = np.broadcast_to(np.asarray(cutoff, dtype=float), x.shape)
    a = 1 - np.exp(-2 * np.pi * c / SR)
    acc = 0.0
    for i in range(len(x)):
        acc += a[i] * (x[i] - acc)
        y[i] = acc
    return y


def tone(f, d, harm=(1, .5, .25), decay=6):
    tt = t(d)
    s = sum(h * np.sin(2 * np.pi * f * (k + 1) * tt) for k, h in enumerate(harm))
    return s * env(len(tt), r=decay)


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def at(x, offset, total):
    out = np.zeros(int(SR * total))
    s = int(SR * offset)
    out[s:s + len(x)] += x[:len(out) - s]
    return out


S = {}
S["jump"] = sweep(260, 720, .18, "tri") * env(int(SR * .18), curve=1.5)
S["double_jump"] = mix(sweep(400, 1100, .2, "tri") * env(int(SR * .2), curve=1.5),
                        lowpass(noise(.25), 2500) * env(int(SR * .25), curve=2) * .6)
S["land"] = mix(lowpass(noise(.12), 600) * env(int(SR * .12), curve=4), sweep(140, 60, .12) * env(int(SR * .12), curve=3))
S["coin"] = mix(tone(1318, .08, decay=8), at(tone(1760, .35, decay=7), .07, .42))
S["egg"] = mix(*[at(tone(f, .5, decay=5) * .7, i * .09, 1.0) for i, f in enumerate([784, 988, 1175, 1568])])
S["stomp"] = mix(sweep(500, 90, .15, "square") * env(int(SR * .15), curve=2), lowpass(noise(.1), 1500) * env(int(SR * .1), curve=3))
S["hurt"] = sweep(600, 180, .3, "square") * env(int(SR * .3), curve=1.5) * .7
S["dash"] = lowpass(noise(.35), np.geomspace(300, 5000, int(SR * .35))) * np.sin(np.linspace(0, np.pi, int(SR * .35)))
S["slide"] = lowpass(noise(.4), 900) * np.sin(np.linspace(0, np.pi, int(SR * .4)))
S["crate"] = mix(*[at(lowpass(noise(.08), 1800) * env(int(SR * .08), curve=5), o, .5) for o in (0, .05, .11, .2)],
                 sweep(220, 70, .3) * env(int(SR * .3), curve=3))
# wood planks knocking into place
S["bridge"] = mix(*[at(mix(tone(300 + 40 * i, .12, harm=(1, .3), decay=25), lowpass(noise(.05), 2500) * env(int(SR * .05), curve=5) * .5), i * .09, 1.1) for i in range(10)])
S["magic"] = mix(*[at(tone(f, .6, decay=5) * .5, i * .05, 1.1) for i, f in enumerate([1046, 1318, 1568, 2093, 2637, 3136])],
                 lowpass(noise(1.0), 6000) * env(int(SR * 1.0), curve=2) * .15)
S["shield"] = mix(sweep(200, 900, .5, "sine") * env(int(SR * .5), curve=1), S["magic"] * .6)
S["shield_hit"] = mix(tone(220, .6, harm=(1, .7, .5, .3), decay=6), lowpass(noise(.2), 3000) * env(int(SR * .2), curve=3))
rum_n = int(SR * 1.6)
rum = lowpass(noise(1.6), 140) * 3
S["gate_crack"] = mix(*[at(lowpass(noise(.06), 4000) * env(int(SR * .06), curve=6), o, .5) for o in (0, .07, .12, .25, .3)])
S["gate_break"] = mix(rum * env(rum_n, curve=1.5),
                      *[at(lowpass(noise(.1), 2500) * env(int(SR * .1), curve=4) * rng.uniform(.3, .8), o, 1.6) for o in rng.uniform(0, 1.2, 18)])
S["boom"] = mix(sweep(120, 35, 1.2) * env(int(SR * 1.2), curve=2) * 1.4, lowpass(noise(1.2), 400) * env(int(SR * 1.2), curve=2))
S["quake"] = lowpass(noise(2.2), 90) * np.sin(np.linspace(0, np.pi, int(SR * 2.2))) * (1 + .5 * np.sin(2 * np.pi * 7 * t(2.2)))
S["correct"] = mix(tone(784, .15, decay=10), at(tone(1175, .4, decay=6), .1, .5))
S["wrong"] = mix(sweep(300, 200, .18, "square") * env(int(SR * .18), curve=1) * .5, at(sweep(250, 150, .3, "square") * env(int(SR * .3), curve=1) * .5, .18, .5))
cw = t(.45)
caw = np.sign(np.sin(2 * np.pi * (900 - 500 * cw / .45) * cw)) * lowpass(noise(.45), 3000)
S["crow"] = mix(caw * env(len(cw), curve=1.2), at(caw * env(len(cw), curve=1.2) * .8, .5, 1.0))
S["heartbeat"] = mix(sweep(90, 45, .12) * env(int(SR * .12), curve=3), at(sweep(80, 40, .12) * env(int(SR * .12), curve=3) * .7, .18, .5))
S["whoosh"] = lowpass(noise(.6), np.geomspace(200, 3000, int(SR * .6))) * np.sin(np.linspace(0, np.pi, int(SR * .6)))
S["slowmo"] = mix(sweep(800, 120, .7, "sine") * env(int(SR * .7), curve=1) * .6, lowpass(noise(.7), 500) * .3)
win = [523, 659, 784, 1046, 784, 1046, 1318]
S["win"] = mix(*[at(tone(f, .5, decay=4), i * .13, 1.6) for i, f in enumerate(win)])
S["lose"] = mix(*[at(tone(f, .5, decay=4) * .8, i * .22, 1.4) for i, f in enumerate([392, 370, 349, 262])])
S["click"] = tone(1200, .05, decay=30)
S["checkpoint"] = mix(tone(659, .2, decay=8), at(tone(988, .4, decay=6), .1, .5))

for k, v in S.items():
    save(f"{OUT}/sfx/{k}.wav", v)


# ----- music loops -----
def music(bpm, bars, chords, lead_scale, drum_heavy, seed):
    r = np.random.default_rng(seed)
    beat = 60 / bpm
    total = bars * 4 * beat
    out = np.zeros(int(SR * total))

    def put(x, sec, vol=1.0):
        s = int(sec * SR)
        e = min(len(out), s + len(x))
        out[s:e] += x[:e - s] * vol

    for b in range(bars):
        root = chords[b % len(chords)]
        for q in range(4):
            sec = (b * 4 + q) * beat
            # bass
            put(tone(root / 2, beat * .9, harm=(1, .4), decay=4), sec, .55)
            # pad / arpeggio
            for i, m in enumerate([1, 1.25, 1.5]):
                put(tone(root * m, beat * .45, harm=(1, .2), decay=7), sec + i * beat / 3, .16)
            # drums
            kick = sweep(150, 45, .15) * env(int(SR * .15), curve=3)
            put(kick, sec, .8 if (q % 2 == 0 or drum_heavy) else 0)
            hat = lowpass(noise(.04), 8000) - lowpass(noise(.04), 2000)
            put(hat * env(len(hat), curve=4), sec + beat / 2, .35)
            if q % 2 == 1:
                sn = lowpass(noise(.15), 4000) * env(int(SR * .15), curve=3)
                put(sn, sec, .45 if drum_heavy else .25)
            # lead
            if r.random() < (.8 if drum_heavy else .55):
                f = r.choice(lead_scale)
                put(tone(f, beat * .5, harm=(1, .3, .1), decay=6), sec + r.choice([0, beat / 2]), .25)
    return out


save(f"{OUT}/music/forest.wav", music(100, 8, [262, 349, 392, 330], [523, 587, 659, 784, 880], False, 1))
save(f"{OUT}/music/chase.wav", music(150, 8, [220, 220, 175, 196], [440, 523, 587, 659, 698], True, 2))
save(f"{OUT}/music/boss.wav", music(130, 8, [196, 208, 175, 185], [392, 415, 466, 523], True, 3))
print("done", len(S), "sfx")
