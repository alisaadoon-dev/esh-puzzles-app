Optional character pictures (made with Gemini on a plain bright-green background):
owl.png owl_happy.png owl_sad.png fox.png fox_happy.png fox_sad.png crow.png hedgehog.png egg.png
Upload them to the repository root; the build copies them here and removes the green automatically.
